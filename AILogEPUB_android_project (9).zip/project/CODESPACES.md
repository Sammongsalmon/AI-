# Codespaces 에서 한 번에 빌드하기

GitHub Actions 를 거치지 않고 Codespaces 안에서 바로 APK 를 만듭니다.
PC 없이 폰 브라우저만으로도 됩니다.

## 1. Codespace 열기

GitHub 에서 아무 저장소나 하나 만들고(빈 저장소도 됩니다)
`Code` → `Codespaces` → `Create codespace` 를 누릅니다.

## 2. ZIP 올리기

Codespace 화면 왼쪽 탐색기의 빈 곳에 `AILogEPUB_android_project.zip` 을
끌어다 놓거나, 우클릭 → `Upload...` 로 올립니다.

## 3. 명령 세 줄

아래 터미널에 그대로 붙여 넣습니다.

```bash
unzip -o AILogEPUB_android_project.zip
cd project
bash run.sh
```

끝입니다. 처음 한 번은 Android SDK 와 Gradle 을 받느라 5~10분쯤 걸리고,
그 다음부터는 1~2분이면 끝납니다.

## 4. 받기

빌드가 끝나면 `project/out/` 안에 APK 가 생깁니다.
왼쪽 탐색기에서 그 파일을 우클릭 → `Download` 하면 폰으로 바로 내려받습니다.

**`project/keystore/release.jks` 도 같이 내려받아 보관하세요.**
이 파일이 있어야 다음 버전을 앱 삭제 없이 덮어쓰기 설치할 수 있습니다.

## 5. (선택) GitHub 저장소에도 올리기

Actions 로도 빌드하고 싶으면 이어서 실행합니다.

```bash
bash publish.sh 원하는-저장소-이름
```

저장소 생성 → 푸시 → 키스토어 시크릿 등록 → 빌드 실행까지 자동으로 합니다.
키스토어와 `out/` 폴더는 `.gitignore` 로 막아 두어 절대 올라가지 않습니다.

---

## 다시 빌드할 때

코드를 고친 뒤 `bash run.sh` 만 다시 실행하면 됩니다.
`keystore/release.jks` 가 그대로 남아 있으므로 **같은 인증서로 서명되어
앱을 지우지 않고 업데이트**됩니다.

Codespace 를 지웠다면, 보관해 둔 `release.jks` 를 `project/keystore/` 에
도로 넣고 `run.sh` 를 실행하면 같은 인증서가 유지됩니다.

## 막혔을 때

| 증상 | 확인 |
|---|---|
| `Unsupported class file major version 69` | Codespace 기본 JDK 가 25 라 Gradle 이 거부한 것입니다. 새 `run.sh` 는 JDK 17/21 을 직접 찾아 쓰므로 그대로 다시 실행하면 됩니다 |
| `java` 버전 부족 | 스크립트가 JDK 17 을 자동 설치합니다. 실패 시 `sudo apt-get install -y openjdk-17-jdk` |
| SDK 다운로드 실패 | Codespace 네트워크 문제입니다. 잠시 뒤 `bash run.sh` 재실행 |
| `gh` 권한 오류 | `gh auth refresh -h github.com -s repo,workflow` |
| Gradle 빌드 오류 | 터미널 출력 전체를 그대로 보내 주세요 |
