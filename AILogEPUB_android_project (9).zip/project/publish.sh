#!/usr/bin/env bash
# =============================================================
#  README 2~5단계 자동 실행
#    저장소 생성 → 푸시 → 키스토어 시크릿 등록 → Actions 빌드
#
#  사용법:  bash publish.sh [저장소이름]
#  (run.sh 를 먼저 한 번 돌려 키스토어가 만들어져 있어야 합니다)
# =============================================================
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$HERE"

REPO="${1:-ai-log-epub}"
KS_DIR="$HERE/keystore"
B64="$KS_DIR/release.jks.base64.txt"

step() { printf '\n\033[1;36m▶ %s\033[0m\n' "$*"; }
info() { printf '  %s\n' "$*"; }
warn() { printf '\033[1;33m  ! %s\033[0m\n' "$*"; }
die()  { printf '\n\033[1;31m✗ %s\033[0m\n' "$*" >&2; exit 1; }

command -v gh >/dev/null 2>&1 || die "gh CLI 가 없습니다. Codespaces 에서 실행해 주세요."
[ -f "$B64" ] || die "키스토어가 없습니다. 먼저 'bash run.sh' 를 실행해 주세요."

# -------------------------------------------------- 1. 인증
step "1/5  GitHub 인증 확인"
if ! gh auth status >/dev/null 2>&1; then
  warn "인증이 필요합니다. 안내를 따라 진행해 주세요."
  gh auth login
fi
OWNER="$(gh api user --jq .login)"
info "계정: $OWNER"

# 시크릿 등록 권한이 없으면 여기서 막힌다
if ! gh auth status 2>&1 | grep -qi 'repo'; then
  warn "토큰 권한이 부족할 수 있습니다. 실패하면: gh auth refresh -h github.com -s repo,workflow"
fi

# -------------------------------------------------- 2. 커밋
step "2/5  로컬 커밋 준비"
if [ ! -d .git ]; then
  git init -q -b main
  info "git 저장소 초기화"
fi
git config user.email >/dev/null 2>&1 || git config user.email "$OWNER@users.noreply.github.com"
git config user.name  >/dev/null 2>&1 || git config user.name  "$OWNER"

# 키스토어·산출물이 절대 올라가지 않도록 재확인
for p in 'keystore/' 'out/' 'local.properties' '.gradle/' 'build/' '*.jks'; do
  grep -qxF "$p" .gitignore 2>/dev/null || echo "$p" >> .gitignore
done

git add -A
if git diff --cached --quiet; then
  info "변경 사항 없음 — 기존 커밋 사용"
else
  git commit -q -m "AI Log EPUB — JavascriptInterface 브리지 적용판"
  info "커밋 완료"
fi

# 안전장치: 키스토어가 추적되고 있으면 중단
if git ls-files --error-unmatch keystore/release.jks >/dev/null 2>&1; then
  die "키스토어가 커밋에 포함됐습니다. .gitignore 를 확인해 주세요."
fi

# -------------------------------------------------- 3. 저장소
step "3/5  원격 저장소"
if gh repo view "$OWNER/$REPO" >/dev/null 2>&1; then
  info "$OWNER/$REPO 이미 존재 — 그대로 사용"
  git remote get-url origin >/dev/null 2>&1 \
    || git remote add origin "https://github.com/$OWNER/$REPO.git"
  if ! git push -u origin main 2>/dev/null; then
    warn "원격에 다른 내용이 있어 강제로 덮어씁니다."
    git push -u origin main --force
  fi
else
  info "$OWNER/$REPO 를 Private 으로 생성"
  gh repo create "$REPO" --private --source=. --remote=origin --push
fi

# -------------------------------------------------- 4. 시크릿
step "4/5  키스토어 시크릿 등록"
PW="$(grep '^KEYSTORE_PASSWORD' "$KS_DIR/암호.txt" | cut -d= -f2- | xargs)"
AL="$(grep '^KEY_ALIAS'         "$KS_DIR/암호.txt" | cut -d= -f2- | xargs)"

gh secret set KEYSTORE_BASE64   --repo "$OWNER/$REPO" < "$B64"
gh secret set KEYSTORE_PASSWORD --repo "$OWNER/$REPO" --body "$PW"
gh secret set KEY_ALIAS         --repo "$OWNER/$REPO" --body "$AL"
info "KEYSTORE_BASE64 / KEYSTORE_PASSWORD / KEY_ALIAS 등록 완료"
info "이제부터 몇 번을 다시 빌드해도 인증서가 같습니다."

# -------------------------------------------------- 5. 빌드 실행
step "5/5  Actions 빌드 실행"
sleep 3
if gh workflow run build.yml --repo "$OWNER/$REPO" --ref main 2>/dev/null; then
  info "빌드를 시작했습니다. 진행 상황을 지켜봅니다."
  sleep 8
  gh run watch --repo "$OWNER/$REPO" --exit-status || warn "빌드가 실패했습니다. 아래 로그를 확인하세요."
  echo
  gh run list --repo "$OWNER/$REPO" --limit 1
else
  warn "워크플로 자동 실행에 실패했습니다."
  info "저장소 → Actions 탭 → 'APK 빌드' → Run workflow 로 직접 실행해 주세요."
fi

echo
echo "  저장소   : https://github.com/$OWNER/$REPO"
echo "  Actions  : https://github.com/$OWNER/$REPO/actions"
echo
echo "  APK 는 실행 화면 아래 Artifacts 에서 내려받습니다."
echo "  (Codespaces 안에서 이미 빌드했다면 out/ 폴더의 APK 를 그냥 쓰셔도 됩니다)"
echo
