const input = document.getElementById("inputText");
const output = document.getElementById("outputText");
const outputPreview = document.getElementById("outputTextPreview");
const chatPaste = document.getElementById("chatPaste");
const chatOutput = document.getElementById("chatOutputText");
const chatOutputPreview = document.getElementById("chatOutputTextPreview");
const chatFileInput = document.getElementById("chatFileInput");
const classicFileInput = document.getElementById("classicFileInput");
const excerptStartTextEl = document.getElementById("excerptStartText");
const excerptEndTextEl = document.getElementById("excerptEndText");
const epubEditPanel = document.getElementById("epubEditPanel");
const epubEditFileInput = document.getElementById("epubEditFileInput");
const epubEditEditor = document.getElementById("epubEditEditor");
const epubFindTextEl = document.getElementById("epubFindText");
const epubReplaceTextEl = document.getElementById("epubReplaceText");
const epubEditFontSizeEl = document.getElementById("epubEditFontSize");
const epubEditTextColorEl = document.getElementById("epubEditTextColor");
const epubEditTextColorREl = document.getElementById("epubEditTextColorR");
const epubEditTextColorGEl = document.getElementById("epubEditTextColorG");
const epubEditTextColorBEl = document.getElementById("epubEditTextColorB");
const epubQuoteColorEl = document.getElementById("epubQuoteColor");
const epubQuoteColorREl = document.getElementById("epubQuoteColorR");
const epubQuoteColorGEl = document.getElementById("epubQuoteColorG");
const epubQuoteColorBEl = document.getElementById("epubQuoteColorB");
const quoteContextMenuEl = document.getElementById("quoteContextMenu");
const quoteUnwrapBtnEl = document.getElementById("quoteUnwrapBtn");
const epubFontInputEl = document.getElementById("epubFontInput");
const classicFileNameEl = document.getElementById("classicFileName");
const chatFileNameEl = document.getElementById("chatFileName");
const epubEditFileNameEl = document.getElementById("epubEditFileName");
const epubFontFileNameEl = document.getElementById("epubFontFileName");
const epubCoverFileNameEl = document.getElementById("epubCoverFileName");

const removeDetailsEl = document.getElementById("removeDetails");
const removeEmptyLinesEl = document.getElementById("removeEmptyLines");
const removeCellEmptyLinesEl = document.getElementById("removeCellEmptyLines");
const removeHTMLEl = document.getElementById("removeHTML");
const removeDecorEl = document.getElementById("removeDecor");
const protectEnabledEl = document.getElementById("protectEnabled");
const protectTokenEl = document.getElementById("protectToken");
const quoteStyleEl = document.getElementById("quoteStyle");
const indentOutputEl = document.getElementById("indentOutput");
const deleteContainsEnabledEl = document.getElementById("deleteContainsEnabled");
const deleteContainsTokenEl = document.getElementById("deleteContainsToken");
const deleteContainsModeEl = document.getElementById("deleteContainsMode");
const middleRangePanelEl = document.getElementById("middleRangePanel");
const removeTablesEl = document.getElementById("removeTables");
const labelSpeakersEl = document.getElementById("labelSpeakers");
const userNameEl = document.getElementById("userName");
const characterNameEl = document.getElementById("characterName");
const reviewDuplicatesEl = document.getElementById("reviewDuplicates");
const reviewOocPairsEl = document.getElementById("reviewOocPairs");
const oocCascadeModeEl = document.getElementById("oocCascadeMode");
const speakerMarkerPresetEl = document.getElementById("speakerMarkerPreset");
const speakerMarkerCustomEl = document.getElementById("speakerMarkerCustom");
const speakerLabelColorEl = document.getElementById("speakerLabelColor");
const speakerUserColorEl = document.getElementById("speakerUserColor");
const speakerCharacterColorEl = document.getElementById("speakerCharacterColor");
const speakerColorTargetEl = document.getElementById("speakerColorTarget");
const speakerLabelModeEl = document.getElementById("speakerLabelMode");
const resultStatsEl = document.getElementById("resultStats");
const riskPanelEl = document.getElementById("riskPanel");
const chapterPreviewEl = document.getElementById("chapterPreview");
const epubPreviewEl = document.getElementById("epubPreview");
const workflowHintEl = document.getElementById("workflowHint");
const epubTitleEl = document.getElementById("epubTitle");
const epubSubtitleEl = document.getElementById("epubSubtitle");
const epubAuthorEl = document.getElementById("epubAuthor");
const epubSeriesEl = document.getElementById("epubSeries");
const epubVolumeEl = document.getElementById("epubVolume");
const epubDescriptionEl = document.getElementById("epubDescription");
const epubTagsEl = document.getElementById("epubTags");
const epubLanguageEl = document.getElementById("epubLanguage");
const epubCoverInputEl = document.getElementById("epubCoverInput");
const chapterSplitModeEl = document.getElementById("chapterSplitMode");
const chapterSizeEl = document.getElementById("chapterSize");
const chapterSeparatorEl = document.getElementById("chapterSeparator");
const chapterTitlePrefixEl = document.getElementById("chapterTitlePrefix");
const chapterFirstTitleEl = document.getElementById("chapterFirstTitle");
const chapterKeywordInputEl = document.getElementById("chapterKeywordInput");
const chapterOrderInputEl = document.getElementById("chapterOrderInput");
const chapterPositionEl = document.getElementById("chapterPosition");
const chapterDividerPanelEl = document.getElementById("chapterDividerPanel");
const chapterTocInlineEl = document.getElementById("chapterTocInline");
const epubStylePresetEl = document.getElementById("epubStylePreset");
const epubTextModeEl = document.getElementById("epubTextMode");
const duplicateReviewPanel = document.getElementById("duplicateReviewPanel");
const containsReviewPanel = document.getElementById("containsReviewPanel");
const oocReviewPanel = document.getElementById("oocReviewPanel");
const chatOptions = document.getElementById("chatOptions");
const classicPanel = document.getElementById("classicPanel");
const chatPanel = document.getElementById("chatPanel");
const speakerOnlyEls = document.querySelectorAll(".speakerOnly");
const downloadFileNameEls = document.querySelectorAll(".downloadFileNameInput");

let activeMode = "classic";
let duplicateDecisions = {};
let containsDecisions = {};
let oocDecisions = {};
let currentDuplicateGroups = [];
let currentParsedBlocks = [];
let lastStructuredItems = [];
let savedEditorRange = null;
let currentContainsItems = [];
let containsOpenGroups = new Set();
let containsOpenTouched = false;
let currentOocItems = [];
let duplicatePageByGroup = {};
let duplicateGroupPage = 0;
let duplicateFilterText = "";
let duplicateOrderQuery = "";
let oocGroupPage = 0;
let oocFilterText = "";
let oocOrderQuery = "";
let middleRangeRules = [];
let cachedChatFileName = "";
let cachedCoverAsset = null;
let isRestoringWork = false;
let autosaveTimer = null;
let chapterKeywordQuery = "";
let chapterOrderQuery = "";
let chapterMatchPage = 0;
let currentChapterMatches = [];
let classicLoadedFileText = "";
let classicLoadedChunks = null;
let classicActiveChunks = null;
let classicActiveDisplayText = "";
let isApplyingClassicExcerpt = false;
let cachedEpubEditFileName = "";
let cachedEpubFontAsset = null;
let downloadFileBaseName = "";
let quoteLongPressTimer = null;
let quoteLongPressMeta = null;
let currentQuoteMenuTarget = null;


function wirePrettyFileInputs(){
  document.querySelectorAll('label.prettyFile, .fileControl').forEach(label => {
    const fileInput = label.querySelector('input[type="file"]');
    if(!fileInput || label.dataset.fileWired === '1') return;
    label.dataset.fileWired = '1';
    label.setAttribute('tabindex', label.getAttribute('tabindex') || '0');
    label.setAttribute('role', 'button');
    label.addEventListener('click', ev => {
      if(ev.target === fileInput) return;
      ev.preventDefault();
      fileInput.click();
    });
    label.addEventListener('keydown', ev => {
      if(ev.key === 'Enter' || ev.key === ' '){
        ev.preventDefault();
        fileInput.click();
      }
    });
  });
}
wirePrettyFileInputs();

function clampColorByte(v){
  const n = parseInt(v, 10);
  if(!Number.isFinite(n)) return 0;
  return Math.max(0, Math.min(255, n));
}
function componentToHex(v){ return clampColorByte(v).toString(16).padStart(2, "0"); }
function rgbToHex(r,g,b){ return `#${componentToHex(r)}${componentToHex(g)}${componentToHex(b)}`; }
function hexToRgb(hex){
  const m = String(hex || "").trim().match(/^#?([0-9a-fA-F]{6})$/);
  if(!m) return {r:0,g:0,b:0};
  const n = parseInt(m[1], 16);
  return {r:(n>>16)&255, g:(n>>8)&255, b:n&255};
}
function updateColorSwatch(colorInput){
  if(!colorInput) return;
  document.querySelectorAll(`[data-swatch="${colorInput.id}"]`).forEach(sw => sw.style.setProperty("--swatch", colorInput.value));
  if(colorInput === epubQuoteColorEl) updateQuoteColorPreview();
}
function syncRgbFromColor(colorInput, rEl, gEl, bEl){
  if(!colorInput) return;
  const rgb = hexToRgb(colorInput.value);
  if(rEl) rEl.value = rgb.r;
  if(gEl) gEl.value = rgb.g;
  if(bEl) bEl.value = rgb.b;
  updateColorSwatch(colorInput);
}
function syncColorFromRgb(colorInput, rEl, gEl, bEl){
  if(!colorInput) return;
  colorInput.value = rgbToHex(rEl && rEl.value, gEl && gEl.value, bEl && bEl.value);
  updateColorSwatch(colorInput);
}
function setupColorWidget(colorInput, rEl, gEl, bEl){
  if(!colorInput) return;
  colorInput.addEventListener("input", () => { syncRgbFromColor(colorInput, rEl, gEl, bEl); scheduleAutosave(); });
  [rEl,gEl,bEl].forEach(el => { if(el) el.addEventListener("input", () => { syncColorFromRgb(colorInput, rEl, gEl, bEl); scheduleAutosave(); }); });
  syncRgbFromColor(colorInput, rEl, gEl, bEl);
}
function updateQuoteColorPreview(){
  const color = epubQuoteColorEl ? epubQuoteColorEl.value : "#4f8aa4";
  document.querySelectorAll(".quotePresetList").forEach(el => el.style.setProperty("--quote-color", color));
}
setupColorWidget(epubEditTextColorEl, epubEditTextColorREl, epubEditTextColorGEl, epubEditTextColorBEl);
setupColorWidget(epubQuoteColorEl, epubQuoteColorREl, epubQuoteColorGEl, epubQuoteColorBEl);
[speakerUserColorEl, speakerCharacterColorEl].forEach(el => {
  if(!el) return;
  el.addEventListener("input", () => { updateColorSwatch(el); transformText(); scheduleAutosave(); });
  updateColorSwatch(el);
});

input.addEventListener("input", () => {
  if(!isApplyingClassicExcerpt) classicActiveChunks = null;
  transformText();
  scheduleAutosave();
});
if(classicFileInput) classicFileInput.addEventListener("change", e => { updateFileNameLabel(classicFileInput, classicFileNameEl); loadClassicFile(); });
if(epubCoverInputEl) epubCoverInputEl.addEventListener("change", e => { updateFileNameLabel(epubCoverInputEl, epubCoverFileNameEl, "선택 없음"); });
[excerptStartTextEl, excerptEndTextEl].forEach(el => { if(el) el.addEventListener("input", scheduleAutosave); });
if(epubEditEditor) epubEditEditor.addEventListener("input", () => { updateResultStats([], [], getActiveOutputValue()); updateEpubPreview(); scheduleAutosave(); });
if(epubEditEditor) epubEditEditor.addEventListener("scroll", () => scheduleAutosave(), {passive:true});
if(epubEditFileInput) epubEditFileInput.addEventListener("change", e => { updateFileNameLabel(epubEditFileInput, epubEditFileNameEl); loadEpubEditFile(); });
if(epubEditEditor){
  ["mouseup","keyup","touchend","pointerup"].forEach(ev => epubEditEditor.addEventListener(ev, rememberEditorSelection));
  document.addEventListener("selectionchange", () => { if(activeMode === "epubedit") rememberEditorSelection(); });
  epubEditEditor.addEventListener("input", () => { rememberEditorSelection(); scheduleAutosave(); updateEpubPreview(); });
  epubEditEditor.addEventListener("pointerdown", handleQuotePointerDown);
  epubEditEditor.addEventListener("pointermove", handleQuotePointerMove);
  epubEditEditor.addEventListener("contextmenu", handleQuoteContextMenu);
  ["pointerup","pointercancel","pointerleave","scroll"].forEach(ev => epubEditEditor.addEventListener(ev, clearQuoteLongPressTimer));
}
if(quoteUnwrapBtnEl) quoteUnwrapBtnEl.addEventListener("click", () => {
  if(currentQuoteMenuTarget && epubEditEditor && epubEditEditor.contains(currentQuoteMenuTarget)) unwrapQuoteBlock(currentQuoteMenuTarget);
  hideQuoteContextMenu();
});
document.addEventListener("click", e => { if(quoteContextMenuEl && !quoteContextMenuEl.contains(e.target)) hideQuoteContextMenu(); });
document.addEventListener("keydown", e => { if(e.key === "Escape") hideQuoteContextMenu(); });
if(epubFontInputEl) epubFontInputEl.addEventListener("change", e => { updateFileNameLabel(epubFontInputEl, epubFontFileNameEl, "선택 없음"); loadEpubFontFile(); });
downloadFileNameEls.forEach(el => {
  el.addEventListener("input", () => {
    downloadFileBaseName = el.value || "";
    syncDownloadFileNameInputs(el);
    scheduleAutosave();
  });
});
chatPaste.addEventListener("input", () => {
  resetReviewDecisions();
  transformText();
  scheduleAutosave();
});
chatPaste.addEventListener("paste", handleRichPaste);
[output, chatOutput].forEach(el => {
  if(!el) return;
  el.addEventListener("scroll", () => scheduleAutosave(), {passive:true});
  const preview = resultPreviewFor(el);
  if(preview) preview.addEventListener("scroll", () => scheduleAutosave(), {passive:true});
});

[
  removeDetailsEl,
  removeEmptyLinesEl,
  removeCellEmptyLinesEl,
  removeHTMLEl,
  removeDecorEl,
  protectEnabledEl,
  quoteStyleEl,
  indentOutputEl,
  deleteContainsEnabledEl,
  deleteContainsModeEl,
  removeTablesEl,
  labelSpeakersEl,
  reviewDuplicatesEl,
  reviewOocPairsEl,
  oocCascadeModeEl,
  speakerMarkerPresetEl,
  speakerColorTargetEl
].forEach(el => el.addEventListener("change", transformText));

protectTokenEl.addEventListener("input", transformText);
deleteContainsTokenEl.addEventListener("input", transformText);
userNameEl.addEventListener("input", transformText);
characterNameEl.addEventListener("input", transformText);
speakerMarkerCustomEl.addEventListener("input", transformText);
if(speakerLabelColorEl) speakerLabelColorEl.addEventListener("input", transformText);
if(speakerLabelModeEl) speakerLabelModeEl.addEventListener("change", transformText);
[
  epubTitleEl, epubSubtitleEl, epubAuthorEl, epubSeriesEl, epubVolumeEl,
  epubDescriptionEl, epubTagsEl, epubLanguageEl, chapterSplitModeEl, chapterSizeEl,
  chapterSeparatorEl, chapterTitlePrefixEl, chapterFirstTitleEl, epubStylePresetEl, epubTextModeEl, epubCoverInputEl
].forEach(el => {
  if(!el) return;
  el.addEventListener(el.tagName === "SELECT" || el.type === "file" ? "change" : "input", () => updateEpubPreview());
});

[chapterKeywordInputEl, chapterOrderInputEl].forEach(el => {
  if(!el) return;
  el.addEventListener("input", () => {
    if(el === chapterKeywordInputEl) chapterKeywordQuery = el.value || "";
    if(el === chapterOrderInputEl) chapterOrderQuery = el.value || "";
    chapterMatchPage = 0;
    updateChapterDividerPanel();
    scheduleAutosave();
  });
  el.addEventListener("keydown", e => {
    if(e.key === "Enter"){ e.preventDefault(); chapterMatchPage = 0; updateChapterDividerPanel(); }
  });
});
if(chapterPositionEl) chapterPositionEl.addEventListener("change", () => { updateChapterDividerPanel(); scheduleAutosave(); });
if(chapterDividerPanelEl) chapterDividerPanelEl.addEventListener("click", handleChapterDividerClick);
chatFileInput.addEventListener("change", e => { updateFileNameLabel(chatFileInput, chatFileNameEl); loadChatFile(); });
duplicateReviewPanel.addEventListener("change", handleDuplicateReviewChange);
duplicateReviewPanel.addEventListener("click", handleDuplicateReviewClick);
duplicateReviewPanel.addEventListener("input", handleDuplicateReviewInput);
duplicateReviewPanel.addEventListener("keydown", handleDuplicateReviewKeydown);
containsReviewPanel.addEventListener("change", handleContainsReviewChange);
containsReviewPanel.addEventListener("click", handleContainsReviewClick);
containsReviewPanel.addEventListener("toggle", handleContainsReviewToggle, true);
oocReviewPanel.addEventListener("change", handleOocReviewChange);
oocReviewPanel.addEventListener("click", handleOocReviewClick);
oocReviewPanel.addEventListener("input", handleOocReviewInput);
oocReviewPanel.addEventListener("keydown", handleOocReviewKeydown);
if(middleRangePanelEl){
  middleRangePanelEl.addEventListener("input", handleMiddleRangeInput);
  middleRangePanelEl.addEventListener("change", handleMiddleRangeInput);
  middleRangePanelEl.addEventListener("click", handleMiddleRangeClick);
}


function updateModeVisibility(){
  const showSpeakerOptions = true;
  speakerOnlyEls.forEach(el => el.classList.toggle("hidden", !showSpeakerOptions));
}


// ------------------ 작업 자동 저장 ------------------
const WORK_DB_NAME = "rofan-cleaner-work-cache";
const WORK_STORE_NAME = "work";
const WORK_STATE_KEY = "current";
const WORK_META_KEY = "rofan-cleaner-work-meta";
const WORK_FALLBACK_KEY = "rofan-cleaner-work-fallback";

function openWorkDB(){
  return new Promise((resolve, reject) => {
    if(!window.indexedDB){ reject(new Error("IndexedDB not supported")); return; }
    const req = indexedDB.open(WORK_DB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if(!db.objectStoreNames.contains(WORK_STORE_NAME)) db.createObjectStore(WORK_STORE_NAME);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error || new Error("IndexedDB open error"));
  });
}
function idbPut(key, value){
  return openWorkDB().then(db => new Promise((resolve, reject) => {
    const tx = db.transaction(WORK_STORE_NAME, "readwrite");
    tx.objectStore(WORK_STORE_NAME).put(value, key);
    tx.oncomplete = () => { db.close(); resolve(); };
    tx.onerror = () => { db.close(); reject(tx.error || new Error("IndexedDB write error")); };
  }));
}
function idbGet(key){
  return openWorkDB().then(db => new Promise((resolve, reject) => {
    const tx = db.transaction(WORK_STORE_NAME, "readonly");
    const req = tx.objectStore(WORK_STORE_NAME).get(key);
    req.onsuccess = () => resolve(req.result || null);
    req.onerror = () => reject(req.error || new Error("IndexedDB read error"));
    tx.oncomplete = () => db.close();
  }));
}
function idbDelete(key){
  return openWorkDB().then(db => new Promise((resolve, reject) => {
    const tx = db.transaction(WORK_STORE_NAME, "readwrite");
    tx.objectStore(WORK_STORE_NAME).delete(key);
    tx.oncomplete = () => { db.close(); resolve(); };
    tx.onerror = () => { db.close(); reject(tx.error || new Error("IndexedDB delete error")); };
  }));
}
function collectWorkValues(){
  return {
    version: 5,
    savedAt: new Date().toISOString(),
    activeMode,
    classicInput: input ? input.value : "",
    classicLoadedFileText,
    classicLoadedChunks,
    classicActiveChunks,
    classicActiveDisplayText,
    excerptStartText: excerptStartTextEl ? excerptStartTextEl.value : "",
    excerptEndText: excerptEndTextEl ? excerptEndTextEl.value : "",
    epubEditHTML: epubEditEditor ? epubEditEditor.innerHTML : "",
    epubEditScroll: epubEditEditor ? epubEditEditor.scrollTop : 0,
    cachedEpubEditFileName,
    cachedEpubFontAsset,
    downloadFileBaseName,
    classicOutput: output ? output.value : "",
    classicOutputScroll: output ? getResultOutputScroll(output) : 0,
    chatHTML: chatPaste ? chatPaste.innerHTML : "",
    chatOutputValue: chatOutput ? chatOutput.value : "",
    chatOutputScroll: chatOutput ? getResultOutputScroll(chatOutput) : 0,
    cachedChatFileName,
    options: collectPresetValues(),
    duplicateDecisions,
    containsDecisions,
    oocDecisions,
    duplicatePageByGroup,
    duplicateGroupPage,
    duplicateFilterText,
    duplicateOrderQuery,
    oocGroupPage,
    oocFilterText,
    oocOrderQuery,
    middleRangeRules: sanitizeMiddleRangeRules(middleRangeRules),
    chapterKeywordQuery,
    chapterOrderQuery,
    chapterMatchPage,
    cachedCoverAsset
  };
}
function applyActiveModeFromState(mode){
  activeMode = mode === "chat" || mode === "epubedit" ? mode : "classic";
  document.querySelectorAll(".tab").forEach(t => {
    const on = t.dataset.tab === activeMode;
    t.classList.toggle("active", on);
    t.setAttribute("aria-selected", on ? "true" : "false");
  });
  classicPanel.classList.toggle("hidden", activeMode !== "classic");
  chatPanel.classList.toggle("hidden", activeMode !== "chat");
  if(epubEditPanel) epubEditPanel.classList.toggle("hidden", activeMode !== "epubedit");
  chatOptions.classList.remove("hidden");
  updateModeVisibility();
}
async function saveWorkNow(){
  if(isRestoringWork) return;
  const state = collectWorkValues();
  try{
    await idbPut(WORK_STATE_KEY, state);
    localStorage.setItem(WORK_META_KEY, JSON.stringify({savedAt: state.savedAt, fileName: cachedChatFileName || "", mode: activeMode}));
    updateAutosaveBadge("자동 저장됨");
  }catch(err){
    try{
      localStorage.setItem(WORK_FALLBACK_KEY, JSON.stringify(state));
      localStorage.setItem(WORK_META_KEY, JSON.stringify({savedAt: state.savedAt, fileName: cachedChatFileName || "", mode: activeMode, fallback:true}));
      updateAutosaveBadge("자동 저장됨");
    }catch(err2){
      console.warn("autosave failed", err, err2);
      updateAutosaveBadge("저장 실패");
    }
  }
}
function scheduleAutosave(){
  if(isRestoringWork) return;
  updateAutosaveBadge("저장 중…");
  clearTimeout(autosaveTimer);
  autosaveTimer = setTimeout(saveWorkNow, 500);
}
function updateAutosaveBadge(text){
  const el = document.getElementById("autosaveStatus");
  if(!el) return;
  let suffix = "";
  const raw = localStorage.getItem(WORK_META_KEY);
  if(raw){
    try{
      const meta = JSON.parse(raw);
      if(meta.savedAt){
        const d = new Date(meta.savedAt);
        if(!Number.isNaN(d.getTime())) suffix = ` · ${String(d.getHours()).padStart(2,"0")}:${String(d.getMinutes()).padStart(2,"0")}`;
      }
      if(meta.fileName) suffix += ` · ${meta.fileName}`;
    }catch(_err){}
  }
  el.textContent = text + suffix;
}
function restoreOutputScrollFromState(state){
  if(!state) return;
  requestAnimationFrame(() => {
    if(output && Number.isFinite(Number(state.classicOutputScroll))) setResultOutputScroll(output, Number(state.classicOutputScroll) || 0);
    if(chatOutput && Number.isFinite(Number(state.chatOutputScroll))) setResultOutputScroll(chatOutput, Number(state.chatOutputScroll) || 0);
    if(epubEditEditor && Number.isFinite(Number(state.epubEditScroll))) epubEditEditor.scrollTop = Number(state.epubEditScroll) || 0;
  });
}
async function restoreSavedWork(){
  isRestoringWork = true;
  let state = null;
  try{ state = await idbGet(WORK_STATE_KEY); }catch(_err){}
  if(!state){
    const fallback = localStorage.getItem(WORK_FALLBACK_KEY);
    if(fallback){
      try{ state = JSON.parse(fallback); }catch(_err){}
    }
  }
  if(state){
    try{
      const restoredOptions = Object.assign({}, state.options || {});
      if((!state.version || state.version < 4) && restoredOptions.chapterSeparator === "---") restoredOptions.chapterSeparator = "—————";
      applyPresetValues(restoredOptions);
      if(input) input.value = state.classicInput || "";
      classicLoadedFileText = state.classicLoadedFileText || "";
      classicLoadedChunks = Array.isArray(state.classicLoadedChunks) ? state.classicLoadedChunks : null;
      classicActiveChunks = Array.isArray(state.classicActiveChunks) ? state.classicActiveChunks : null;
      classicActiveDisplayText = state.classicActiveDisplayText || "";
      if(excerptStartTextEl) excerptStartTextEl.value = state.excerptStartText || "";
      if(excerptEndTextEl) excerptEndTextEl.value = state.excerptEndText || "";
      if(epubEditEditor) epubEditEditor.innerHTML = state.epubEditHTML || "";
      cachedEpubEditFileName = state.cachedEpubEditFileName || "";
      cachedEpubFontAsset = state.cachedEpubFontAsset || null;
      downloadFileBaseName = state.downloadFileBaseName || "";
      syncDownloadFileNameInputs();
      if(cachedEpubFontAsset) applyCachedEpubFont();
      if(chatPaste) chatPaste.innerHTML = state.chatHTML || "";
      cachedChatFileName = state.cachedChatFileName || "";
      cachedCoverAsset = state.cachedCoverAsset || null;
      duplicateDecisions = state.duplicateDecisions || {};
      containsDecisions = state.containsDecisions || {};
      oocDecisions = state.oocDecisions || {};
      duplicatePageByGroup = state.duplicatePageByGroup || {};
      duplicateGroupPage = state.duplicateGroupPage || 0;
      duplicateFilterText = state.duplicateFilterText || "";
      duplicateOrderQuery = state.duplicateOrderQuery || "";
      oocGroupPage = state.oocGroupPage || 0;
      oocFilterText = state.oocFilterText || "";
      oocOrderQuery = state.oocOrderQuery || "";
      middleRangeRules = sanitizeMiddleRangeRules((state.options && state.options.middleRangeRules) || state.middleRangeRules || []);
      chapterKeywordQuery = state.chapterKeywordQuery || "";
      chapterOrderQuery = state.chapterOrderQuery || "";
      chapterMatchPage = state.chapterMatchPage || 0;
      if(chapterKeywordInputEl) chapterKeywordInputEl.value = chapterKeywordQuery;
      if(chapterOrderInputEl) chapterOrderInputEl.value = chapterOrderQuery;
      applyActiveModeFromState(state.activeMode || activeMode);
      updateAutosaveBadge("복원됨");
      showToast(cachedChatFileName ? `저장된 작업을 불러왔습니다: ${cachedChatFileName}` : "저장된 작업을 불러왔습니다.");
    }catch(err){
      console.error(err);
      updateAutosaveBadge("복원 실패");
    }
  }else{
    applyActiveModeFromState(activeMode);
    updateAutosaveBadge("자동 저장 대기");
  }
  isRestoringWork = false;
  transformText();
  if(state){
    if(output && state.classicOutput) setResultOutput(output, state.classicOutput);
    if(chatOutput && state.chatOutputValue) setResultOutput(chatOutput, state.chatOutputValue);
    restoreOutputScrollFromState(state);
  }
  updateResultStats([], [], getActiveOutputValue());
  updateEpubPreview();
  updateChapterDividerPanel();
  scheduleAutosave();
}
async function clearSavedWork(){
  if(!window.confirm("저장된 작업 캐시를 삭제하시겠습니까? 새로고침 복원 데이터도 함께 지워집니다.")) return;
  try{ await idbDelete(WORK_STATE_KEY); }catch(_err){}
  localStorage.removeItem(WORK_META_KEY);
  localStorage.removeItem(WORK_FALLBACK_KEY);
  cachedChatFileName = "";
  cachedCoverAsset = null;
  updateAutosaveBadge("캐시 삭제됨");
  showToast("저장된 작업 캐시를 삭제했습니다.");
}
function wireAutosave(){
  document.addEventListener("input", e => {
    if(e.target && e.target.closest && e.target.closest("#toast")) return;
    scheduleAutosave();
  }, true);
  document.addEventListener("change", e => {
    if(e.target === epubCoverInputEl) cacheCoverFile();
    scheduleAutosave();
  }, true);
  document.addEventListener("click", e => {
    if(e.target && e.target.closest && e.target.closest("button,.toggle,.tab,input[type='radio']")) scheduleAutosave();
  }, true);
}
async function cacheCoverFile(){
  const file = epubCoverInputEl && epubCoverInputEl.files && epubCoverInputEl.files[0];
  if(!file) return;
  if(file.size > 8 * 1024 * 1024){
    cachedCoverAsset = null;
    showToast("표지가 커서 자동 저장에서는 제외했습니다.");
    return;
  }
  const dataUrl = await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error || new Error("cover read error"));
    reader.readAsDataURL(file);
  });
  cachedCoverAsset = {name:file.name || "cover", type:file.type || "image/jpeg", dataUrl};
}
function dataUrlToUint8Array(dataUrl){
  const m = String(dataUrl || "").match(/^data:([^;,]+)?(;base64)?,(.*)$/);
  if(!m) return new Uint8Array();
  const is64 = !!m[2];
  const raw = is64 ? atob(m[3]) : decodeURIComponent(m[3]);
  return Uint8Array.from(raw, ch => ch.charCodeAt(0));
}

// 탭 전환
document.querySelectorAll(".tab").forEach(tab => {
  tab.addEventListener("click", () => {
    activeMode = tab.dataset.tab;
    document.querySelectorAll(".tab").forEach(t => {
      const on = t.dataset.tab === activeMode;
      t.classList.toggle("active", on);
      t.setAttribute("aria-selected", on ? "true" : "false");
    });
    classicPanel.classList.toggle("hidden", activeMode !== "classic");
    chatPanel.classList.toggle("hidden", activeMode !== "chat");
    if(epubEditPanel) epubEditPanel.classList.toggle("hidden", activeMode !== "epubedit");
    chatOptions.classList.remove("hidden");
    updateModeVisibility();
    transformText();
    scheduleAutosave();
  });
});

// ------------------ 공통 토큰 ------------------
function splitTokens(raw){
  return (raw || "")
    .split(",")
    .map(s => s.trim())
    .filter(Boolean);
}
function getProtectTokens(){
  if (!protectEnabledEl.checked) return [];
  return splitTokens(protectTokenEl.value || "");
}
function isProtectedText(t, tokens){
  if (!t || !tokens || tokens.length === 0) return false;
  return tokens.some(tok => tok && t.includes(tok));
}
function getDeleteContainsTokens(){
  if (!deleteContainsEnabledEl.checked) return [];
  return splitTokens(deleteContainsTokenEl.value || "");
}
function shouldDeleteByContains(t, tokens){
  if (!t || !tokens || tokens.length === 0) return false;
  const text = String(t);
  const lowerText = text.toLowerCase();
  return tokens.some(tok => {
    if(!tok) return false;
    const token = String(tok);
    return lowerText.includes(token.toLowerCase());
  });
}

function createMiddleRangeRule(data){
  const source = data || {};
  return {
    id: source.id || ("range-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 8)),
    start: String(source.start || ""),
    end: String(source.end || ""),
    action: "delete",
    unit: source.unit === "sentence" ? "sentence" : "paragraph"
  };
}
function sanitizeMiddleRangeRules(rules){
  if(!Array.isArray(rules)) return [];
  return rules.map(createMiddleRangeRule).filter(Boolean);
}
function ensureMiddleRangeRows(){
  if(!Array.isArray(middleRangeRules)) middleRangeRules = [];
  if(!middleRangeRules.length) middleRangeRules = [createMiddleRangeRule()];
}
function renderMiddleRangePanel(){
  if(!middleRangePanelEl) return;
  ensureMiddleRangeRows();
  middleRangePanelEl.innerHTML = middleRangeRules.map((rule, idx) => `
    <div class="middleRangeItem" data-middle-range-id="${escapeAttr(rule.id)}">
      <div class="middleRangeHead">
        <strong>범위 ${idx + 1}</strong>
        <span class="control compactControl">처리 <select data-middle-range-field="action"><option value="delete" selected>삭제</option></select></span>
        <span class="control compactControl">삭제 단위 <select data-middle-range-field="unit"><option value="paragraph" ${rule.unit !== "sentence" ? "selected" : ""}>키워드가 포함된 문단부터 삭제</option><option value="sentence" ${rule.unit === "sentence" ? "selected" : ""}>키워드가 포함된 문장부터 삭제</option></select></span>
        <button type="button" class="btn subtle warn" data-middle-range-remove="${escapeAttr(rule.id)}">범위 삭제</button>
      </div>
      <div class="middleRangeGrid">
        <label class="control wide">시작 문장<textarea data-middle-range-field="start" placeholder="삭제 범위가 시작되는 문장 전체를 붙여넣기">${escapeHTML(rule.start)}</textarea></label>
        <label class="control wide">끝 문장<textarea data-middle-range-field="end" placeholder="삭제 범위가 끝나는 문장 전체를 붙여넣기">${escapeHTML(rule.end)}</textarea></label>
      </div>
    </div>`).join("");
}
function addMiddleRangeRule(){
  ensureMiddleRangeRows();
  middleRangeRules.push(createMiddleRangeRule());
  renderMiddleRangePanel();
  scheduleAutosave();
}
function findMiddleRangeRule(id){
  return (middleRangeRules || []).find(rule => rule.id === id);
}
function handleMiddleRangeInput(e){
  const field = e.target && e.target.dataset ? e.target.dataset.middleRangeField : "";
  if(!field) return;
  const wrap = e.target.closest("[data-middle-range-id]");
  if(!wrap) return;
  const rule = findMiddleRangeRule(wrap.dataset.middleRangeId);
  if(!rule) return;
  if(field === "action") rule.action = "delete";
  else rule[field] = e.target.value || "";
  transformText();
  scheduleAutosave();
}
function handleMiddleRangeClick(e){
  const btn = e.target.closest("[data-middle-range-remove]");
  if(!btn) return;
  const id = btn.dataset.middleRangeRemove;
  middleRangeRules = (middleRangeRules || []).filter(rule => rule.id !== id);
  ensureMiddleRangeRows();
  renderMiddleRangePanel();
  transformText();
  scheduleAutosave();
}
function normalizeRangeNeedle(text){
  return String(text || "").replace(/\r/g, "").replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim();
}
function buildNormalizedTextMap(text){
  const source = String(text || "");
  let normalized = "";
  const map = [];
  let pendingSpace = false;
  let pendingSpaceIndex = 0;
  for(let i = 0; i < source.length; i++){
    const ch = source[i];
    if(/\s|\u00a0/.test(ch)){
      if(!pendingSpace){ pendingSpace = true; pendingSpaceIndex = i; }
      continue;
    }
    if(pendingSpace && normalized){ normalized += " "; map.push(pendingSpaceIndex); }
    pendingSpace = false;
    normalized += ch;
    map.push(i);
  }
  return { normalized, map };
}
function normalizedOriginalMatch(text, needle, fromOriginal){
  const built = buildNormalizedTextMap(text);
  const normalizedNeedle = normalizeRangeNeedle(needle);
  if(!built.normalized || !normalizedNeedle) return null;
  let fromNorm = 0;
  while(fromNorm < built.map.length && built.map[fromNorm] < (Number(fromOriginal) || 0)) fromNorm++;
  const pos = built.normalized.toLowerCase().indexOf(normalizedNeedle.toLowerCase(), fromNorm);
  if(pos < 0) return null;
  const last = Math.min(built.map.length - 1, pos + normalizedNeedle.length - 1);
  const start = built.map[pos];
  const end = built.map[last] + 1;
  return {pos:start, len:Math.max(1, end - start)};
}
function findRangeNeedleInChunks(chunks, needle, startIndex, startPos){
  const rawNeedle = String(needle || "").trim();
  if(!rawNeedle) return null;
  const normalizedNeedle = normalizeRangeNeedle(rawNeedle);
  if(!normalizedNeedle) return null;
  const fromIndex = Math.max(0, Number(startIndex) || 0);
  for(let i = fromIndex; i < chunks.length; i++){
    const text = String((chunks[i] && chunks[i].text) || "");
    const from = i === fromIndex ? Math.max(0, Number(startPos) || 0) : 0;
    const lowerText = text.toLowerCase();
    const lowerNeedle = rawNeedle.toLowerCase();
    let exact = text.indexOf(rawNeedle, from);
    if(exact < 0) exact = lowerText.indexOf(lowerNeedle, from);
    if(exact >= 0) return {index:i, pos:exact, len:rawNeedle.length, whole:false};
    const normalizedMatch = normalizedOriginalMatch(text, rawNeedle, from);
    if(normalizedMatch) return {index:i, pos:normalizedMatch.pos, len:normalizedMatch.len, whole:false};
  }
  return null;
}
function getSentenceBoundsForRange(text, pos, len){
  const s = String(text || "");
  const safePos = Math.max(0, Math.min(s.length, Number(pos) || 0));
  const safeEnd = Math.max(safePos, Math.min(s.length, safePos + (Number(len) || 0)));
  const sentenceEndChars = new Set([".", "?", "!", "。", "？", "！", "…", "\n"]);
  const closingChars = new Set(['"', "'", "”", "’", "」", "』", "〉", ")", "]", "}"]);
  let start = safePos;
  while(start > 0){
    const prev = s[start - 1];
    if(sentenceEndChars.has(prev)) break;
    start--;
  }
  while(start < s.length && /\s/.test(s[start])) start++;
  let end = safeEnd;
  while(end < s.length){
    const ch = s[end];
    end++;
    if(sentenceEndChars.has(ch)) break;
  }
  while(end < s.length && closingChars.has(s[end])) end++;
  while(end < s.length && /[ \t]/.test(s[end])) end++;
  return {start, end};
}
function deleteTextRangeInChunkText(text, start, end){
  const s = String(text || "");
  const from = Math.max(0, Math.min(s.length, start));
  const to = Math.max(from, Math.min(s.length, end));
  return (s.slice(0, from) + s.slice(to)).replace(/\n{3,}/g, "\n\n").trim();
}
function getActiveMiddleRangeRules(){
  return (middleRangeRules || [])
    .filter(rule => rule && rule.action !== "keep")
    .map(rule => ({
      start:String(rule.start || "").trim(),
      end:String(rule.end || "").trim(),
      unit: rule.unit === "sentence" ? "sentence" : "paragraph"
    }))
    .filter(rule => rule.start && rule.end);
}
function applyMiddleRangeDeletesToChunks(chunks){
  const rules = getActiveMiddleRangeRules();
  if(!rules.length || !Array.isArray(chunks) || !chunks.length) return chunks;
  let working = chunks.map(chunk => Object.assign({}, chunk));
  rules.forEach(rule => {
    const startInfo = findRangeNeedleInChunks(working, rule.start, 0, 0);
    if(!startInfo) return;
    const endInfo = findRangeNeedleInChunks(working, rule.end, startInfo.index, startInfo.pos + startInfo.len);
    if(!endInfo || endInfo.index < startInfo.index) return;

    if(rule.unit === "sentence"){
      if(startInfo.index === endInfo.index){
        const text = String((working[startInfo.index] && working[startInfo.index].text) || "");
        const startBounds = getSentenceBoundsForRange(text, startInfo.pos, startInfo.len);
        const endBounds = getSentenceBoundsForRange(text, endInfo.pos, endInfo.len);
        working[startInfo.index].text = deleteTextRangeInChunkText(text, startBounds.start, Math.max(startBounds.start, endBounds.end));
      }else{
        const startText = String((working[startInfo.index] && working[startInfo.index].text) || "");
        const endText = String((working[endInfo.index] && working[endInfo.index].text) || "");
        const startBounds = getSentenceBoundsForRange(startText, startInfo.pos, startInfo.len);
        const endBounds = getSentenceBoundsForRange(endText, endInfo.pos, endInfo.len);
        if(working[startInfo.index]) working[startInfo.index].text = deleteTextRangeInChunkText(startText, startBounds.start, startText.length);
        for(let i = startInfo.index + 1; i < endInfo.index; i++){
          if(working[i]) working[i].text = "";
        }
        if(working[endInfo.index]) working[endInfo.index].text = deleteTextRangeInChunkText(endText, 0, endBounds.end);
      }
    }else{
      for(let i = startInfo.index; i <= endInfo.index; i++){
        if(working[i]) working[i].text = "";
      }
    }
    working = working.filter(chunk => String((chunk && chunk.text) || "").trim());
  });
  return working;
}

function resetReviewDecisions(){
  duplicateDecisions = {};
  containsDecisions = {};
  oocDecisions = {};
  duplicatePageByGroup = {};
  duplicateGroupPage = 0;
  duplicateFilterText = "";
  duplicateOrderQuery = "";
  oocGroupPage = 0;
  oocFilterText = "";
  oocOrderQuery = "";
}

// ------------------ 기호/구분선 판정 ------------------
function getProtectedChapterSeparators(){
  const out = new Set();
  const sep = chapterSeparatorEl ? String(chapterSeparatorEl.value || "").trim() : "";
  const mode = chapterSplitModeEl ? chapterSplitModeEl.value : "";
  if(sep && mode === "separator") out.add(sep);
  return out;
}
function isProtectedChapterSeparatorLine(line, preserveSet){
  const s = (line || "").trim();
  return !!(s && preserveSet && preserveSet.has(s));
}
function isDecorOnlyLine(line, preserveSet){
  const s=(line||"").trim();
  if(!s) return false;
  if(isProtectedChapterSeparatorLine(s, preserveSet)) return false;
  if(/^[-*_—–]{3,}$/.test(s)) return true;
  if(/^[<>\[\]\(\){}|\\/·•….,:;'"`~!@#$%^&+=-]+$/.test(s)) return true;
  return false;
}
function isDecorOnlyParagraph(p, preserveSet){
  const lines=(p||"").split("\n").map(l=>l.trim()).filter(Boolean);
  if(!lines.length) return false;
  if(lines.some(l => isProtectedChapterSeparatorLine(l, preserveSet))) return false;
  return lines.every(l => isDecorOnlyLine(l, preserveSet));
}
function removeDecorLines(p, preserveSet){
  const kept = (p||"").split("\n").filter(l => !isDecorOnlyLine(l, preserveSet));
  return kept.join("\n").trim();
}
function shouldRemoveCellEmptyLines(){
  return !!(removeCellEmptyLinesEl && removeCellEmptyLinesEl.checked);
}
function normalizeBlankLinesInsideCell(text){
  if(removeEmptyLinesEl.checked || shouldRemoveCellEmptyLines()){
    return String(text || "").replace(/\n\s*\n+/g,"\n");
  }
  return text;
}
function isTableLikeText(t){
  const s = (t || "").trim();
  if (!s) return false;
  const pipeCount = (s.match(/\|/g) || []).length;
  if (pipeCount >= 2) return true;
  if (/^[\s|:.-]{3,}$/.test(s) && s.includes("|")) return true;
  return false;
}

// ------------------ details 제거 (기존 로그용, 보호 키워드 예외) ------------------
function filterDetailsByProtection(text, tokens){
  return (text || "").replace(/<details\b[\s\S]*?<\/details>/gi, (block) => {
    if (!tokens || tokens.length === 0) return "";
    let inner = block
      .replace(/<summary[\s\S]*?<\/summary>/gi, "")
      .replace(/<\/?details[^>]*>/gi, "");
    const paras = inner.split(/\n\s*\n+/).map(p => p.trim()).filter(Boolean);
    const kept = paras.filter(p => isProtectedText(p, tokens));
    if (kept.length === 0) return "";
    return "\n\n" + kept.join("\n\n") + "\n\n";
  })
  .replace(/^\s*<\/?details.*?>\s*$/gim, "")
  .replace(/^\s*<summary.*?>.*?<\/summary>\s*$/gim, "");
}

// ------------------ 별표 지문 파서(기존 로그용) ------------------
function parseChunks(text){
  const s=(text||"").replace(/\r/g,"");
  const out=[];
  let i=0, normal="";

  const flush=()=>{
    if(!normal) return;
    normal.split(/\n\s*\n+/).map(p=>p.trim()).filter(Boolean)
      .forEach((p, idx)=>out.push({id:"classic-" + out.length + "-" + idx, kind:"normal", text:p, owner:"character", color:"", fromTable:false, fromDetails:false, blockId:"classic-" + out.length}));
    normal="";
  };

  while(i<s.length){
    if(s[i]!=="*"){ normal+=s[i++]; continue; }

    flush();
    i++;

    let content="";
    while(i<s.length && s[i]!=="*"){ content+=s[i++]; }
    if(i<s.length && s[i]==="*") i++;

    out.push({id:"classic-" + out.length, kind:"scene", text:content.trim(), owner:"user", color:"", fromTable:false, fromDetails:false, blockId:"classic-" + out.length});

    while(i<s.length && (s[i]===" " || s[i]==="\t" || s[i]==="\n")){
      i++;
      if(i<s.length && s[i]==="*") break;
    }
  }

  flush();
  return out;
}

// ------------------ 따옴표 ------------------
function getQuotes(style){
  if(style==="straight") return ['"', '"'];
  if(style==="doubleCurly") return ['“', '”'];
  if(style==="singleCurly") return ['‘', '’'];
  return ["",""];
}
function isAlreadyQuoted(t){
  const pairs=[['"','"'],['“','”'],['‘','’']];
  return pairs.some(([o,c])=>t.startsWith(o) && t.endsWith(c) && t.length>=2);
}
function getSpeakerName(owner){
  if(owner === "user") return (userNameEl.value || "").trim() || "유저";
  if(owner === "character") return (characterNameEl.value || "").trim() || "캐릭터";
  return "";
}
function getSpeakerMarker(){
  const preset = speakerMarkerPresetEl ? speakerMarkerPresetEl.value : "none";
  if(preset === "none") return "";
  if(preset === "custom") return (speakerMarkerCustomEl.value || "").trim();
  return preset;
}
function wrapColorHTML(text, color){
  const safeColor = /^#[0-9a-f]{6}$/i.test(color || "") ? color : "#17181c";
  return `<span style="color:${safeColor}">${escapeHTML(text)}</span>`;
}
function speakerColorForOwner(owner){
  const fallback = speakerLabelColorEl && speakerLabelColorEl.value ? speakerLabelColorEl.value : "#4f849c";
  const el = owner === "user" ? speakerUserColorEl : owner === "character" ? speakerCharacterColorEl : null;
  const value = el && el.value ? el.value : fallback;
  return /^#[0-9a-f]{6}$/i.test(value || "") ? value : "#4f849c";
}
function makeSpeakerLabel(chunk){
  if(!(activeMode === "chat" || activeMode === "classic")) return "";
  if(!labelSpeakersEl.checked || !chunk.owner) return "";
  const name = getSpeakerName(chunk.owner);
  if(!name) return "";
  const marker = getSpeakerMarker();
  const colorTarget = speakerColorTargetEl ? speakerColorTargetEl.value : "none";
  const color = speakerColorForOwner(chunk.owner);
  if(colorTarget === "marker" && marker){
    return wrapColorHTML(marker, color) + name;
  }
  const label = marker + name;
  if(colorTarget === "all") return wrapColorHTML(label, color);
  return label;
}
function labelChunk(text, chunk, shouldLabel){
  if(!shouldLabel) return text;
  const label = makeSpeakerLabel(chunk);
  if(!label) return text;
  return label + "\n" + text;
}

// ------------------ 로판Ai 저장 파일 불러오기 ------------------
function activateChatTab(){
  activeMode = "chat";
  document.querySelectorAll(".tab").forEach(t => {
    const on = t.dataset.tab === activeMode;
    t.classList.toggle("active", on);
    t.setAttribute("aria-selected", on ? "true" : "false");
  });
  classicPanel.classList.add("hidden");
  chatPanel.classList.remove("hidden");
  if(epubEditPanel) epubEditPanel.classList.add("hidden");
  chatOptions.classList.remove("hidden");
  updateModeVisibility();
}
function readFileAsArrayBuffer(file){
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error || new Error("file read error"));
    reader.readAsArrayBuffer(file);
  });
}
function isZipBytes(bytes){
  return bytes && bytes.length >= 4 && bytes[0] === 0x50 && bytes[1] === 0x4b;
}

function bytesToBinaryString(bytes){
  const arr = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes || []);
  let out = "";
  const step = 0x8000;
  for(let i = 0; i < arr.length; i += step){
    out += String.fromCharCode.apply(null, arr.subarray(i, i + step));
  }
  return out;
}
function binaryStringToBytes(str){
  const s = String(str || "");
  const bytes = new Uint8Array(s.length);
  for(let i = 0; i < s.length; i++) bytes[i] = s.charCodeAt(i) & 0xff;
  return bytes;
}
function mimeAsciiHead(bytes){
  const arr = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes || []);
  return bytesToBinaryString(arr.subarray(0, Math.min(arr.length, 65536)));
}
function normalizeCharsetLabel(label){
  const raw = String(label || "").trim().replace(/^['\"]|['\"]$/g, "").toLowerCase();
  if(!raw) return "";
  const aliases = {
    "utf8":"utf-8",
    "utf_8":"utf-8",
    "unicode":"utf-16le",
    "utf16":"utf-16le",
    "utf-16":"utf-16le",
    "utf16le":"utf-16le",
    "utf16be":"utf-16be",
    "cp949":"windows-949",
    "x-windows-949":"windows-949",
    "ks_c_5601-1987":"euc-kr",
    "ks_c_5601-1989":"euc-kr",
    "ksc5601":"euc-kr",
    "ksc_5601":"euc-kr",
    "gb2312":"gb18030",
    "gbk":"gb18030",
    "x-gbk":"gb18030",
    "sjis":"shift_jis",
    "shift-jis":"shift_jis",
    "x-sjis":"shift_jis",
    "ms932":"shift_jis"
  };
  return aliases[raw] || raw;
}
function uniqueList(list){
  const seen = new Set();
  return (list || []).filter(v => {
    const key = normalizeCharsetLabel(v);
    if(!key || seen.has(key)) return false;
    seen.add(key);
    return true;
  }).map(normalizeCharsetLabel);
}
function decodedTextScore(text){
  const s = String(text || "");
  let score = 0;
  score += (s.match(/\uFFFD/g) || []).length * 100000;
  score += (s.match(/\u0000/g) || []).length * 10000;
  score += (s.match(/[\u0001-\u0008\u000B\u000C\u000E-\u001F]/g) || []).length * 2000;
  score += (s.match(/[ÃÂìëíê]/g) || []).length * 25;
  score -= (s.match(/<html\b|<body\b|<div\b|<p\b/gi) || []).length * 100;
  score -= Math.min((s.match(/[\uAC00-\uD7A3]/g) || []).length, 2000);
  return score;
}
function decodeBytesWithCharset(bytes, charsetHint){
  const arr = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes || []);
  const bom = arr.length >= 2 && arr[0] === 0xff && arr[1] === 0xfe ? "utf-16le" :
    arr.length >= 2 && arr[0] === 0xfe && arr[1] === 0xff ? "utf-16be" :
    arr.length >= 3 && arr[0] === 0xef && arr[1] === 0xbb && arr[2] === 0xbf ? "utf-8" : "";
  const candidates = uniqueList([bom, charsetHint, "utf-8", "utf-16le", "utf-16be", "windows-949", "euc-kr", "gb18030", "big5", "shift_jis", "windows-1252"]);
  let best = "";
  let bestScore = Infinity;
  candidates.forEach(label => {
    try{
      const decoded = new TextDecoder(label).decode(arr).replace(/^\uFEFF/, "");
      const score = decodedTextScore(decoded);
      if(score < bestScore){ best = decoded; bestScore = score; }
    }catch(_err){}
  });
  return best || new TextDecoder("utf-8").decode(arr).replace(/^\uFEFF/, "");
}
function extractCharsetFromHeaders(headers){
  const h = String(headers || "").replace(/\r?\n[ \t]+/g, " ");
  const m = h.match(/charset\s*=\s*(?:"([^"]+)"|'([^']+)'|([^;\s]+))/i);
  return normalizeCharsetLabel((m && (m[1] || m[2] || m[3])) || "");
}
function extractCharsetFromHtml(text){
  const s = String(text || "");
  const direct = s.match(/<meta\s+[^>]*charset\s*=\s*(?:"([^"]+)"|'([^']+)'|([^\s"'>;]+))/i);
  if(direct) return normalizeCharsetLabel(direct[1] || direct[2] || direct[3] || "");
  const httpEquiv = s.match(/<meta\s+[^>]*http-equiv\s*=\s*(?:"content-type"|'content-type'|content-type)[^>]*content\s*=\s*(?:"([^"]+)"|'([^']+)'|([^>\s]+))/i);
  return httpEquiv ? extractCharsetFromHeaders("Content-Type: " + (httpEquiv[1] || httpEquiv[2] || httpEquiv[3] || "")) : "";
}
function decodeBytesSmart(bytes){
  return decodeBytesWithCharset(bytes, "");
}

async function loadChatFile(){
  const file = chatFileInput.files && chatFileInput.files[0];
  if(!file) return;

  try{
    const buffer = await readFileAsArrayBuffer(file);
    const bytes = new Uint8Array(buffer);
    const lowerName = (file.name || "").toLowerCase();
    const mimeHead = mimeAsciiHead(bytes);
    const looksMHT = /\.(mht|mhtml)$/i.test(lowerName) || /MIME-Version:\s*1\.0/i.test(mimeHead) || /Content-Type:\s*multipart\/related/i.test(mimeHead);

    if(isZipBytes(bytes) || /\.zip$/i.test(lowerName)){
      chatFileInput.value = "";
      showToast("ZIP 파일은 변환 대상이 아닙니다. MHT/HTML/Markdown/TXT 파일을 선택해 주세요.");
      return;
    }

    const raw = looksMHT ? "" : decodeBytesSmart(bytes);
    const looksHTML = !looksMHT && /<!doctype\s+html\b|<html\b|<body\b|<(div|p|span)\b/i.test(raw);
    const looksStructuredMarkdown = !looksMHT && (/<!--\s*rofan:/i.test(raw) || /\.(md|markdown)$/i.test(lowerName));
    const allowedExt = /\.(mht|mhtml|html|htm|md|markdown|txt)$/i.test(lowerName);

    if(!allowedExt && !looksMHT && !looksHTML && !looksStructuredMarkdown){
      chatFileInput.value = "";
      showToast("지원하지 않는 파일입니다. .mht/.html/.md/.txt 파일을 선택해 주세요.");
      return;
    }

    let sanitized = "";
    if(looksMHT){
      const html = extractHTMLFromMHTBytes(bytes) || extractHTMLFromMHT(decodeBytesSmart(bytes));
      if(!html || !looksLikeHTML(html)){
        showToast("파일 안에서 HTML 채팅 내용을 찾지 못했습니다.");
        return;
      }
      sanitized = sanitizePastedHTML(extractLikelyChatHTML(html));
    }else if(looksStructuredMarkdown){
      sanitized = structuredMarkdownToHtml(raw) || plainTextToHtml(raw);
    }else if(looksHTML){
      sanitized = sanitizePastedHTML(extractLikelyChatHTML(raw));
    }else{
      sanitized = plainTextToHtml(raw);
    }
    if(!htmlToPlainText(sanitized)){
      showToast("불러온 파일에서 변환할 텍스트를 찾지 못했습니다.");
      return;
    }

    activateChatTab();
    resetReviewDecisions();
    chatPaste.innerHTML = sanitized;
    // 접힌 <details> 는 innerText 로 읽히지 않는다. 불러오는 즉시 펴 둔다.
    openAllFolds(chatPaste);
    cachedChatFileName = file.name || "저장 파일";
    transformText();
    updateChapterDividerPanel();
    scheduleAutosave();
    showToast("파일을 불러왔습니다.");
  }catch(err){
    console.error(err);
    showToast("파일을 읽지 못했습니다.");
  }
}

function looksLikeHTML(text){
  return /<!doctype\s+html\b|<html\b|<body\b|<(div|p|span|br|i|em|details|table)\b/i.test(String(text || ""));
}
function decodeBase64Bytes(str){
  const cleaned = String(str || "").replace(/[^A-Za-z0-9+/=]/g, "");
  if(!cleaned) return new Uint8Array();
  const binary = atob(cleaned);
  const bytes = new Uint8Array(binary.length);
  for(let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i) & 0xff;
  return bytes;
}
function decodeQuotedPrintableBytes(str){
  const qp = String(str || "").replace(/=\r?\n/g, "");
  const bytes = [];
  for(let i = 0; i < qp.length; i++){
    if(qp[i] === "=" && /^[0-9a-fA-F]{2}$/.test(qp.slice(i + 1, i + 3))){
      bytes.push(parseInt(qp.slice(i + 1, i + 3), 16));
      i += 2;
    }else{
      bytes.push(qp.charCodeAt(i) & 0xff);
    }
  }
  return Uint8Array.from(bytes);
}
function decodeMimeBody(headers, bodyBinary){
  const unfolded = String(headers || "").replace(/\r?\n[ \t]+/g, " ");
  const encMatch = unfolded.match(/Content-Transfer-Encoding:\s*([^\r\n;]+)/i);
  const enc = encMatch ? encMatch[1].trim().toLowerCase() : "";
  const headerCharset = extractCharsetFromHeaders(unfolded);
  let bodyBytes;
  if(enc.includes("base64")) bodyBytes = decodeBase64Bytes(bodyBinary);
  else if(enc.includes("quoted-printable")) bodyBytes = decodeQuotedPrintableBytes(bodyBinary);
  else bodyBytes = binaryStringToBytes(bodyBinary);

  let decoded = decodeBytesWithCharset(bodyBytes, headerCharset);
  if(!headerCharset){
    const metaCharset = extractCharsetFromHtml(decoded);
    if(metaCharset) decoded = decodeBytesWithCharset(bodyBytes, metaCharset);
  }
  return decoded.replace(/^\uFEFF/, "");
}
function extractHTMLFromMHTBytes(bytes){
  const arr = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes || []);
  if(!arr.length) return "";
  const binary = bytesToBinaryString(arr);
  const head = binary.slice(0, Math.min(binary.length, 131072)).replace(/\r?\n[ \t]+/g, " ");
  const boundaryMatch = head.match(/boundary=(?:"([^"]+)"|([^;\r\n]+))/i);
  if(!boundaryMatch) return "";
  const boundary = (boundaryMatch[1] || boundaryMatch[2] || "").trim();
  if(!boundary) return "";
  const parts = binary.split("--" + boundary);
  const htmlParts = [];
  for(const part of parts){
    const sepMatch = part.match(/\r?\n\r?\n/);
    if(!sepMatch) continue;
    const sepIndex = sepMatch.index;
    const sepLength = sepMatch[0].length;
    const headers = part.slice(0, sepIndex).replace(/^\r?\n/, "");
    const unfolded = headers.replace(/\r?\n[ \t]+/g, " ");
    if(!/Content-Type:\s*text\/html\b/i.test(unfolded)) continue;
    let bodyBinary = part.slice(sepIndex + sepLength);
    bodyBinary = bodyBinary.replace(/\r?\n--\s*$/g, "");
    const body = decodeMimeBody(headers, bodyBinary);
    if(body) htmlParts.push(body);
  }
  if(htmlParts.length){
    htmlParts.sort((a,b) => scoreHTMLPart(b) - scoreHTMLPart(a));
    return htmlParts[0];
  }
  return "";
}
function extractHTMLFromMHT(raw){
  const text = String(raw || "");
  const boundaryMatch = text.match(/boundary=(?:"([^"]+)"|([^;\r\n]+))/i);
  if(boundaryMatch){
    const boundary = (boundaryMatch[1] || boundaryMatch[2] || "").trim();
    const parts = text.split("--" + boundary);
    const htmlParts = [];
    for(const part of parts){
      const sepMatch = part.match(/\r?\n\r?\n/);
      if(!sepMatch) continue;
      const sepIndex = sepMatch.index;
      const sepLength = sepMatch[0].length;
      const headers = part.slice(0, sepIndex);
      const unfolded = headers.replace(/\r?\n[ \t]+/g, " ");
      if(!/Content-Type:\s*text\/html\b/i.test(unfolded)) continue;
      let body = part.slice(sepIndex + sepLength).replace(/\r?\n--\s*$/g, "");
      const encMatch = unfolded.match(/Content-Transfer-Encoding:\s*([^\r\n;]+)/i);
      const enc = encMatch ? encMatch[1].trim().toLowerCase() : "";
      const charset = extractCharsetFromHeaders(unfolded);
      if(enc.includes("base64")) body = decodeBytesWithCharset(decodeBase64Bytes(body), charset);
      else if(enc.includes("quoted-printable")) body = decodeBytesWithCharset(decodeQuotedPrintableBytes(body), charset);
      htmlParts.push(body);
    }
    if(htmlParts.length){
      htmlParts.sort((a,b) => scoreHTMLPart(b) - scoreHTMLPart(a));
      return htmlParts[0];
    }
  }

  const docMatch = text.match(/<!doctype\s+html[\s\S]*$/i) || text.match(/<html[\s\S]*$/i) || text.match(/<body[\s\S]*$/i);
  return docMatch ? docMatch[0] : text;
}
function scoreHTMLPart(part){
  const s = String(part || "");
  let score = Math.min(s.length, 500000);
  if(/<!doctype\s+html|<html\b/i.test(s)) score += 500000;
  score += (s.match(/data-narration/gi) || []).length * 1000;
  score += (s.match(/class=["'][^"']*mt-1/gi) || []).length * 1000;
  score -= decodedTextScore(s);
  return score;
}
function decodeBase64UTF8(str){
  return decodeBytesWithCharset(decodeBase64Bytes(str), "utf-8");
}
function decodeQuotedPrintableUTF8(str){
  return decodeBytesWithCharset(decodeQuotedPrintableBytes(str), "utf-8");
}
function extractLikelyChatHTML(html){
  const doc = new DOMParser().parseFromString(html || "", "text/html");
  // 로판AI 발췌본은 어느 부분이 본문인지 이미 표시돼 있다. 짐작하지 말고 그대로 쓴다.
  const marked = doc.querySelector('[data-rofan-export]');
  if(marked) return marked.innerHTML;
  const scoreContainer = (el) => {
    if(!el) return 0;
    const textLen = (el.innerText || el.textContent || "").length;
    const pCount = el.querySelectorAll ? el.querySelectorAll("p").length : 0;
    const replyCount = el.querySelectorAll ? el.querySelectorAll("div.mt-1").length : 0;
    const narrationCount = el.querySelectorAll ? el.querySelectorAll("[data-narration]").length : 0;
    return replyCount * 100000 + narrationCount * 20000 + pCount * 1000 + Math.min(textLen, 100000);
  };

  const overflowCandidates = Array.from(doc.querySelectorAll("div"))
    .filter(el => /overflow-y-auto/.test(String(el.className || "")));
  if(overflowCandidates.length){
    overflowCandidates.sort((a,b) => scoreContainer(b) - scoreContainer(a));
    const container = overflowCandidates[0];
    const children = Array.from(container.children || []).filter(el => scoreContainer(el) > 0);
    if(children.length){
      children.sort((a,b) => scoreContainer(b) - scoreContainer(a));
      return children[0].innerHTML || children[0].outerHTML;
    }
    return container.innerHTML;
  }

  const candidates = Array.from(doc.querySelectorAll("main, section, article, div"));
  candidates.push(doc.body);
  candidates.sort((a,b) => scoreContainer(b) - scoreContainer(a));
  const best = candidates.find(el => scoreContainer(el) > 0) || doc.body;
  return best ? best.innerHTML : html;
}
function htmlToPlainText(html){
  const temp = document.createElement("div");
  temp.innerHTML = html || "";
  return (temp.innerText || temp.textContent || "").trim();
}

// ------------------ 로판Ai 전체 채팅방 붙여넣기 ------------------
function handleRichPaste(e){
  const data = e.clipboardData || window.clipboardData;
  if(!data) return;

  const html = data.getData("text/html");
  const text = data.getData("text/plain");

  if(html){
    e.preventDefault();
    resetReviewDecisions();
    insertHtmlAtCursor(sanitizePastedHTML(html));
    transformText();
    return;
  }

  if(text){
    e.preventDefault();
    resetReviewDecisions();
    insertHtmlAtCursor(escapeHTML(text).replace(/\n/g,"<br>"));
    transformText();
  }
}
// 접힘 토큰과 그 안쪽이 화면에서 감춰져 있으면 innerText 로 읽을 때 통째로 빠진다.
// 불러온 직후 접힘을 펴고 숨김 표시를 벗겨, 코드와 내용이 그대로 살아 있게 한다.
function openAllFolds(root){
  if(!root || !root.querySelectorAll) return;
  try{
    root.querySelectorAll("details").forEach(d => { d.open = true; d.setAttribute("open",""); });
    root.querySelectorAll("[hidden]").forEach(d => d.removeAttribute("hidden"));
    root.querySelectorAll('[aria-hidden="true"]').forEach(d => d.removeAttribute("aria-hidden"));
    root.querySelectorAll('[style*="display"],[style*="visibility"]').forEach(d => {
      const v = String(d.getAttribute("style") || "")
        .replace(/display\s*:\s*none\s*;?/gi, "")
        .replace(/visibility\s*:\s*hidden\s*;?/gi, "");
      if(v.trim()) d.setAttribute("style", v); else d.removeAttribute("style");
    });
    root.querySelectorAll("[class]").forEach(d => {
      const kept = String(d.getAttribute("class") || "").split(/\s+/)
        .filter(c => c && !/^(hidden|invisible)$/.test(c));
      if(kept.length) d.setAttribute("class", kept.join(" ")); else d.removeAttribute("class");
    });
  }catch(_err){}
}
function sanitizePastedHTML(html){
  const doc = new DOMParser().parseFromString(html || "", "text/html");
  doc.querySelectorAll("script,style,meta,link,iframe,object,embed").forEach(n => n.remove());
  doc.body.querySelectorAll("*").forEach(el => {
    [...el.attributes].forEach(attr => {
      const name = attr.name.toLowerCase();
      const value = String(attr.value || "").trim().toLowerCase();
      if(name.startsWith("on")) el.removeAttribute(attr.name);
      if((name === "href" || name === "src") && value.startsWith("javascript:")) el.removeAttribute(attr.name);
    });
  });
  return doc.body.innerHTML;
}
function insertHtmlAtCursor(html){
  chatPaste.focus();
  const selection = window.getSelection();
  if(!selection || selection.rangeCount === 0){
    chatPaste.insertAdjacentHTML("beforeend", html);
    return;
  }
  const range = selection.getRangeAt(0);
  range.deleteContents();
  const temp = document.createElement("div");
  temp.innerHTML = html;
  const frag = document.createDocumentFragment();
  let node, lastNode = null;
  while((node = temp.firstChild)){
    lastNode = frag.appendChild(node);
  }
  range.insertNode(frag);
  openAllFolds(chatPaste);
  if(lastNode){
    range.setStartAfter(lastNode);
    range.collapse(true);
    selection.removeAllRanges();
    selection.addRange(range);
  }
}
function escapeHTML(str){
  return String(str || "")
    .replace(/&/g,"&amp;")
    .replace(/</g,"&lt;")
    .replace(/>/g,"&gt;")
    .replace(/"/g,"&quot;")
    .replace(/'/g,"&#039;");
}
function escapeAttr(str){
  return escapeHTML(str).replace(/`/g,"&#096;");
}
function htmlFromResultText(text){
  const escaped = escapeHTML(text || "");
  // 결과창은 안전하게 escape한 뒤, 이 앱이 만든 제한적인 span 색상 태그만 다시 렌더링합니다.
  // HTML/Markdown/EPUB 내보내기에는 raw 값이 그대로 쓰입니다.
  return escaped.replace(/&lt;span\b([\s\S]*?)&gt;([\s\S]*?)&lt;\/span&gt;/gi, (match, rawAttrs, inner) => {
    const attrs = String(rawAttrs || "");
    const colorMatch = attrs.match(/color\s*:\s*(#[0-9a-fA-F]{6})/i);
    const color = colorMatch ? colorMatch[1] : "";
    const ownerMatch = attrs.match(/data-speaker-owner=&quot;([a-zA-Z_-]+)&quot;/i);
    const hasSpeakerClass = /speaker-label/i.test(attrs);
    const attrParts = [];
    if(hasSpeakerClass) attrParts.push('class="speaker-label"');
    if(ownerMatch) attrParts.push(`data-speaker-owner="${escapeAttr(ownerMatch[1])}"`);
    if(color) attrParts.push(`style="color:${color}"`);
    if(!attrParts.length) return inner;
    return `<span ${attrParts.join(" ")}>${inner}</span>`;
  });
}
function resultPreviewFor(el){
  if(el === output) return outputPreview;
  if(el === chatOutput) return chatOutputPreview;
  return null;
}
function syncResultPreview(el){
  const preview = resultPreviewFor(el);
  if(!preview || !el) return;
  const oldScroll = preview.scrollTop;
  preview.innerHTML = htmlFromResultText(el.value || "");
  preview.dataset.placeholder = el.getAttribute("placeholder") || "변환 결과";
  preview.scrollTop = oldScroll;
}
function setResultOutput(el, value){
  if(!el) return;
  el.value = value || "";
  syncResultPreview(el);
}
function getResultOutputScroll(el){
  const preview = resultPreviewFor(el);
  return preview ? preview.scrollTop : (el ? el.scrollTop : 0);
}
function setResultOutputScroll(el, value){
  const preview = resultPreviewFor(el);
  const v = Number(value) || 0;
  if(preview) preview.scrollTop = v;
  if(el) el.scrollTop = v;
}

function syncActiveResultHeight(){
  const panel = activeMode === "chat" ? chatPanel : activeMode === "classic" ? classicPanel : null;
  if(!panel || panel.classList.contains("hidden")) return;
  if(window.matchMedia && window.matchMedia("(max-width: 860px)").matches) return;
  const grid = panel.querySelector(".editorGrid");
  const left = panel.querySelector(".editorGrid > .editorBox:not(.resultBox)");
  const resultBox = panel.querySelector(".editorGrid > .editorBox.resultBox");
  const preview = resultBox ? resultBox.querySelector(".richResultBox") : null;
  const label = resultBox ? resultBox.querySelector(".editorLabel") : null;
  if(!grid || !left || !resultBox || !preview) return;
  const leftRect = left.getBoundingClientRect();
  const labelHeight = label ? Math.ceil(label.getBoundingClientRect().height) : 0;
  const target = Math.max(320, Math.round(leftRect.height) - labelHeight - 9);
  resultBox.style.minHeight = Math.round(leftRect.height) + "px";
  preview.style.setProperty("--synced-result-height", target + "px");
  preview.style.height = target + "px";
  preview.style.maxHeight = target + "px";
}
function isItalicElement(el){
  if(!el || el.nodeType !== 1) return false;
  const dataKind = String(el.getAttribute("data-kind") || "").toLowerCase();
  if(/scene|narration|지문/.test(dataKind)) return true;
  if(/normal|dialogue|대사/.test(dataKind)) return false;
  const tag = el.tagName;
  if(tag === "I" || tag === "EM" || tag === "CITE") return true;
  if(String(el.getAttribute("data-narration") || "").toLowerCase() === "true") return true;

  const style = (el.getAttribute("style") || "").toLowerCase();
  if(/font-style\s*:\s*italic/.test(style)) return true;
  if(/font-style\s*:\s*oblique/.test(style)) return true;

  const className = String(el.className || "").toLowerCase();
  if(/\b(italic|italics|emphasis)\b/.test(className)) return true;

  try{
    const computed = window.getComputedStyle(el);
    if(computed && (computed.fontStyle === "italic" || computed.fontStyle === "oblique")) return true;
  }catch(_err){}

  return false;
}
function isBlockElement(el){
  if(!el || el.nodeType !== 1) return false;
  const blockTags = new Set([
    "ADDRESS","ARTICLE","ASIDE","BLOCKQUOTE","DD","DETAILS","DIALOG","DIV","DL","DT",
    "FIELDSET","FIGCAPTION","FIGURE","FOOTER","FORM","H1","H2","H3","H4","H5","H6",
    "HEADER","HR","LI","MAIN","NAV","OL","P","PRE","SECTION","SUMMARY","TABLE","TBODY",
    "TD","TFOOT","TH","THEAD","TR","UL"
  ]);
  if(blockTags.has(el.tagName)) return true;
  const role = (el.getAttribute("role") || "").toLowerCase();
  return ["article","paragraph","row","table","grid","list","listitem"].includes(role);
}
function isTableElement(el){
  if(!el || el.nodeType !== 1) return false;
  if(["TABLE","TBODY","TFOOT","THEAD","TR","TD","TH","CAPTION","COL","COLGROUP"].includes(el.tagName)) return true;
  const role = (el.getAttribute("role") || "").toLowerCase();
  if(["table","grid","row","cell","columnheader","rowheader"].includes(role)) return true;
  const className = String(el.className || "").toLowerCase();
  if(/\b(table|grid)\b/.test(className)) return true;
  return false;
}
function isRemovableBlockText(text){
  const s = normalizeParagraphText(text || "");
  if(!s) return false;
  if(/^🩸?\s*기록지/.test(s) || /^기록지/.test(s)) return true;
  if(isTableLikeText(s)) return true;
  return false;
}
function isRemovableBlockElement(el){
  if(!el || el.nodeType !== 1) return false;
  if(isTableElement(el)) return true;
  const text = (el.innerText || el.textContent || "").trim();
  if(/^🩸?\s*기록지/.test(text) || /^기록지/.test(text)) return true;
  return false;
}
function isSkippableElement(el){
  if(!el || el.nodeType !== 1) return false;
  if(["SCRIPT","STYLE","META","LINK","NOSCRIPT","IFRAME","OBJECT","EMBED","SVG","CANVAS","BUTTON","INPUT","TEXTAREA","SELECT","OPTION"].includes(el.tagName)) return true;
  const ariaHidden = (el.getAttribute("aria-hidden") || "").toLowerCase();
  const hidden = el.hasAttribute("hidden") || ariaHidden === "true";
  if(hidden) return true;
  const className = String(el.className || "").toLowerCase();
  if(/(^|\s)(select-none|sr-only|hidden|invisible)(\s|$)/.test(className)) return true;
  const style = String(el.getAttribute("style") || "").toLowerCase().replace(/\s+/g, "");
  if(/display:none/.test(style) || /visibility:hidden/.test(style)) return true;
  const title = el.getAttribute("title") || "";
  if(["북마크 추가", "분기 생성"].includes(title)) return true;
  return false;
}
function normalizeParagraphText(text){
  return (text || "")
    .replace(/\u00a0/g," ")
    .replace(/[ \t]+/g," ")
    .replace(/\s+([,.!?;:])/g,"$1")
    .trim();
}
function normalizeColorValue(value){
  let v = String(value || "").trim().replace(/!important/ig, "");
  if(!v) return "";
  const hex = v.match(/^#([0-9a-f]{3}|[0-9a-f]{6}|[0-9a-f]{8})$/i);
  if(hex){
    let h = hex[1];
    if(h.length === 3) h = h.split("").map(ch => ch + ch).join("");
    if(h.length === 8) h = h.slice(0,6);
    return "#" + h.toUpperCase();
  }
  const rgb = v.match(/^rgba?\(([^)]+)\)$/i);
  if(rgb){
    const nums = rgb[1].split(",").slice(0,3).map(x => Math.max(0, Math.min(255, parseInt(x, 10) || 0)));
    if(nums.length === 3) return "#" + nums.map(n => n.toString(16).padStart(2,"0")).join("").toUpperCase();
  }
  const named = {white:"#FFFFFF", black:"#000000", yellow:"#FFFF00", gray:"#808080", grey:"#808080"};
  return named[v.toLowerCase()] || v.toLowerCase();
}
function getInlineColor(el){
  if(!el || el.nodeType !== 1) return "";
  const style = el.getAttribute("style") || "";
  const colorMatch = style.match(/(?:^|;)\s*color\s*:\s*([^;]+)/i);
  if(colorMatch) return normalizeColorValue(colorMatch[1]);
  const colorAttr = el.getAttribute("color");
  if(colorAttr) return normalizeColorValue(colorAttr);
  const className = String(el.className || "");
  const arbitrary = className.match(/text-\[#([0-9a-f]{3,8})\]/i);
  if(arbitrary) return normalizeColorValue("#" + arbitrary[1]);
  const cls = className.toLowerCase();
  if(/\btext-white\b/.test(cls)) return "#FFFFFF";
  if(/\btext-indigo-400\b/.test(cls)) return "#818CF8";
  if(/\btext-yellow-400\b/.test(cls)) return "#FACC15";
  if(/\btext-neutral-400\b|\btext-zinc-400\b/.test(cls)) return "#A3A3A3";
  if(/\btext-neutral-200\b|\btext-zinc-200\b/.test(cls)) return "#E5E5E5";
  return "";
}
function ownerFromColor(color, className){
  const c = normalizeColorValue(color || "");
  const cls = String(className || "").toLowerCase();
  if(["#818CF8", "#A3A3A3", "#A5B4FC", "#6366F1"].includes(c)) return "user";
  if(["#FFFFFF", "#FFC200", "#FACC15", "#EAB308", "#FEF08A", "#E5E5E5"].includes(c)) return "character";
  if(/\btext-indigo-/.test(cls)) return "user";
  if(/\btext-white\b|\btext-yellow-|\btext-amber-/.test(cls)) return "character";
  return "";
}
function ownerLabel(owner){
  if(owner === "user") return getSpeakerName("user");
  if(owner === "character") return getSpeakerName("character");
  return "구분 없음";
}
function getElementKindHint(el){
  if(!el || el.nodeType !== 1) return "";
  const dataKind = String(el.getAttribute("data-kind") || "").toLowerCase();
  if(/scene|narration|지문/.test(dataKind)) return "scene";
  if(/normal|dialogue|대사/.test(dataKind)) return "normal";
  return "";
}
function getElementBlockId(el){
  if(!el || el.nodeType !== 1) return "";
  return (el.getAttribute("data-block-id") || el.getAttribute("data-block") || "").trim();
}

function getElementOwnerHint(el, color){
  if(!el || el.nodeType !== 1) return "";
  const dataOwner = String(el.getAttribute("data-owner") || "").toLowerCase();
  if(/user|human|me|내|유저/.test(dataOwner)) return "user";
  if(/assistant|ai|character|bot|캐릭터/.test(dataOwner)) return "character";
  const author = String(el.getAttribute("data-author") || el.getAttribute("data-message-author") || el.getAttribute("data-role") || "").toLowerCase();
  if(/user|human|me|내|유저/.test(author)) return "user";
  if(/assistant|ai|character|bot|캐릭터/.test(author)) return "character";
  const className = String(el.className || "");
  if(/(^|\s)mt-1(\s|$)/.test(className)) return "character";

  // 로판Ai 저장본은 같은 p 태그 안에서도 글자색으로 유저/캐릭터 시점이 갈립니다.
  // 그래서 p 태그를 무조건 유저로 보지 않고, 색상 단서를 먼저 믿습니다.
  const byColor = ownerFromColor(color, className);
  if(byColor) return byColor;

  if(el.tagName === "P") return "user";
  return "";
}
function isUiOnlyText(text){
  const s = normalizeParagraphText(text);
  if(!s) return true;
  if(/^\d+\s*\/\s*\d+$/.test(s)) return true;
  if(/^(복사|삭제|수정|북마크|분기|다시 생성|재생성)$/.test(s)) return true;
  return false;
}
function hasSkippableAncestor(el, root){
  let cur = el.parentElement;
  while(cur && cur !== root){
    if(isSkippableElement(cur)) return true;
    cur = cur.parentElement;
  }
  return false;
}
function collectRofanContentBlocks(root){
  const blocks = [];
  // 기본 대화는 p / div.mt-1로 잡히지만, MHT 저장본의 첫 캐릭터 메시지는
  // p로 감싸지지 않고 색상 span만 있는 경우가 있어 함께 후보에 넣습니다.
  // 부모 p가 이미 잡힌 span은 아래 contains 검사로 중복 제거됩니다.
  const candidates = Array.from(root.querySelectorAll('[data-owner][data-kind], .rofan-block, p, div.mt-1, span[style*="color"], div[style*="color"]'));
  candidates.forEach((el, index) => {
    if(blocks.some(b => b.el.contains(el))) return;
    if(isSkippableElement(el) || hasSkippableAncestor(el, root)) return;
    const text = normalizeParagraphText(el.innerText || el.textContent || "");
    if(isUiOnlyText(text)) return;
    const color = getInlineColor(el);
    const owner = getElementOwnerHint(el, color);
    if(!owner) return;

    // 같은 색상 span 안에 실제 문단 전체가 있고, 그 안에 장식용 작은 span이 다시 들어가는 구조가 많습니다.
    // 이미 선택된 더 큰 메시지 후보 안의 요소는 건너뛰고, 반대로 현재 요소가 앞서 잡은 작은 조각을 포함하면
    // 큰 메시지를 남기도록 작은 조각을 제거합니다.
    for(let i=blocks.length-1; i>=0; i--){
      if(el.contains(blocks[i].el)){
        blocks.splice(i, 1);
      }
    }
    blocks.push({el, owner, index});
  });
  return blocks;
}
function parseRofanChatChunks(root){
  const chunks = [];
  const blocks = [];
  let chunkSeq = 0;
  let blockSeq = 0;

  const pushChunksFromElement = (el, baseOwner) => {
    const blockId = getElementBlockId(el) || ("b" + (blockSeq++));
    const baseKind = getElementKindHint(el);
    const start = chunks.length;
    let buffer = "";
    let bufferKind = null;
    let bufferOwner = baseOwner || "";
    let bufferColor = "";
    let bufferFromTable = false;
    let bufferFromDetails = false;

    const flush = () => {
      const text = normalizeParagraphText(buffer);
      if(text){
        chunks.push({
          id: "c" + (chunkSeq++),
          kind: bufferKind || baseKind || "normal",
          text,
          owner: bufferOwner || "",
          color: bufferColor || "",
          fromTable: bufferFromTable,
          fromDetails: bufferFromDetails,
          blockId
        });
      }
      buffer = "";
      bufferKind = null;
      bufferOwner = baseOwner || "";
      bufferColor = "";
      bufferFromTable = false;
      bufferFromDetails = false;
    };

    const addInlineText = (text, ctx) => {
      const raw = String(text || "").replace(/\r/g,"");
      if(!raw) return;
      const kind = ctx.kind || (ctx.italic ? "scene" : "normal");
      const owner = ctx.owner || ownerFromColor(ctx.color, "") || "";
      const parts = raw.split("\n");
      parts.forEach((part, idx) => {
        const normalized = part.replace(/\u00a0/g," ").replace(/[ \t]+/g," ");
        if(normalized){
          if(buffer && ((bufferKind && bufferKind !== kind) || (bufferOwner && owner && bufferOwner !== owner))) flush();
          if(!bufferKind) bufferKind = kind;
          if(!bufferOwner && owner) bufferOwner = owner;
          if(!bufferColor && ctx.color) bufferColor = ctx.color;
          buffer += normalized;
          if(ctx.fromTable) bufferFromTable = true;
          if(ctx.fromDetails) bufferFromDetails = true;
        }
        if(idx < parts.length - 1) flush();
      });
    };

    const walk = (node, ctx) => {
      if(!node) return;
      if(node.nodeType === Node.TEXT_NODE){
        addInlineText(node.nodeValue, ctx);
        return;
      }
      if(node.nodeType !== Node.ELEMENT_NODE) return;

      const childEl = node;
      if(isSkippableElement(childEl)) return;

      if(childEl.tagName === "BR"){
        flush();
        return;
      }

      const color = getInlineColor(childEl) || ctx.color || "";
      const ownerHint = getElementOwnerHint(childEl, color);
      const nextCtx = {
        italic: ctx.italic || isItalicElement(childEl),
        kind: getElementKindHint(childEl) || ctx.kind || "",
        fromTable: ctx.fromTable || isRemovableBlockElement(childEl),
        fromDetails: ctx.fromDetails || childEl.tagName === "DETAILS",
        owner: ownerHint || ctx.owner || "",
        color
      };

      const block = isBlockElement(childEl) && childEl !== el;
      if(block) flush();
      Array.from(childEl.childNodes).forEach(child => walk(child, nextCtx));
      if(block) flush();
    };

    Array.from(el.childNodes).forEach(child => walk(child, {
      italic: isItalicElement(el),
      kind: baseKind || "",
      fromTable: isRemovableBlockElement(el),
      fromDetails: el.tagName === "DETAILS",
      owner: baseOwner || getElementOwnerHint(el, getInlineColor(el)) || "",
      color: getInlineColor(el) || ""
    }));
    flush();

    const blockText = chunks.slice(start).map(c => c.text).join("\n\n").trim();
    if(blockText){
      blocks.push({id:blockId, owner:baseOwner || "", text:blockText, startChunk:start, endChunk:chunks.length});
    }else{
      chunks.splice(start);
    }
  };

  const semanticBlocks = collectRofanContentBlocks(root);
  if(semanticBlocks.length){
    semanticBlocks.forEach(block => pushChunksFromElement(block.el, block.owner));
  }else{
    pushChunksFromElement(root, "");
  }

  const mergedBlocks = mergeRofanBlocksById(blocks, chunks);
  blocks.splice(0, blocks.length, ...mergedBlocks);
  preserveLeadingCharacterBlocks(blocks, chunks);
  const responseBlocks = normalizeResponseBlocks(blocks, chunks);
  blocks.splice(0, blocks.length, ...responseBlocks);
  return {chunks, blocks};
}

function mergeRofanBlocksById(blocks, chunks){
  if(!blocks || !blocks.length) return blocks || [];
  const map = new Map();
  const order = [];
  blocks.forEach(block => {
    const id = block && block.id;
    if(!id) return;
    if(!map.has(id)){
      map.set(id, {id, owner:block.owner || "", text:"", startChunk:block.startChunk, endChunk:block.endChunk});
      order.push(id);
    }else{
      const cur = map.get(id);
      if(!cur.owner && block.owner) cur.owner = block.owner;
      cur.startChunk = Math.min(cur.startChunk, block.startChunk);
      cur.endChunk = Math.max(cur.endChunk, block.endChunk);
    }
  });
  return order.map(id => {
    const b = map.get(id);
    const related = (chunks || []).filter(c => c.blockId === id);
    if(related.length){
      b.owner = b.owner || (related.find(c => c.owner) || {}).owner || "";
      b.text = related.map(c => c.text).filter(Boolean).join("\n\n").trim();
      const positions = related.map(c => (chunks || []).indexOf(c)).filter(i => i >= 0);
      if(positions.length){ b.startChunk = Math.min(...positions); b.endChunk = Math.max(...positions) + 1; }
    }
    return b;
  }).filter(b => b.text);
}

function preserveLeadingCharacterBlocks(blocks, chunks){
  // 채팅방 맨 앞의 인트로/첫 답변은 캐릭터 발화인 경우가 많습니다.
  // 색상이나 구조 때문에 유저 p로 들어온 선행 블록은 첫 실제 유저 입력 전 캐릭터 블록으로 보정합니다.
  if(!blocks || !blocks.length) return;
  const firstCharacterIndex = blocks.findIndex(b => b.owner === "character");
  if(firstCharacterIndex <= 0) return;
  for(let i=0; i<firstCharacterIndex; i++){
    const block = blocks[i];
    if(block.owner !== "user") continue;
    const slice = chunks.slice(block.startChunk, block.endChunk);
    const hasCharacterColor = slice.some(c => ownerFromColor(c.color, "") === "character");
    const allScene = slice.length && slice.every(c => c.kind === "scene");
    if(hasCharacterColor || allScene){
      block.owner = "character";
      slice.forEach(c => { c.owner = "character"; });
    }
  }
}

function isLikelyChapterSeparatorText(text){
  const clean = String(text || "").replace(/<[^>]*>/g, "").replace(/\s+/g, "").trim();
  if(!clean) return false;
  return /^[\-—―─━_]{3,}$/.test(clean);
}

function normalizeResponseBlocks(blocks, chunks){
  if(!Array.isArray(blocks) || !blocks.length) return blocks || [];
  const sorted = blocks.slice().sort((a,b)=>(a.startChunk||0)-(b.startChunk||0));
  const grouped = [];
  let current = null;
  let seq = 0;
  const finish = () => {
    if(!current) return;
    const related = chunks.slice(current.startChunk, current.endChunk).filter(Boolean);
    current.text = related.map(c => c.text).filter(Boolean).join("\n\n").trim();
    const owners = related.map(c => c.owner).filter(Boolean);
    current.owner = current.owner || owners[0] || "";
    if(current.text) grouped.push(current);
    current = null;
  };
  sorted.forEach(block => {
    const start = Math.max(0, block.startChunk || 0);
    const end = Math.max(start, block.endChunk || start);
    const related = chunks.slice(start, end).filter(Boolean);
    const owner = block.owner || (related.find(c => c.owner) || {}).owner || "";
    const text = related.map(c => c.text).filter(Boolean).join("\n\n").trim();
    const separator = isLikelyChapterSeparatorText(text);
    const canMerge = current && !separator && owner && current.owner === owner && current.endChunk === start;
    if(!canMerge) finish();
    if(!current){
      current = {id:`rb${seq++}`, owner, text:"", startChunk:start, endChunk:end};
    }else{
      current.endChunk = Math.max(current.endChunk, end);
    }
    const id = current.id;
    for(let i=start; i<end; i++){
      if(chunks[i]) chunks[i].blockId = id;
    }
    if(separator){
      finish();
    }
  });
  finish();
  return grouped;
}

function normalizeChunkResponseBlocks(chunks){
  if(!Array.isArray(chunks) || !chunks.length) return chunks || [];
  let seq = 0;
  let currentId = "";
  let currentOwner = "";
  chunks.forEach(chunk => {
    const owner = chunk.owner || "character";
    const separator = isLikelyChapterSeparatorText(chunk.text);
    if(!currentId || separator || owner !== currentOwner){
      currentId = `md-rb${seq++}`;
      currentOwner = owner;
    }
    chunk.blockId = currentId;
    if(separator){
      currentId = "";
      currentOwner = "";
    }
  });
  return chunks;
}

// ------------------ 중복/삭제 확인 패널 ------------------
function normalizeForCompare(text){
  return String(text || "")
    .replace(/\s+/g, "")
    .replace(/[“”‘’"']/g, "")
    .trim();
}
function hashString(str){
  let h = 2166136261;
  const s = String(str || "");
  for(let i=0; i<s.length; i++){
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0).toString(36);
}
function previewText(text, limit){
  // 중복 후보 검토에서는 내용을 확인해야 하므로 뒤를 생략하지 않고 전체를 보여준다.
  return normalizeParagraphText(text || "");
}
function findNextAnswerBlock(blocks, index){
  for(let i=index + 1; i<blocks.length; i++){
    if(blocks[i].owner === "character") return blocks[i];
    if(blocks[i].owner === "user") return null;
  }
  return null;
}
function findNextUserBlockAfter(blocks, block){
  if(!block) return null;
  const index = blocks.findIndex(b => b && b.id === block.id);
  if(index < 0) return null;
  for(let i=index + 1; i<blocks.length; i++){
    if(blocks[i].owner === "user") return blocks[i];
  }
  return null;
}
function findPrevUserBlock(blocks, index){
  for(let i=index - 1; i>=0; i--){
    if(blocks[i].owner === "user") return blocks[i];
    if(blocks[i].owner === "character") return null;
  }
  return null;
}
function splitSentencesForCompare(text){
  return String(text || "")
    .replace(/([.!?。！？]|[다요죠까네군니다]\.)/g, "$1\n")
    .split(/\n|(?<=[.!?。！？])\s+/)
    .map(s => s.trim())
    .filter(Boolean)
    .map(s => normalizeForCompare(s))
    .filter(s => s.length >= 8);
}
function overlapSentenceCount(a, b){
  const aSet = new Set(splitSentencesForCompare(a));
  const bList = splitSentencesForCompare(b);
  let count = 0;
  bList.forEach(s => { if(aSet.has(s)) count++; });
  return count;
}
function promptRepresentative(prompts){
  const map = new Map();
  prompts.forEach(p => {
    const key = normalizeForCompare(p.text);
    if(!map.has(key)) map.set(key, {text:p.text, count:0, length:p.text.length});
    const item = map.get(key);
    item.count++;
    if(p.text.length > item.length){ item.text = p.text; item.length = p.text.length; }
  });
  return Array.from(map.values()).sort((a,b) => b.count - a.count || b.length - a.length)[0]?.text || prompts[0]?.text || "";
}
function buildDuplicateAnswerGroups(blocks){
  const promptOccurrences = [];
  blocks.forEach((block, index) => {
    if(block.owner !== "user") return;
    const norm = normalizeForCompare(block.text);
    if(norm.length < 30) return;
    const answer = findNextAnswerBlock(blocks, index);
    if(!answer) return;
    promptOccurrences.push({promptBlock:block, answerBlock:answer, promptNorm:norm});
  });

  const parent = Array.from({length:promptOccurrences.length}, (_,i)=>i);
  const find = (x) => parent[x] === x ? x : (parent[x] = find(parent[x]));
  const unite = (a,b) => { const ra=find(a), rb=find(b); if(ra!==rb) parent[rb]=ra; };
  for(let i=0; i<promptOccurrences.length; i++){
    for(let j=i+1; j<promptOccurrences.length; j++){
      if(promptOccurrences[i].promptNorm === promptOccurrences[j].promptNorm || overlapSentenceCount(promptOccurrences[i].promptBlock.text, promptOccurrences[j].promptBlock.text) >= 2){
        unite(i,j);
      }
    }
  }
  const promptMap = new Map();
  promptOccurrences.forEach((occ, idx) => {
    const r = find(idx);
    if(!promptMap.has(r)) promptMap.set(r, []);
    promptMap.get(r).push(occ);
  });
  const promptGroups = Array.from(promptMap.values())
    .filter(list => list.length > 1)
    .map(list => {
      const keySeed = list.map(o => o.promptBlock.id).join("|");
      return {key:"prompt-" + hashString(keySeed), type:"prompt", promptText:promptRepresentative(list.map(o => o.promptBlock)), occurrences:list.map(o => ({...o, nextUserBlock: findNextUserBlockAfter(blocks, o.answerBlock)}))};
    });

  const coveredAnswerIds = new Set();
  promptGroups.forEach(g => g.occurrences.forEach(o => coveredAnswerIds.add(o.answerBlock.id)));

  const answerGroups = new Map();
  blocks.forEach((block, index) => {
    if(block.owner !== "character" || coveredAnswerIds.has(block.id)) return;
    const norm = normalizeForCompare(block.text);
    if(norm.length < 80) return;
    const key = "answer-" + hashString(norm);
    if(!answerGroups.has(key)) answerGroups.set(key, {key, type:"answer", promptText:block.text, occurrences:[]});
    answerGroups.get(key).occurrences.push({promptBlock:findPrevUserBlock(blocks, index), answerBlock:block, nextUserBlock:findNextUserBlockAfter(blocks, block)});
  });

  return promptGroups.concat(Array.from(answerGroups.values()).filter(g => g.occurrences.length > 1)).slice(0, 80);
}
function getDroppedBlockIdsFromDuplicateDecisions(groups){
  const dropped = new Set();
  groups.forEach(group => {
    const decision = duplicateDecisions[group.key] || "all";
    if(decision === "all") return;
    group.occurrences.forEach(occ => {
      const keepId = occ.answerBlock ? occ.answerBlock.id : (occ.promptBlock ? occ.promptBlock.id : "");
      if(keepId === decision) return;
      if(occ.promptBlock) dropped.add(occ.promptBlock.id);
      if(occ.answerBlock) dropped.add(occ.answerBlock.id);
    });
  });
  return dropped;
}
function groupMatchesDuplicateFilter(group, idx){
  const keyword = normalizeParagraphText(duplicateFilterText || "").toLowerCase();
  const order = String(duplicateOrderQuery || "").trim();
  if(order){
    const n = Number(order);
    if(Number.isFinite(n) && n > 0 && (idx + 1) !== n) return false;
  }
  if(!keyword) return true;
  const hay = [group.promptText || ""];
  (group.occurrences || []).forEach(occ => {
    if(occ.promptBlock) hay.push(occ.promptBlock.text || "");
    if(occ.answerBlock) hay.push(occ.answerBlock.text || "");
  });
  return hay.join("\n").toLowerCase().includes(keyword);
}
function getFilteredDuplicateGroups(){
  return (currentDuplicateGroups || []).map((group, index) => ({group, index})).filter(item => groupMatchesDuplicateFilter(item.group, item.index));
}
function updateDuplicateReviewPanel(groups){
  currentDuplicateGroups = groups || [];
  if(activeMode !== "chat" || !reviewDuplicatesEl.checked){
    duplicateReviewPanel.classList.add("hidden");
    duplicateReviewPanel.innerHTML = "";
    return;
  }
  if(!currentDuplicateGroups.length){
    duplicateReviewPanel.classList.remove("hidden");
    duplicateReviewPanel.innerHTML = `<div class="reviewHead"><div><div class="reviewTitle">중복 답변 확인</div><div class="reviewMeta">같은 입력이나 같은 답변이 반복된 후보를 찾지 못했습니다.</div></div></div>`;
    return;
  }

  const filtered = getFilteredDuplicateGroups();
  const total = currentDuplicateGroups.length;
  const count = filtered.length;
  duplicateGroupPage = Math.max(0, Math.min(Math.max(0, count - 1), duplicateGroupPage || 0));

  let html = `<div class="reviewHead"><div><div class="reviewTitle">중복 답변 확인</div><div class="reviewMeta">한 묶음씩 넘겨 보며 선택합니다.</div></div><div class="smallMuted">${count}/${total}묶음</div></div>`;
  html += `<div class="reviewSearchBar"><input type="search" data-dupe-search="keyword" placeholder="후보 내용 검색" value="${escapeAttr(duplicateFilterText)}"><input type="number" min="1" data-dupe-search="order" placeholder="순서" value="${escapeAttr(duplicateOrderQuery)}"><button type="button" class="btn primary" data-dupe-search-apply="1">검색</button><button type="button" class="btn subtle" data-dupe-search-clear="1">초기화</button></div>`;

  if(!count){
    html += `<div class="emptyState">검색 조건에 맞는 중복 후보가 없습니다.</div>`;
    duplicateReviewPanel.classList.remove("hidden");
    duplicateReviewPanel.innerHTML = html;
    return;
  }

  const wrap = filtered[duplicateGroupPage];
  const group = wrap.group;
  const gIdx = wrap.index;
  const selected = duplicateDecisions[group.key] || "all";
  const current = Math.max(0, Math.min(group.occurrences.length - 1, duplicatePageByGroup[group.key] || 0));
  duplicatePageByGroup[group.key] = current;
  const occ = group.occurrences[current];
  const answer = occ.answerBlock || occ.promptBlock;
  const answerId = answer ? answer.id : "";
  const title = group.type === "prompt" ? "같은 입력에 대한 답변 후보" : "반복된 답변 후보";
  const prevGroupDisabled = duplicateGroupPage <= 0 ? "disabled" : "";
  const nextGroupDisabled = duplicateGroupPage >= count - 1 ? "disabled" : "";
  const prevCandDisabled = current <= 0 ? "disabled" : "";
  const nextCandDisabled = current >= group.occurrences.length - 1 ? "disabled" : "";

  html += `<div class="dupeCard">`;
  html += `<div class="reviewNav"><div><div class="reviewTitle">${title}</div><div class="reviewMeta">전체 ${gIdx + 1}/${total} · 검색 결과 ${duplicateGroupPage + 1}/${count} · 후보 ${group.occurrences.length}개</div></div><div class="navButtons"><button type="button" class="navIconBtn" data-dupe-group-page="prev" ${prevGroupDisabled} aria-label="이전 묶음">‹</button><button type="button" class="navIconBtn" data-dupe-group-page="next" ${nextGroupDisabled} aria-label="다음 묶음">›</button></div></div>`;
  const nextUser = occ.nextUserBlock || findNextUserBlockAfter((currentParsedBlocks || []), answer);
  const nextUserHtml = nextUser
    ? `<details class="nextPromptFold"><summary><span class="nextFoldIcon">›</span><span>유저 다음 지문</span></summary><div class="previewText fullPreview nextPreview">${escapeHTML(nextUser.text || "")}</div></details>`
    : `<details class="nextPromptFold"><summary><span class="nextFoldIcon">›</span><span>유저 다음 지문</span></summary><div class="emptyState nextEmpty">다음 유저 지문이 없습니다.</div></details>`;
  html += `<div class="dupeCompareGrid">`;
  html += `<div class="reviewBlock"><div class="dupeSummary"><span class="pill">연결 유저 지문</span><span class="pill">${current + 1}/${group.occurrences.length}</span></div><div class="previewText fullPreview">${escapeHTML(occ.promptBlock ? occ.promptBlock.text : "")}</div>${nextUserHtml}</div>`;
  html += `<div class="reviewBlock"><div class="dupeSummary withNav"><span><span class="pill">${escapeHTML(ownerLabel(answer ? answer.owner : ""))}</span><span class="pill">답변 후보 ${current + 1}/${group.occurrences.length}</span></span><span class="navButtons"><button type="button" class="navIconBtn" data-dupe-page="prev" data-dupe-key="${escapeAttr(group.key)}" ${prevCandDisabled} aria-label="이전 후보">‹</button><button type="button" class="navIconBtn" data-dupe-page="next" data-dupe-key="${escapeAttr(group.key)}" ${nextCandDisabled} aria-label="다음 후보">›</button></span></div><div class="previewText fullPreview">${escapeHTML(answer ? answer.text : "")}</div></div>`;
  html += `</div>`;
  html += `<div class="reviewChoices choiceRow"><label class="reviewChoice"><input type="radio" name="dupe_${escapeAttr(group.key)}" data-dupe-key="${escapeAttr(group.key)}" value="all" ${selected === "all" ? "checked" : ""}>모두 유지</label><label class="reviewChoice"><input type="radio" name="dupe_${escapeAttr(group.key)}" data-dupe-key="${escapeAttr(group.key)}" value="${escapeAttr(answerId)}" ${selected === answerId ? "checked" : ""}>현재 후보만 유지</label></div>`;
  html += `</div>`;

  duplicateReviewPanel.classList.remove("hidden");
  duplicateReviewPanel.innerHTML = html;
}
function handleDuplicateReviewChange(e){
  const target = e.target;
  if(!target || !target.matches('input[type="radio"][data-dupe-key]')) return;
  duplicateDecisions[target.dataset.dupeKey] = target.value;
  transformText();
}
function handleDuplicateReviewClick(e){
  const apply = e.target.closest("button[data-dupe-search-apply]");
  if(apply){
    duplicateGroupPage = 0;
    updateDuplicateReviewPanel(currentDuplicateGroups);
    return;
  }
  const clear = e.target.closest("button[data-dupe-search-clear]");
  if(clear){
    duplicateFilterText = "";
    duplicateOrderQuery = "";
    duplicateGroupPage = 0;
    updateDuplicateReviewPanel(currentDuplicateGroups);
    return;
  }
  const groupButton = e.target.closest("button[data-dupe-group-page]");
  if(groupButton && !groupButton.disabled){
    const filtered = getFilteredDuplicateGroups();
    const max = Math.max(0, filtered.length - 1);
    duplicateGroupPage = groupButton.dataset.dupeGroupPage === "next" ? Math.min(max, duplicateGroupPage + 1) : Math.max(0, duplicateGroupPage - 1);
    updateDuplicateReviewPanel(currentDuplicateGroups);
    return;
  }
  const button = e.target.closest("button[data-dupe-page]");
  if(!button || button.disabled) return;
  const key = button.dataset.dupeKey;
  const group = currentDuplicateGroups.find(g => g.key === key);
  if(!group) return;
  const max = Math.max(0, group.occurrences.length - 1);
  const cur = Math.max(0, Math.min(max, duplicatePageByGroup[key] || 0));
  duplicatePageByGroup[key] = button.dataset.dupePage === "next" ? Math.min(max, cur + 1) : Math.max(0, cur - 1);
  updateDuplicateReviewPanel(currentDuplicateGroups);
}
function handleDuplicateReviewInput(e){
  const target = e.target;
  if(!target) return;
  if(target.matches('[data-dupe-search="keyword"]')){
    duplicateFilterText = target.value || "";
  }else if(target.matches('[data-dupe-search="order"]')){
    duplicateOrderQuery = target.value || "";
  }
}
function handleDuplicateReviewKeydown(e){
  const target = e.target;
  if(!target || !target.matches('[data-dupe-search]') || e.key !== "Enter") return;
  e.preventDefault();
  duplicateGroupPage = 0;
  updateDuplicateReviewPanel(currentDuplicateGroups);
}
function getChunkKey(chunk, index){
  return "chunk-" + (chunk.blockId || "x") + "-" + hashString((chunk.owner || "") + "|" + (chunk.kind || "") + "|" + normalizeForCompare(chunk.text)) + "-" + index;
}
function getContainsGroupKey(chunk){
  return "contains-" + hashString((chunk.owner || "") + "|" + (chunk.kind || "") + "|" + String(chunk.text || ""));
}
function getContainsSnippet(text){
  const t = normalizeParagraphText(text || "");
  if(!t) return "빈 문단";
  return t.length > 25 ? t.slice(0, 25) + "…" : t;
}
function getTokenKey(token){
  return "token-" + hashString(String(token || "").toLowerCase());
}
function tokenMatchesText(text, token){
  if(!text || !token) return false;
  return String(text).toLowerCase().includes(String(token).toLowerCase());
}
function buildContainsReviewItems(chunks, dropBlockIds, deleteTokens, dropChunkIds){
  const tokens = getProtectTokens();
  if(!deleteContainsEnabledEl.checked || deleteContainsModeEl.value !== "review" || !deleteTokens.length) return [];
  const tokenGroups = new Map();
  deleteTokens.forEach(rawToken => {
    const token = String(rawToken || "").trim();
    if(!token) return;
    const tokenKey = getTokenKey(token);
    if(!tokenGroups.has(tokenKey)) tokenGroups.set(tokenKey, { token, tokenKey, rows:new Map(), count:0 });
  });

  chunks.map((chunk, index) => ({chunk, index, key:getChunkKey(chunk, index), groupKey:getContainsGroupKey(chunk)}))
    .filter(item => !dropBlockIds.has(item.chunk.blockId))
    .filter(item => !(dropChunkIds && dropChunkIds.has(item.chunk.id)))
    .filter(item => !isProtectedText(item.chunk.text, tokens))
    .forEach(item => {
      deleteTokens.forEach(rawToken => {
        const token = String(rawToken || "").trim();
        if(!token || !tokenMatchesText(item.chunk.text, token)) return;
        const tokenKey = getTokenKey(token);
        const group = tokenGroups.get(tokenKey);
        if(!group) return;
        if(!group.rows.has(item.groupKey)) group.rows.set(item.groupKey, {...item, count:0, keys:[]});
        const row = group.rows.get(item.groupKey);
        row.count++;
        row.keys.push(item.key);
        group.count++;
      });
    });

  return Array.from(tokenGroups.values())
    .map(group => ({...group, rows:Array.from(group.rows.values())}))
    .filter(group => group.rows.length > 0);
}
function updateContainsReviewPanel(items){
  currentContainsItems = items || [];
  if(!deleteContainsEnabledEl.checked || deleteContainsModeEl.value !== "review"){
    containsReviewPanel.classList.add("hidden");
    containsReviewPanel.innerHTML = "";
    return;
  }
  if(!currentContainsItems.length){
    containsReviewPanel.classList.remove("hidden");
    containsReviewPanel.innerHTML = `<div class="reviewHead"><div><div class="reviewTitle">특정 글자 포함 문단 확인</div><div class="reviewMeta">현재 키워드에 걸리는 문단이 없습니다.</div></div></div>`;
    return;
  }

  const totalRows = currentContainsItems.reduce((sum, group) => sum + group.rows.length, 0);
  const totalHits = currentContainsItems.reduce((sum, group) => sum + group.count, 0);
  let html = `<div class="reviewHead"><div><div class="reviewTitle">특정 글자 포함 문단 확인</div><div class="reviewMeta">키워드별로 묶었습니다. 접힌 상태에서도 남김/삭제를 고를 수 있습니다. ${totalRows}개 묶음 · ${totalHits}개 감지</div></div><div class="bulkButtons"><button type="button" class="btn subtle" data-contains-bulk="keep">모두 남김</button><button type="button" class="btn subtle warn" data-contains-bulk="delete">모두 삭제</button></div></div>`;

  currentContainsItems.forEach((group, gidx) => {
    const open = containsOpenTouched ? containsOpenGroups.has(group.tokenKey) : gidx === 0;
    const allDeleted = (group.rows || []).length > 0 && (group.rows || []).every(item => containsDecisions[item.groupKey || item.key] === "delete");
    const summaryState = allDeleted ? "삭제" : "남김";
    html += `<details class="containsKeywordGroup" data-contains-group="${escapeAttr(group.tokenKey)}"${open ? " open" : ""}><summary><span class="keywordSummaryLeft"><span class="keywordTitle">${escapeHTML(group.token)}</span><span class="keywordMeta">${group.rows.length}개 묶음 · 총 ${group.count}개 · ${summaryState}</span></span><span class="keywordSummaryActions" data-stop-summary><button type="button" class="miniChoiceBtn${!allDeleted ? " active" : ""}" data-contains-group-bulk="keep" data-contains-group-key="${escapeAttr(group.tokenKey)}">묶음 남김</button><button type="button" class="miniChoiceBtn warn${allDeleted ? " active" : ""}" data-contains-group-bulk="delete" data-contains-group-key="${escapeAttr(group.tokenKey)}">묶음 삭제</button></span></summary><div class="containsRows">`;
    group.rows.forEach((item, idx) => {
      const key = item.groupKey || item.key;
      const decision = containsDecisions[key] || "keep";
      const chunk = item.chunk;
      const kindLabel = chunk.kind === "scene" ? "지문" : "대사";
      const extra = item.count && item.count > 1 ? ` 외 ${item.count - 1}개` : "";
      html += `<details class="containsRow"><summary><span class="containsPreview">${escapeHTML(getContainsSnippet(chunk.text))}${escapeHTML(extra)}</span><span class="containsRight"><span class="pill">${escapeHTML(ownerLabel(chunk.owner))}</span><span class="pill">${kindLabel}</span><span class="inlineChoice" data-stop-summary><label><input type="radio" name="contains_${escapeAttr(key)}" data-contains-key="${escapeAttr(key)}" data-contains-group-key="${escapeAttr(group.tokenKey)}" value="keep" ${decision !== "delete" ? "checked" : ""}>남김</label><label><input type="radio" name="contains_${escapeAttr(key)}" data-contains-key="${escapeAttr(key)}" data-contains-group-key="${escapeAttr(group.tokenKey)}" value="delete" ${decision === "delete" ? "checked" : ""}>삭제</label></span></span></summary><div class="reviewBlock"><div class="previewText compactPreview">${escapeHTML(chunk.text)}</div></div></details>`;
    });
    html += `</div></details>`;
  });
  containsReviewPanel.classList.remove("hidden");
  containsReviewPanel.innerHTML = html;
}
function handleContainsReviewChange(e){
  const target = e.target;
  if(!target || !target.matches('input[type="radio"][data-contains-key]')) return;
  containsDecisions[target.dataset.containsKey] = target.value;
  if(target.dataset.containsGroupKey){
    containsOpenTouched = true;
    containsOpenGroups.add(target.dataset.containsGroupKey);
  }
  transformText();
}
function handleContainsReviewToggle(e){
  const detail = e.target;
  if(!detail || !detail.classList || !detail.classList.contains("containsKeywordGroup")) return;
  const key = detail.dataset.containsGroup;
  if(!key) return;
  containsOpenTouched = true;
  if(detail.open) containsOpenGroups.add(key);
  else containsOpenGroups.delete(key);
}
function handleContainsReviewClick(e){
  const control = e.target.closest('[data-stop-summary]');
  if(control){
    e.stopPropagation();
  }
  const groupButton = e.target.closest("button[data-contains-group-bulk]");
  if(groupButton){
    e.preventDefault();
    e.stopPropagation();
    const groupKey = groupButton.dataset.containsGroupKey;
    const value = groupButton.dataset.containsGroupBulk === "delete" ? "delete" : "keep";
    const group = currentContainsItems.find(item => item.tokenKey === groupKey);
    if(group){
      (group.rows || []).forEach(item => { containsDecisions[item.groupKey || item.key] = value; });
      containsOpenTouched = true;
      if(groupKey) containsOpenGroups.add(groupKey);
      transformText();
    }
    return;
  }
  const button = e.target.closest("button[data-contains-bulk]");
  if(!button) return;
  const value = button.dataset.containsBulk === "delete" ? "delete" : "keep";
  currentContainsItems.forEach(group => {
    (group.rows || []).forEach(item => { containsDecisions[item.groupKey || item.key] = value; });
  });
  transformText();
}


function countSimpleSentences(text){
  const parts = String(text || "").split(/[.!?。！？\n]+/).map(s => s.trim()).filter(Boolean);
  return Math.max(1, parts.length || 0);
}
function normalizeOocMarkerText(text){
  return String(text || "")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/\u00a0/g, " ");
}
function containsOocMarker(text){
  return /ooc/i.test(normalizeOocMarkerText(text));
}
function isOocPrompt(text){
  return containsOocMarker(text);
}
function isTrivialContinuationPrompt(text){
  const t = normalizeParagraphText(text || "");
  if(!t) return true;
  if(/^[\s*＊·•・.。…\-—_]+$/.test(t)) return true;
  if(/이어|이어서|계속|계속해서|다음|출력|응답/.test(t) && countSimpleSentences(t) <= 1 && t.length <= 90) return true;
  return false;
}
function stripBracketedOocText(text){
  let t = String(text || "");
  const stripInline = value => String(value || "")
    .replace(/\[[^\]]*ooc[^\]]*\]/gi, "")
    .replace(/<[^>]*ooc[^>]*>/gi, "")
    .replace(/\*\*[^*]*ooc[^*]*\*\*/gi, "")
    .replace(/\([^)]*ooc[^)]*\)/gi, "")
    .replace(/【[^】]*ooc[^】]*】/gi, "")
    .replace(/「[^」]*ooc[^」]*」/gi, "");
  t = stripInline(t);
  const paragraphs = t.split(/\n\s*\n/).map(part => {
    const cleaned = stripInline(part).trim();
    if(containsOocMarker(cleaned)) return "";
    return cleaned;
  }).filter(Boolean);
  return paragraphs.join("\n\n").replace(/\n{3,}/g, "\n\n").trim();
}
function getOocReviewKey(block){
  return "ooc-" + (block && block.id ? block.id : hashString(block ? block.text : ""));
}
function buildOocReviewItems(blocks, alreadyDropped){
  if(activeMode !== "chat" || !reviewOocPairsEl || !reviewOocPairsEl.checked) return [];
  const cascade = oocCascadeModeEl && oocCascadeModeEl.value === "cascade";
  const items = [];
  for(let i=0; i<blocks.length; i++){
    const block = blocks[i];
    if(!block || block.owner !== "user" || !isOocPrompt(block.text) || (alreadyDropped && alreadyDropped.has(block.id))) continue;
    const answerBlocks = [];
    let j = i + 1;
    while(j < blocks.length){
      const cur = blocks[j];
      if(!cur) { j++; continue; }
      if(alreadyDropped && alreadyDropped.has(cur.id)){ j++; continue; }
      if(cur.owner === "character"){
        answerBlocks.push(cur);
        j++;
        continue;
      }
      if(cur.owner === "user"){
        if(cascade && isTrivialContinuationPrompt(cur.text)){
          j++;
          continue;
        }
        break;
      }
      j++;
    }
    items.push({key:getOocReviewKey(block), promptBlock:block, answerBlocks});
  }
  return items.slice(0, 120);
}
function oocItemMatchesFilter(item, idx){
  const keyword = normalizeParagraphText(oocFilterText || "").toLowerCase();
  const order = String(oocOrderQuery || "").trim();
  if(order){
    const n = Number(order);
    if(Number.isFinite(n) && n > 0 && (idx + 1) !== n) return false;
  }
  if(!keyword) return true;
  const hay = [item.promptBlock ? item.promptBlock.text : ""].concat((item.answerBlocks || []).map(b => b.text || "")).join("\n").toLowerCase();
  return hay.includes(keyword);
}
function getFilteredOocItems(){
  return (currentOocItems || []).map((item, index) => ({item, index})).filter(w => oocItemMatchesFilter(w.item, w.index));
}
function updateOocReviewPanel(items){
  currentOocItems = items || [];
  if(activeMode !== "chat" || !reviewOocPairsEl || !reviewOocPairsEl.checked){
    oocReviewPanel.classList.add("hidden");
    oocReviewPanel.innerHTML = "";
    return;
  }
  if(!currentOocItems.length){
    oocReviewPanel.classList.remove("hidden");
    oocReviewPanel.innerHTML = `<div class="reviewHead"><div><div class="reviewTitle">OOC 응답 검토</div><div class="reviewMeta">OOC가 들어간 유저 지문을 찾지 못했습니다.</div></div></div>`;
    return;
  }
  const filtered = getFilteredOocItems();
  const total = currentOocItems.length;
  const count = filtered.length;
  oocGroupPage = Math.max(0, Math.min(Math.max(0, count - 1), oocGroupPage || 0));

  let html = `<div class="reviewHead"><div><div class="reviewTitle">OOC 응답 검토</div><div class="reviewMeta">OOC가 포함된 지문을 한 개씩 확인합니다.</div></div><div class="bulkButtons"><button type="button" class="btn subtle" data-ooc-bulk="keepPrompt">전체 지문만 삭제</button><button type="button" class="btn subtle" data-ooc-bulk="delete">전체 응답까지 삭제</button></div></div>`;
  html += `<div class="reviewSearchBar"><input type="search" data-ooc-search="keyword" placeholder="OOC/응답 내용 검색" value="${escapeAttr(oocFilterText)}"><input type="number" min="1" data-ooc-search="order" placeholder="순서" value="${escapeAttr(oocOrderQuery)}"><button type="button" class="btn primary" data-ooc-search-apply="1">검색</button><button type="button" class="btn subtle" data-ooc-search-clear="1">초기화</button></div>`;
  if(!count){
    html += `<div class="emptyState">검색 조건에 맞는 OOC 지문이 없습니다.</div>`;
    oocReviewPanel.classList.remove("hidden");
    oocReviewPanel.innerHTML = html;
    return;
  }
  const wrap = filtered[oocGroupPage];
  const item = wrap.item;
  const idx = wrap.index;
  const decision = oocDecisions[item.key] || "strip";
  const answerCount = item.answerBlocks.length;
  const answersText = item.answerBlocks.map((b, n) => `응답 ${n + 1}\n${b.text}`).join("\n\n");
  const prevDisabled = oocGroupPage <= 0 ? "disabled" : "";
  const nextDisabled = oocGroupPage >= count - 1 ? "disabled" : "";
  html += `<div class="dupeCard oocCard">`;
  html += `<div class="reviewNav"><div><div class="reviewTitle">OOC 지문 ${idx + 1}</div><div class="reviewMeta">전체 ${idx + 1}/${total} · 검색 결과 ${oocGroupPage + 1}/${count} · 연결 응답 ${answerCount}개</div></div><div class="navButtons"><button type="button" class="navIconBtn" data-ooc-page="prev" ${prevDisabled} aria-label="이전 OOC">‹</button><button type="button" class="navIconBtn" data-ooc-page="next" ${nextDisabled} aria-label="다음 OOC">›</button></div></div>`;
  html += `<div class="dupeCompareGrid">`;
  html += `<div class="reviewBlock"><div class="dupeSummary"><span class="pill">OOC 포함 지문</span></div><div class="previewText">${escapeHTML(item.promptBlock.text)}</div></div>`;
  html += `<div class="reviewBlock"><div class="dupeSummary"><span class="pill">연결 캐릭터 응답</span><span class="pill">${answerCount}개</span></div>${answerCount ? `<div class="previewText">${escapeHTML(answersText)}</div>` : `<div class="emptyState">연결된 캐릭터 응답이 없습니다.</div>`}</div>`;
  html += `</div>`;
  html += `<div class="reviewChoices choiceRow threeChoices"><label class="reviewChoice"><input type="radio" name="ooc_${escapeAttr(item.key)}" data-ooc-key="${escapeAttr(item.key)}" value="strip" ${decision === "strip" ? "checked" : ""}>OOC 문단만 삭제</label><label class="reviewChoice"><input type="radio" name="ooc_${escapeAttr(item.key)}" data-ooc-key="${escapeAttr(item.key)}" value="prompt" ${decision === "prompt" ? "checked" : ""}>전체 유저 지문 삭제</label><label class="reviewChoice"><input type="radio" name="ooc_${escapeAttr(item.key)}" data-ooc-key="${escapeAttr(item.key)}" value="delete" ${decision === "delete" ? "checked" : ""}>응답까지 삭제</label></div>`;
  html += `</div>`;
  oocReviewPanel.classList.remove("hidden");
  oocReviewPanel.innerHTML = html;
}
function handleOocReviewChange(e){
  const target = e.target;
  if(!target || !target.matches('input[type="radio"][data-ooc-key]')) return;
  oocDecisions[target.dataset.oocKey] = target.value;
  transformText();
}
function handleOocReviewClick(e){
  const bulk = e.target.closest("button[data-ooc-bulk]");
  if(bulk){
    const value = bulk.dataset.oocBulk === "delete" ? "delete" : "prompt";
    currentOocItems.forEach(item => { oocDecisions[item.key] = value; });
    transformText();
    return;
  }
  const pageBtn = e.target.closest("button[data-ooc-page]");
  if(pageBtn){
    const filtered = getFilteredOocItems();
    const max = Math.max(0, filtered.length - 1);
    oocGroupPage = pageBtn.dataset.oocPage === "next" ? Math.min(max, oocGroupPage + 1) : Math.max(0, oocGroupPage - 1);
    updateOocReviewPanel(currentOocItems);
  }
  if(e.target.closest("button[data-ooc-search-apply]")){
    oocGroupPage = 0;
    updateOocReviewPanel(currentOocItems);
    return;
  }
  if(e.target.closest("button[data-ooc-search-clear]")){
    oocFilterText = "";
    oocOrderQuery = "";
    oocGroupPage = 0;
    updateOocReviewPanel(currentOocItems);
  }
}
function handleOocReviewInput(e){
  const target = e.target;
  if(!target) return;
  if(target.matches('[data-ooc-search="keyword"]')) oocFilterText = target.value || "";
  if(target.matches('[data-ooc-search="order"]')) oocOrderQuery = target.value || "";
}
function handleOocReviewKeydown(e){
  if(e.key !== "Enter") return;
  if(e.target && e.target.matches('[data-ooc-search]')){
    e.preventDefault();
    oocGroupPage = 0;
    updateOocReviewPanel(currentOocItems);
  }
}
function getDroppedBlockIdsFromOocDecisions(items){
  const dropped = new Set();
  (items || []).forEach(item => {
    const decision = oocDecisions[item.key] || "strip";
    if(decision === "prompt" || decision === "delete"){
      if(item.promptBlock) dropped.add(item.promptBlock.id);
    }
    if(decision === "delete"){
      item.answerBlocks.forEach(b => dropped.add(b.id));
    }
  });
  return dropped;
}
function getOocStripMap(items){
  const map = new Map();
  (items || []).forEach(item => {
    const decision = oocDecisions[item.key] || "strip";
    if(decision === "strip" && item.promptBlock) map.set(item.promptBlock.id, true);
  });
  return map;
}
function mergeSets(){
  const merged = new Set();
  Array.from(arguments).forEach(set => {
    if(!set) return;
    set.forEach(v => merged.add(v));
  });
  return merged;
}
function createStructuralDeletePlan(chunks, dropBlockIds){
  const tokens = getProtectTokens();
  const dropChunkIds = new Set();
  (chunks || []).forEach(chunk => {
    if(!chunk || (dropBlockIds && dropBlockIds.has(chunk.blockId))) return;
    const t = String(chunk.text || "").trim();
    if(!t) return;
    const protectedHere = isProtectedText(t, tokens);
    if(removeDetailsEl.checked && chunk.fromDetails && !protectedHere){
      dropChunkIds.add(chunk.id);
      return;
    }
    if(removeTablesEl.checked && !protectedHere && (chunk.fromTable || isRemovableBlockText(t))){
      // 표/블록 제거는 문단 단위(chunk)로만 처리합니다.
      // 같은 응답 블록 안의 뒤쪽 지문까지 blockId로 삭제하지 않도록 여기에서 범위를 고정합니다.
      dropChunkIds.add(chunk.id);
    }
  });
  return { dropBlockIds: dropBlockIds || new Set(), dropChunkIds };
}
function makeDeleteOptions(base){
  const out = Object.assign({}, base || {});
  out.dropBlockIds = out.dropBlockIds || new Set();
  out.dropChunkIds = out.dropChunkIds || new Set();
  return out;
}

function shouldIndentOutput(){
  return !!(indentOutputEl && indentOutputEl.checked);
}
function indentRenderedText(text){
  if(!shouldIndentOutput()) return text;
  return String(text || "").split("\n").map(line => line.trim() ? "　" + line : line).join("\n");
}

// ------------------ 출력 공통 렌더러 ------------------
function renderChunks(chunks, options){
  options = makeDeleteOptions(options);
  const tokens = getProtectTokens();
  const deleteTokens = options.deleteTokens || [];
  const dropBlockIds = options.dropBlockIds || new Set();
  const dropChunkIds = options.dropChunkIds || new Set();
  const quoteStyle = quoteStyleEl.value;
  const [openQ, closeQ] = getQuotes(quoteStyle);
  const labeledBlockIds = new Set();
  const allowSpeakerLabels = !!options.labelSpeakers;

  const renderedItems = chunks.map((chunk, index) => {
    const {kind, text: raw, fromTable, fromDetails} = chunk;
    if(dropBlockIds.has(chunk.blockId) || dropChunkIds.has(chunk.id)) return null;
    let t = (raw || "").trim();
    if(options.oocStripMap && options.oocStripMap.has(chunk.blockId)){
      t = stripBracketedOocText(t);
    }
    if(!t) return "";

    if(removeHTMLEl.checked){
      t = t.replace(/<script[\s\S]*?<\/script>/gi,"");
      t = t.replace(/<style[\s\S]*?<\/style>/gi,"");
      t = t.replace(/<br\s*\/?>/gi,"\n");
      t = t.replace(/<\/p>/gi,"\n");
      t = t.replace(/<[^>]+>/g,"");
      t = t.replace(/<[^>\n]*/g,"");
      t = t.trim();
      if(!t) return "";
    }

    t = t.replace(/\*\*(.*?)\*\*/g,"$1");
    t = t.replace(/__(.*?)__/g,"$1");

    const protectedHere = isProtectedText(t, tokens);

    if(removeDetailsEl.checked && fromDetails && !protectedHere) return "";
    if(options.removeTables && !protectedHere && (fromTable || isRemovableBlockText(t))) return "";

    if(shouldDeleteByContains(t, deleteTokens) && !protectedHere){
      if(options.deleteContainsMode === "review"){
        const key = getContainsGroupKey(chunk);
        const legacyKey = getChunkKey(chunk, index);
        if(options.containsDecisions && (options.containsDecisions[key] === "delete" || options.containsDecisions[legacyKey] === "delete")) return "";
      }else{
        return "";
      }
    }

    if(removeDecorEl.checked && !protectedHere){
      const preserveDecor = getProtectedChapterSeparators();
      if(isDecorOnlyParagraph(t, preserveDecor)) return "";
      t = removeDecorLines(t, preserveDecor);
      if(!t) return "";
    }

    if(protectedHere){
      const kept = indentRenderedText(normalizeBlankLinesInsideCell(t));
      const shouldLabel = allowSpeakerLabels && !labeledBlockIds.has(chunk.blockId);
      if(shouldLabel) labeledBlockIds.add(chunk.blockId);
      return { text: labelChunk(kept, chunk, shouldLabel), blockId: chunk.blockId, owner: chunk.owner || "", kind: chunk.kind || "normal" };
    }

    if(kind==="scene"){
      const scene = indentRenderedText(normalizeBlankLinesInsideCell(t));
      const shouldLabel = allowSpeakerLabels && !labeledBlockIds.has(chunk.blockId);
      if(shouldLabel) labeledBlockIds.add(chunk.blockId);
      return { text: labelChunk(scene, chunk, shouldLabel), blockId: chunk.blockId, owner: chunk.owner || "", kind: chunk.kind || "scene" };
    }

    if(isDecorOnlyParagraph(t, getProtectedChapterSeparators())) return { text: t, blockId: chunk.blockId, owner: chunk.owner || "", kind: chunk.kind || "normal" };

    let dialogue = t;
    if(quoteStyle !== "none" && !isAlreadyQuoted(t)) dialogue = openQ + t + closeQ;
    dialogue = indentRenderedText(dialogue);
    const shouldLabel = allowSpeakerLabels && !labeledBlockIds.has(chunk.blockId);
    if(shouldLabel) labeledBlockIds.add(chunk.blockId);
    return { text: labelChunk(dialogue, chunk, shouldLabel), blockId: chunk.blockId, owner: chunk.owner || "", kind: chunk.kind || "normal" };
  }).filter(item => item && item.text);

  let outputText;
  if(removeEmptyLinesEl.checked){
    outputText = renderedItems.map(item => item.text).join("\n").trim();
  }else if(shouldRemoveCellEmptyLines()){
    outputText = renderedItems.map((item, idx) => {
      if(idx === 0) return item.text;
      const prev = renderedItems[idx - 1];
      return (prev && prev.blockId === item.blockId ? "\n" : "\n\n") + item.text;
    }).join("").trim();
  }else{
    outputText = renderedItems.map(item => item.text).join("\n\n").trim();
  }
  if(options.returnItems) return {text: outputText, items: renderedItems};
  return outputText;
}

// ------------------ 메인 변환 ------------------
function shouldRenderSpeakerLabels(){
  if(!(activeMode === "chat" || activeMode === "classic")) return false;
  if(!labelSpeakersEl || !labelSpeakersEl.checked) return false;
  const mode = speakerLabelModeEl ? speakerLabelModeEl.value : "output";
  return mode !== "reviewOnly";
}
function afterTransform(chunks, blocks, renderedText){
  updateResultStats(chunks || [], blocks || [], renderedText || "");
  updateEpubPreview();
  updateChapterDividerPanel();
  syncActiveResultHeight();
}
function transformText(){
  if(activeMode === "epubedit"){
    lastStructuredItems = [];
    updateEpubPreview();
    updateResultStats([], [], epubEditEditor ? editorPlainText(epubEditEditor) : "");
    return;
  }else if(activeMode === "chat"){
    const parsed = parseRofanChatChunks(chatPaste);
    currentParsedBlocks = parsed.blocks || [];
    const duplicateGroups = reviewDuplicatesEl.checked ? buildDuplicateAnswerGroups(parsed.blocks) : [];
    const duplicateDropBlockIds = getDroppedBlockIdsFromDuplicateDecisions(duplicateGroups);
    updateDuplicateReviewPanel(duplicateGroups);

    const oocItems = buildOocReviewItems(parsed.blocks, duplicateDropBlockIds);
    updateOocReviewPanel(oocItems);
    const oocDropBlockIds = getDroppedBlockIdsFromOocDecisions(oocItems);
    const oocStripMap = getOocStripMap(oocItems);
    const dropBlockIds = mergeSets(duplicateDropBlockIds, oocDropBlockIds);
    const rangeAdjustedChunks = applyMiddleRangeDeletesToChunks(parsed.chunks);
    const structuralPlan = createStructuralDeletePlan(rangeAdjustedChunks, dropBlockIds);

    const deleteTokens = getDeleteContainsTokens();
    const containsItems = buildContainsReviewItems(rangeAdjustedChunks, dropBlockIds, deleteTokens, structuralPlan.dropChunkIds);
    updateContainsReviewPanel(containsItems);

    const renderedPack = renderChunks(rangeAdjustedChunks, {
      removeTables: removeTablesEl.checked,
      deleteTokens,
      deleteContainsMode: deleteContainsModeEl.value,
      containsDecisions,
      dropBlockIds,
      dropChunkIds: structuralPlan.dropChunkIds,
      oocStripMap,
      labelSpeakers: shouldRenderSpeakerLabels(),
      returnItems: true
    });
    const rendered = renderedPack.text;
    lastStructuredItems = renderedPack.items || [];
    setResultOutput(chatOutput, rendered);
    afterTransform(rangeAdjustedChunks, parsed.blocks, rendered);
    return;
  }

  let text = input.value || "";
  const tokens = getProtectTokens();
  const structuredChunks = parseStructuredMarkdownToChunks(text);

  if(!structuredChunks){
    if(removeDetailsEl.checked){
      text = filterDetailsByProtection(text, tokens);
      text = text.replace(/<summary.*?>.*?<\/summary>/gi,"");
    }

    if(removeHTMLEl.checked){
      text = text.replace(/<script[\s\S]*?<\/script>/gi,"");
      text = text.replace(/<style[\s\S]*?<\/style>/gi,"");
      text = text.replace(/<br\s*\/?>/gi,"\n");
      text = text.replace(/<\/p>/gi,"\n");
      text = text.replace(/<[^>]+>/g,"");
      text = text.replace(/<[^>\n]*/g,"");
    }

    text = text.replace(/\*\*(.*?)\*\*/g,"$1");
    text = text.replace(/__(.*?)__/g,"$1");
  }

  const chunks = (classicActiveChunks && classicActiveChunks.length) ? cloneChunks(classicActiveChunks) : (structuredChunks || parseChunks(text));
  const rangeAdjustedChunks = applyMiddleRangeDeletesToChunks(chunks);
  const deleteTokens = getDeleteContainsTokens();
  currentDuplicateGroups = [];
  duplicateReviewPanel.classList.add("hidden");
  duplicateReviewPanel.innerHTML = "";
  if(oocReviewPanel){ oocReviewPanel.classList.add("hidden"); oocReviewPanel.innerHTML = ""; }
  const emptyDrop = new Set();
  const structuralPlan = createStructuralDeletePlan(rangeAdjustedChunks, emptyDrop);
  const containsItems = buildContainsReviewItems(rangeAdjustedChunks, emptyDrop, deleteTokens, structuralPlan.dropChunkIds);
  updateContainsReviewPanel(containsItems);
  const renderedPack = renderChunks(rangeAdjustedChunks, {
    removeTables: removeTablesEl.checked,
    deleteTokens,
    deleteContainsMode: deleteContainsModeEl.value,
    containsDecisions,
    dropBlockIds: emptyDrop,
    dropChunkIds: structuralPlan.dropChunkIds,
    labelSpeakers: shouldRenderSpeakerLabels(),
    returnItems: true
  });
  const rendered = renderedPack.text;
  lastStructuredItems = renderedPack.items || [];
  setResultOutput(output, rendered);
  afterTransform(rangeAdjustedChunks, [], rendered);
}

// ------------------ UI ------------------
function getActiveOutput(){
  if(activeMode === "chat") return chatOutput;
  if(activeMode === "epubedit") return epubEditEditor;
  return output;
}
function copyResult(){
  const value = getPlainActiveOutputValue();
  if(navigator.clipboard && navigator.clipboard.writeText){
    navigator.clipboard.writeText(value)
      .then(() => showToast("복사되었습니다."))
      .catch(() => fallbackCopy(value));
    return;
  }
  fallbackCopy(value);
}
function fallbackCopy(value){
  const temp = document.createElement("textarea");
  temp.value = value;
  temp.setAttribute("readonly", "");
  temp.style.position = "fixed";
  temp.style.left = "-9999px";
  document.body.appendChild(temp);
  temp.select();
  document.execCommand("copy");
  document.body.removeChild(temp);
  showToast("복사되었습니다.");
}
function showToast(msg){
  const t = document.getElementById("toast");
  t.textContent = msg;
  t.style.opacity = "1";
  setTimeout(()=>{ t.style.opacity = "0"; }, 1600);
}
function syncDownloadFileNameInputs(source){
  downloadFileNameEls.forEach(el => {
    if(el !== source) el.value = downloadFileBaseName || "";
  });
}
function currentDownloadBaseName(fallback){
  let typed = downloadFileBaseName || "";
  downloadFileNameEls.forEach(el => {
    if(!typed && el.value) typed = el.value;
  });
  typed = String(typed || fallback || "download").trim();
  return typed || "download";
}
function safeDownloadFileName(ext, fallback){
  return safeFileName(currentDownloadBaseName(fallback), ext);
}
function downloadTxt(){
  const blob=new Blob([getPlainActiveOutputValue()],{type:"text/plain;charset=utf-8"});
  const url=URL.createObjectURL(blob);
  const a=document.createElement("a");
  a.href=url;
  const fallback = activeMode === "chat" ? "cleaned_rofan_chat" : (activeMode === "epubedit" ? "edited_epub_text" : "cleaned_log");
  a.download=safeDownloadFileName(".txt", fallback);
  a.click();
  URL.revokeObjectURL(url);
}
function clearAll(){
  if(!window.confirm("정말 초기화하시겠습니까? 현재 입력과 변환 결과가 비워집니다.")) return;
  resetReviewDecisions();
  cachedChatFileName = "";
  duplicateGroupPage = 0;
  duplicateFilterText = "";
  duplicateOrderQuery = "";
  oocGroupPage = 0;
  oocFilterText = "";
  oocOrderQuery = "";
  middleRangeRules = [createMiddleRangeRule()];
  renderMiddleRangePanel();
  chapterKeywordQuery = "";
  chapterOrderQuery = "";
  chapterMatchPage = 0;
  if(chapterKeywordInputEl) chapterKeywordInputEl.value = "";
  if(chapterOrderInputEl) chapterOrderInputEl.value = "";
  if(duplicateReviewPanel){ duplicateReviewPanel.innerHTML = ""; duplicateReviewPanel.classList.add("hidden"); }
  if(containsReviewPanel){ containsReviewPanel.innerHTML = ""; containsReviewPanel.classList.add("hidden"); }
  if(oocReviewPanel){ oocReviewPanel.innerHTML = ""; oocReviewPanel.classList.add("hidden"); }

  if(activeMode === "epubedit"){
    if(epubEditEditor){ epubEditEditor.innerHTML = ""; epubEditEditor.scrollTop = 0; }
    if(epubEditFileInput) epubEditFileInput.value = "";
    if(epubEditFileNameEl) epubEditFileNameEl.textContent = "선택된 파일 없음";
    cachedEpubEditFileName = "";
    savedEditorRange = null;
    lastStructuredItems = [];
    updateEpubPreview();
    updateResultStats([], [], "");
  }else if(activeMode === "chat"){
    if(chatPaste) chatPaste.innerHTML="";
    if(chatOutput){ setResultOutput(chatOutput, ""); setResultOutputScroll(chatOutput, 0); }
    if(chatFileInput) chatFileInput.value="";
    if(chatFileNameEl) chatFileNameEl.textContent = "선택된 파일 없음";
    lastStructuredItems = [];
    transformText();
    updateResultStats([], [], getActiveOutputValue());
  }else{
    if(input) input.value="";
    if(output){ setResultOutput(output, ""); setResultOutputScroll(output, 0); }
    if(classicFileInput) classicFileInput.value = "";
    if(classicFileNameEl) classicFileNameEl.textContent = "선택된 파일 없음";
    if(excerptStartTextEl) excerptStartTextEl.value = "";
    if(excerptEndTextEl) excerptEndTextEl.value = "";
    classicLoadedFileText = "";
    classicLoadedChunks = null;
    classicActiveChunks = null;
    classicActiveDisplayText = "";
    lastStructuredItems = [];
    transformText();
    updateResultStats([], [], getActiveOutputValue());
  }
  updateEpubPreview();
  updateChapterDividerPanel();
  scheduleAutosave();
  showToast("초기화했습니다.");
}


// ------------------ 통계 / EPUB / 내보내기 ------------------
function stripHTMLTags(text){
  return String(text || "").replace(/<[^>]*>/g, "");
}
function normalizeSpeakerCompareLine(line){
  return stripHTMLTags(line || "").replace(/\s+/g, "").trim();
}
function getPossibleSpeakerLabels(){
  const names = [getSpeakerName("user"), getSpeakerName("character")].filter(Boolean);
  const marker = getSpeakerMarker();
  const labels = [];
  names.forEach(name => {
    labels.push(name);
    if(marker) labels.push(marker + name, marker + " " + name);
  });
  return labels.map(normalizeSpeakerCompareLine).filter(Boolean);
}
function stripSpeakerLabelLines(text){
  const labels = new Set(getPossibleSpeakerLabels());
  if(!labels.size) return text;
  return String(text || "").split(/\n/).filter(line => !labels.has(normalizeSpeakerCompareLine(line))).join("\n").replace(/\n{3,}/g,"\n\n").trim();
}
function getPreparedOutputForExport(){
  const active = getActiveOutput();
  let text = activeMode === "epubedit" ? editorPlainText(epubEditEditor) : ((active && active.value) || "");
  text = String(text || "").replace(/\r/g, "");
  const mode = epubTextModeEl ? epubTextModeEl.value : "current";
  const labelMode = speakerLabelModeEl ? speakerLabelModeEl.value : "output";
  if(mode === "removeLabels" || labelMode === "hideInEpub" || labelMode === "reviewOnly"){
    text = stripSpeakerLabelLines(text);
  }
  if(mode === "novel"){
    text = stripSpeakerLabelLines(text).replace(/\n{3,}/g,"\n\n").trim();
  }
  return text.trim();
}
function getResultStats(text, chunks){
  const clean = stripHTMLTags(text || "");
  const paragraphs = clean.split(/\n\s*\n+/).map(p=>p.trim()).filter(Boolean);
  return {
    chars: clean.length,
    charsNoSpace: clean.replace(/\s/g,"").length,
    paragraphs: paragraphs.length,
    chunks: chunks.length,
    scenes: chunks.filter(c => c.kind === "scene").length,
    dialogues: chunks.filter(c => c.kind !== "scene").length,
    user: chunks.filter(c => c.owner === "user").length,
    character: chunks.filter(c => c.owner === "character").length
  };
}
function fmtNum(n){ return Number(n || 0).toLocaleString("ko-KR"); }
function updateResultStats(chunks, blocks, renderedText){
  const stats = getResultStats(renderedText || "", chunks || []);
  if(resultStatsEl){
    resultStatsEl.innerHTML = `
      <div class="stat"><strong>${fmtNum(stats.chars)}</strong><span>글자</span></div>
      <div class="stat"><strong>${fmtNum(stats.charsNoSpace)}</strong><span>공백 제외</span></div>
      <div class="stat"><strong>${fmtNum(stats.paragraphs)}</strong><span>문단</span></div>
      <div class="stat"><strong>${fmtNum(stats.scenes)}</strong><span>지문</span></div>
      <div class="stat"><strong>${fmtNum(stats.dialogues)}</strong><span>대사</span></div>
      <div class="stat"><strong>${fmtNum(currentDuplicateGroups.length)}</strong><span>중복 묶음</span></div>
      <div class="stat"><strong>${fmtNum(currentContainsItems.length)}</strong><span>키워드 후보</span></div>`;
  }
  updateRiskPanel(renderedText || "", chunks || []);
  if(workflowHintEl){
    const missing = !renderedText ? "입력하면 바로 정리됩니다." : `${fmtNum(stats.paragraphs)}개 문단 준비됨`;
    workflowHintEl.textContent = missing;
  }
}
const RISK_TERMS = ["OOC", "시스템", "기록지", "설정", "요약", "이전 대화", "AI", "모델", "검열", "�", "제3자 개입", "분위기 반전", "복선 회수", "상황 주도", "장면 전환", "시간 경과", "사건 발생", "이어서 진행"];
function countTermInsensitive(text, term){
  const hay = String(text || "").toLowerCase();
  const needle = String(term || "").toLowerCase();
  if(!needle) return 0;
  let count = 0, pos = 0;
  while((pos = hay.indexOf(needle, pos)) !== -1){ count++; pos += needle.length; }
  return count;
}
function updateRiskPanel(text, chunks){
  if(!riskPanelEl) return;
  const fullText = String(text || "");
  const responseText = Array.isArray(chunks)
    ? chunks.filter(chunk => chunk && chunk.owner === "character").map(chunk => String(chunk.text || "")).join("\n")
    : "";
  const braceSource = responseText || fullText;
  const found = RISK_TERMS
    .map(term => ({term, count:countTermInsensitive(fullText, term)}))
    .filter(x => x.count > 0);
  RESPONSE_BRACE_RISK_TERMS.forEach(term => {
    const count = countTermInsensitive(braceSource, term);
    if(count > 0) found.push({term, count});
  });
  if(!found.length){
    riskPanelEl.innerHTML = `<div class="emptyState">위험 문구 없음</div>`;
    return;
  }
  riskPanelEl.innerHTML = found.map(x => `<button type="button" class="riskChip" onclick="appendDeleteKeyword('${escapeAttr(x.term)}')"><span>${escapeHTML(x.term)}</span><b>${x.count}</b></button>`).join("") + `<div class="miniHelp">누르면 삭제 키워드에 추가됩니다.</div>`;
}
function appendDeleteKeyword(term){
  const tokens = splitTokens(deleteContainsTokenEl.value || "");
  if(!tokens.some(t => t.toLowerCase() === String(term).toLowerCase())) tokens.push(term);
  deleteContainsTokenEl.value = tokens.join(", ");
  deleteContainsEnabledEl.checked = true;
  deleteContainsModeEl.value = "review";
  transformText();
  showToast("검토 키워드에 추가했습니다.");
}
function resetDuplicateChoices(){
  if(!window.confirm("중복 답변 검토 선택을 초기화하시겠습니까?")) return;
  duplicateDecisions = {};
  duplicatePageByGroup = {};
  duplicateGroupPage = 0;
  duplicateFilterText = "";
  duplicateOrderQuery = "";
  oocGroupPage = 0;
  oocFilterText = "";
  oocOrderQuery = "";
  transformText();
  showToast("중복 선택을 초기화했습니다.");
}
function resetContainsChoices(){
  if(!window.confirm("키워드 검토 선택을 초기화하시겠습니까?")) return;
  containsDecisions = {};
  transformText();
  showToast("키워드 검토 선택을 초기화했습니다.");
}
function resetReviewOnly(){
  if(!window.confirm("모든 검토 선택을 초기화하시겠습니까?")) return;
  resetReviewDecisions();
  transformText();
  showToast("검토 선택을 초기화했습니다.");
}

function getActiveOutputValue(){
  if(activeMode === "epubedit") return epubEditEditor ? editorPlainText(epubEditEditor) : "";
  const el = getActiveOutput();
  return el ? (el.value || "") : "";
}
function getPlainActiveOutputValue(){
  return stripHTMLTags(getActiveOutputValue()).replace(/&nbsp;/gi, " ").trim();
}
function setActiveOutputValue(value){
  if(activeMode === "epubedit"){
    if(epubEditEditor) epubEditEditor.innerHTML = plainTextToHtml(value || "");
    updateResultStats([], [], value || "");
    updateEpubPreview();
    updateChapterDividerPanel();
    scheduleAutosave();
    return;
  }
  const el = getActiveOutput();
  if(!el) return;
  setResultOutput(el, value);
  updateResultStats([], [], value || "");
  updateEpubPreview();
  updateChapterDividerPanel();
  scheduleAutosave();
}
function splitOutputParagraphsWithOffsets(text){
  const re = /\n\s*\n+/g;
  const parts = [];
  let start = 0;
  let m;
  while((m = re.exec(text))){
    const raw = text.slice(start, m.index);
    if(raw.trim()) parts.push({text:raw.trim(), start, end:m.index});
    start = re.lastIndex;
  }
  const raw = text.slice(start);
  if(raw.trim()) parts.push({text:raw.trim(), start, end:text.length});
  return parts;
}
function getChapterSearchMatches(){
  const q = String(chapterKeywordQuery || "").trim().toLowerCase();
  const order = String(chapterOrderQuery || "").trim();
  const text = getActiveOutputValue();
  let matches = splitOutputParagraphsWithOffsets(text).map((p, index) => ({...p, index}));
  if(q) matches = matches.filter(p => p.text.toLowerCase().includes(q));
  if(order){
    const n = Number(order);
    if(Number.isFinite(n) && n > 0) matches = matches.filter((_p, idx) => idx + 1 === n || _p.index + 1 === n);
  }
  return matches;
}
function updateChapterDividerPanel(){
  if(!chapterDividerPanelEl) return;
  const separator = (chapterSeparatorEl && chapterSeparatorEl.value.trim()) || "—————";
  const useSeparatorMode = chapterSplitModeEl && chapterSplitModeEl.value === "separator";
  currentChapterMatches = getChapterSearchMatches();
  const total = currentChapterMatches.length;
  chapterMatchPage = Math.max(0, Math.min(Math.max(0, total - 1), chapterMatchPage || 0));
  const current = total ? currentChapterMatches[chapterMatchPage] : null;
  let html = `<div class="miniToolHead"><div><strong>구분선 삽입</strong><span>${useSeparatorMode ? "검색한 지문 위/아래에 챕터 구분선을 넣습니다." : "나누기를 구분선 기준으로 바꾸면 EPUB 챕터가 나뉩니다."}</span></div><span class="smallMuted">${total ? `${chapterMatchPage + 1}/${total}` : "0개"}</span></div>`;
  if(!total){
    html += `<div class="emptyState">키워드를 입력하면 해당 문단이 표시됩니다.</div>`;
  }else{
    const prevDisabled = chapterMatchPage <= 0 ? "disabled" : "";
    const nextDisabled = chapterMatchPage >= total - 1 ? "disabled" : "";
    html += `<div class="chapterMatchCard"><div class="dupeSummary withNav"><span><span class="pill">문단 ${current.index + 1}</span><span class="pill">구분선 ${escapeHTML(separator)}</span></span><span class="navButtons"><button type="button" class="navIconBtn" data-chapter-match-page="prev" ${prevDisabled} aria-label="이전 문단">‹</button><button type="button" class="navIconBtn" data-chapter-match-page="next" ${nextDisabled} aria-label="다음 문단">›</button></span></div><div class="previewText fullPreview">${escapeHTML(current.text)}</div><div class="chapterInsertRow"><button type="button" class="btn primary" data-chapter-insert="1">현재 문단에 구분선 넣기</button></div></div>`;
  }
  chapterDividerPanelEl.innerHTML = html;
}
function makeEditorChapterSeparator(separator){
  const hr = document.createElement("hr");
  hr.setAttribute("data-chapter-separator", "true");
  hr.setAttribute("aria-label", separator || "챕터 구분선");
  hr.className = "chapter-editor-separator";
  return hr;
}
function insertChapterDividerIntoEditor(current, position, separator){
  if(!epubEditEditor) return false;
  const normalize = value => String(value || "").replace(/\s+/g, " ").trim();
  const nodes = Array.from(epubEditEditor.childNodes).filter(node => {
    if(node.nodeType === Node.ELEMENT_NODE && node.tagName === "HR") return true;
    return !!normalize(node.innerText || node.textContent || "");
  });
  const wanted = normalize(current && current.text);
  let target = nodes.find(node => normalize(node.innerText || node.textContent || "") === wanted);
  if(!target) target = nodes[current ? current.index : -1];
  const marker = makeEditorChapterSeparator(separator);
  if(target && target.parentNode){
    target.parentNode.insertBefore(marker, position === "after" ? target.nextSibling : target);
  }else{
    epubEditEditor.appendChild(marker);
  }
  return true;
}
function refreshChapterViews(){
  updateEpubPreview();
  updateChapterDividerPanel();
  requestAnimationFrame(() => updateEpubPreview());
}
function insertChapterDividerAtCurrentMatch(){
  const matches = getChapterSearchMatches();
  if(!matches.length){ showToast("구분선을 넣을 문단을 찾지 못했습니다."); return; }
  const current = matches[Math.max(0, Math.min(matches.length - 1, chapterMatchPage || 0))];
  const separator = (chapterSeparatorEl && chapterSeparatorEl.value.trim()) || "—————";
  const position = chapterPositionEl ? chapterPositionEl.value : "before";
  if(chapterSplitModeEl) chapterSplitModeEl.value = "separator";

  if(activeMode === "epubedit" && epubEditEditor){
    insertChapterDividerIntoEditor(current, position, separator);
    refreshChapterViews();
    scheduleAutosave();
  }else{
    const text = getActiveOutputValue();
    const paras = splitOutputParagraphsWithOffsets(text).map(p => p.text);
    const insertAt = position === "after" ? current.index + 1 : current.index;
    paras.splice(insertAt, 0, separator);
    setActiveOutputValue(paras.join("\n\n"));
    refreshChapterViews();
    scheduleAutosave();
  }
  showToast(position === "after" ? "문단 아래에 구분선을 넣었습니다." : "문단 위에 구분선을 넣었습니다.");
}
function handleChapterDividerClick(e){
  const pageBtn = e.target.closest("button[data-chapter-match-page]");
  if(pageBtn){
    const max = Math.max(0, currentChapterMatches.length - 1);
    chapterMatchPage = pageBtn.dataset.chapterMatchPage === "next" ? Math.min(max, chapterMatchPage + 1) : Math.max(0, chapterMatchPage - 1);
    updateChapterDividerPanel();
    scheduleAutosave();
    return;
  }
  if(e.target.closest("button[data-chapter-insert]")) insertChapterDividerAtCurrentMatch();
}
function getEpubConfig(){
  const title = (epubTitleEl && epubTitleEl.value.trim()) || "정리한 로그";
  return {
    title,
    subtitle: (epubSubtitleEl && epubSubtitleEl.value.trim()) || "",
    author: (epubAuthorEl && epubAuthorEl.value.trim()) || "",
    series: (epubSeriesEl && epubSeriesEl.value.trim()) || "",
    volume: (epubVolumeEl && epubVolumeEl.value.trim()) || "",
    description: (epubDescriptionEl && epubDescriptionEl.value.trim()) || "",
    tags: splitTokens(epubTagsEl ? epubTagsEl.value : ""),
    language: (epubLanguageEl && epubLanguageEl.value.trim()) || "ko",
    chapterMode: chapterSplitModeEl ? chapterSplitModeEl.value : "none",
    chapterSize: Math.max(1, parseInt(chapterSizeEl ? chapterSizeEl.value : "7000", 10) || 7000),
    separator: (chapterSeparatorEl && chapterSeparatorEl.value.trim()) || "—————",
    chapterPrefix: (chapterTitlePrefixEl && chapterTitlePrefixEl.value.trim()) || "Chapter",
    firstChapterTitle: (chapterFirstTitleEl && chapterFirstTitleEl.value.trim()) || "",
    stylePreset: epubStylePresetEl ? epubStylePresetEl.value : "novel"
  };
}
function getChapterTitle(idx, cfg){
  const c = cfg || getEpubConfig();
  if(idx === 0 && c.firstChapterTitle) return c.firstChapterTitle;
  return `${c.chapterPrefix} ${idx + 1}`;
}
function chapterLeadText(ch){
  const raw = ch && ch.bodyHtml ? blockHtmlToText(ch.bodyHtml) : String((ch && ch.body) || "");
  return raw.replace(/\s+/g, " ").trim().slice(0, 80);
}
function renderChapterTocHtml(chapters, compact){
  if(!chapters || !chapters.length) return `<div class="emptyState">챕터가 아직 없습니다. 결과가 생기면 목차가 표시됩니다.</div>`;
  const rows = chapters.slice(0, compact ? 12 : 50).map((ch, idx) => {
    const count = fmtNum(stripHTMLTags(ch.body || blockHtmlToText(ch.bodyHtml || "")).length);
    const lead = chapterLeadText(ch);
    return `<div class="chapterTocRow"><b>${idx + 1}</b><span><strong>${escapeHTML(ch.title)}</strong>${lead ? `<small>${escapeHTML(lead)}</small>` : ""}</span><em>${count}자</em></div>`;
  }).join("");
  const more = chapters.length > (compact ? 12 : 50) ? `<div class="miniHelp">외 ${chapters.length - (compact ? 12 : 50)}개 챕터</div>` : "";
  return `<div class="chapterTocBox"><div class="tocSummary"><strong>현재 목차</strong><span>${chapters.length}개 챕터</span></div>${rows}${more}</div>`;
}
function splitTextIntoParagraphs(text){
  return String(text || "").replace(/\r/g,"").split(/\n\s*\n+/).map(p => p.trim()).filter(Boolean);
}
function isConfiguredChapterSeparator(text, cfg){
  const raw = String(text || "");
  const clean = raw.replace(/<[^>]*>/g, "").replace(/&nbsp;/gi, " ").replace(/\s+/g, "").trim();
  const sep = String((cfg && cfg.separator) || (chapterSeparatorEl && chapterSeparatorEl.value) || "—————").replace(/\s+/g, "").trim();
  if(!clean || !sep) return false;
  if(clean === sep) return true;
  const dashLine = /^[\-—―─━_]{3,}$/;
  return dashLine.test(clean) && dashLine.test(sep);
}

function splitTextIntoChapters(text){
  const cfg = getEpubConfig();
  const source = String(text || "").trim();
  if(!source) return [];
  const chapters = [];
  const makeTitle = (idx) => getChapterTitle(idx, cfg);
  if(cfg.chapterMode === "separator"){
    const paras = splitTextIntoParagraphs(source);
    let bucket = [];
    const flush = () => {
      const body = bucket.join("\n\n").trim();
      if(body) chapters.push({title:makeTitle(chapters.length), body});
      bucket = [];
    };
    paras.forEach(p => {
      if(isConfiguredChapterSeparator(p, cfg)) flush();
      else bucket.push(p);
    });
    flush();
  }else if(cfg.chapterMode === "paragraphs"){
    const paras = splitTextIntoParagraphs(source);
    for(let i=0; i<paras.length; i += cfg.chapterSize){
      chapters.push({title:makeTitle(chapters.length), body:paras.slice(i, i + cfg.chapterSize).join("\n\n")});
    }
  }else if(cfg.chapterMode === "chars"){
    const paras = splitTextIntoParagraphs(source);
    let bucket = [], count = 0;
    paras.forEach(p => {
      if(bucket.length && count + p.length > cfg.chapterSize){
        chapters.push({title:makeTitle(chapters.length), body:bucket.join("\n\n")});
        bucket = []; count = 0;
      }
      bucket.push(p); count += p.length;
    });
    if(bucket.length) chapters.push({title:makeTitle(chapters.length), body:bucket.join("\n\n")});
  }else{
    chapters.push({title:cfg.title, body:source});
  }
  return chapters.length ? chapters : [{title:cfg.title, body:source}];
}
function escapeXML(str){
  return String(str || "")
    .replace(/&/g,"&amp;")
    .replace(/</g,"&lt;")
    .replace(/>/g,"&gt;")
    .replace(/"/g,"&quot;")
    .replace(/'/g,"&#39;");
}
function restoreAllowedInlineSpans(escaped){
  return String(escaped || "").replace(/&lt;span\b([\s\S]*?)&gt;([\s\S]*?)&lt;\/span&gt;/gi, (match, rawAttrs, inner) => {
    const attrs = String(rawAttrs || "");
    const colorMatch = attrs.match(/color\s*:\s*(#[0-9a-fA-F]{6})/i);
    const color = colorMatch ? colorMatch[1] : "";
    const ownerMatch = attrs.match(/data-speaker-owner=&quot;([a-zA-Z_-]+)&quot;/i);
    const hasSpeakerClass = /speaker-label/i.test(attrs);
    const attrParts = [];
    if(hasSpeakerClass) attrParts.push('class="speaker-label"');
    if(ownerMatch) attrParts.push(`data-speaker-owner="${escapeXML(ownerMatch[1])}"`);
    if(color) attrParts.push(`style="color:${color}"`);
    if(!attrParts.length) return inner;
    return `<span ${attrParts.join(" ")}>${inner}</span>`;
  });
}
function paragraphToXhtml(p){
  const lines = String(p || "").split(/\n/).map(line => restoreAllowedInlineSpans(escapeXML(line)));
  return `<p>${lines.join("<br/>")}</p>`;
}
function textToXhtmlBody(text){
  return splitTextIntoParagraphs(text).map(paragraphToXhtml).join("\n");
}
function getEpubCss(){
  const preset = getEpubConfig().stylePreset;
  const fontFace = cachedEpubFontAsset ? `@font-face{font-family:"UploadedEpubFont";src:url("${escapeXML(cachedEpubFontAsset.epubName || cachedEpubFontAsset.name || "uploaded-font.woff")}");} body{font-family:"UploadedEpubFont",serif !important;}` : "";
  const base = `body{line-height:1.82;word-break:keep-all;overflow-wrap:break-word;} p{margin:0 0 1em;} h1{font-size:1.45em;margin:0 0 1.2em;} .cover{text-align:center;} .cover img{max-width:100%;height:auto;} blockquote{margin:1em 0;} .quoteLine{padding:.25em 0 .25em 1em;border-left:4px solid #4f8aa4;background:transparent;border-radius:0;text-align:left;} .quotePostype{padding:.9em 1.05em;border-left:4px solid #4f8aa4;background:#f3f9fc;border-radius:.75em;text-align:left;} .quoteBlog{padding:1em .5em;border-top:1px solid #bdd8e3;border-bottom:1px solid #bdd8e3;border-left:0;background:transparent;border-radius:0;text-align:center;} .quoteSoft{padding:1em 1.1em;border-left:0;background:#eaf5fa;border:1px solid #d4e9f1;border-radius:1em;text-align:center;} .rofan-block[data-owner]{margin:0 0 1em;} .rofan-block[data-kind="scene"]{font-style:normal;}`;
  if(preset === "paper") return fontFace + base + ` body{font-family:serif;} p{text-indent:1em;margin-bottom:.65em;}`;
  if(preset === "script") return fontFace + base + ` body{font-family:sans-serif;} p{margin-bottom:1.1em;} p:nth-child(odd){padding-left:.5em;border-left:2px solid #ddd;}`;
  if(preset === "backup") return fontFace + base + ` body{font-family:monospace;font-size:.92em;} p{white-space:pre-wrap;margin-bottom:1.2em;}`;
  return fontFace + base + ` body{font-family:serif;} p{margin-bottom:.95em;}`;
}
function updateEpubPreview(){
  const text = getPreparedOutputForExport();
  const chapters = getExportChapters();
  const cfg = getEpubConfig();
  if(chapterPreviewEl){
    chapterPreviewEl.innerHTML = renderChapterTocHtml(chapters, false);
  }
  if(chapterTocInlineEl){
    chapterTocInlineEl.innerHTML = renderChapterTocHtml(chapters, true);
  }
  if(epubPreviewEl){
    const first = chapters[0] ? chapters[0].body : "";
    const previewBody = activeMode === "epubedit" && chapters[0] && chapters[0].bodyHtml ? chapterBodyToXhtml(chapters[0]) : splitTextIntoParagraphs(first).slice(0, 12).map(paragraphToXhtml).join("\n");
    epubPreviewEl.innerHTML = `
      <div class="previewMeta"><b>${escapeHTML(cfg.title)}</b>${cfg.author ? `<span>${escapeHTML(cfg.author)}</span>` : ""}<span>${chapters.length || 0}개 챕터</span></div>
      <div class="bookPreview">${previewBody || `<p class="mutedText">미리보기 없음</p>`}</div>`;
  }
}
function safeFileName(name, ext){
  const base = String(name || "download").replace(/[\\/:*?"<>|]/g,"_").replace(/\s+/g,"_").slice(0,80) || "download";
  return base + ext;
}
function downloadBlob(blob, filename){
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function itemKindLabel(kind){ return kind === "scene" ? "scene" : "dialogue"; }
function safeMetaValue(value, fallback){
  const v = String(value || "").replace(/[;\n>]/g, "").trim();
  return v || fallback;
}
function stripCurrentSpeakerLabelsFromItemText(text){
  return stripSpeakerLabelLines(String(text || "")).trim();
}
function shouldKeepSpeakerLabelsForExport(){
  if(!(activeMode === "chat" || activeMode === "classic")) return false;
  if(!labelSpeakersEl || !labelSpeakersEl.checked) return false;
  const mode = speakerLabelModeEl ? speakerLabelModeEl.value : "output";
  return mode === "output";
}
function mergeStructuredItemsByBlock(items){
  const out = [];
  (items || []).forEach((item, idx) => {
    if(!item || !String(item.text || "").trim()) return;
    const blockId = item.blockId || ("block-" + idx);
    const owner = item.owner || "character";
    const kind = item.kind || "normal";
    const last = out[out.length - 1];
    if(last && last.blockId === blockId && last.owner === owner && last.kind === kind){
      last.text = [last.text, item.text].filter(Boolean).join("\n\n");
    }else{
      out.push({blockId, owner, kind, text:item.text || ""});
    }
  });
  return out;
}

function structuredItemsToHtml(items){
  return mergeStructuredItemsByBlock(items).map((item, idx) => {
    const owner = escapeAttr(safeMetaValue(item.owner, idx === 0 ? "character" : "character"));
    const kind = escapeAttr(safeMetaValue(item.kind, "normal"));
    const blockId = escapeAttr(safeMetaValue(item.blockId, "block-" + idx));
    const cleanText = shouldKeepSpeakerLabelsForExport() ? String(item.text || "").trim() : stripCurrentSpeakerLabelsFromItemText(item.text || "");
    const paragraphs = String(cleanText || "").split(/\n+/).filter(Boolean).map(t => `<p>${htmlFromResultText(t)}</p>`).join("\n");
    return paragraphs ? `<div class="rofan-block" data-block-id="${blockId}" data-owner="${owner}" data-kind="${kind}">${paragraphs}</div>` : "";
  }).filter(Boolean).join("\n");
}
function structuredItemsToMarkdown(items){
  return mergeStructuredItemsByBlock(items).map((item, idx) => {
    const owner = safeMetaValue(item.owner, idx === 0 ? "character" : "character");
    const kind = safeMetaValue(item.kind, "normal");
    const blockId = safeMetaValue(item.blockId, "block-" + idx);
    const body = shouldKeepSpeakerLabelsForExport() ? String(item.text || "").trim() : stripCurrentSpeakerLabelsFromItemText(item.text || "");
    return body ? `<!-- rofan:block=${blockId};owner=${owner};kind=${kind} -->\n${body}` : "";
  }).filter(Boolean).join("\n\n");
}

function chunksToStructuredMarkdown(chunks){
  return structuredItemsToMarkdown((chunks || []).filter(c => c && String(c.text || '').trim()).map((c, idx) => ({
    blockId: c.blockId || ('block-' + idx),
    owner: c.owner || 'character',
    kind: c.kind || 'normal',
    text: c.text || ''
  })));
}
function parseRofanCommentAttrs(src){
  const attrs = {};
  String(src || "").split(";").forEach(part => {
    const eq = part.indexOf("=");
    if(eq < 0) return;
    const key = part.slice(0, eq).trim().toLowerCase();
    const val = part.slice(eq + 1).trim();
    if(key) attrs[key] = val;
  });
  return attrs;
}
function parseStructuredMarkdownToChunks(raw){
  const text = String(raw || '').replace(/\r/g, '');
  const re = /<!--\s*rofan:([^>]*)-->/gi;
  let match, last = 0, items = [];
  while((match = re.exec(text))){
    if(items.length){ items[items.length - 1].body = text.slice(last, match.index).trim(); }
    const attrs = parseRofanCommentAttrs(match[1] || "");
    const owner = safeMetaValue(attrs.owner, 'character');
    const kind = safeMetaValue(attrs.kind, 'normal');
    let block = safeMetaValue(attrs.block || attrs.blockid || attrs['block-id'], '');
    if(!block){
      const prev = items[items.length - 1];
      block = prev && prev.owner === owner ? prev.block : ('md-' + items.length);
    }
    items.push({owner, kind, block, body:''});
    last = re.lastIndex;
  }
  if(!items.length) return null;
  items[items.length - 1].body = text.slice(last).trim();
  const chunks = [];
  let seq = 0;
  items.forEach((it) => {
    String(it.body || '').split(/\n\s*\n+/).map(p => p.trim()).filter(Boolean).forEach(p => {
      chunks.push({id:'mdc-' + (seq++), kind:it.kind || 'normal', owner:it.owner || 'character', text:p, color:'', fromTable:false, fromDetails:false, blockId:it.block || ('md-' + seq)});
    });
  });
  return chunks.length ? normalizeChunkResponseBlocks(chunks) : null;
}

function structuredMarkdownToHtml(raw){
  const chunks = parseStructuredMarkdownToChunks(raw);
  return chunks ? structuredItemsToHtml(chunks.map(c => ({blockId:c.blockId, owner:c.owner, kind:c.kind, text:c.text}))) : '';
}
function parseHtmlToRofanChunks(html){
  const holder = document.createElement('div');
  holder.innerHTML = sanitizePastedHTML(extractLikelyChatHTML(String(html || '')));
  return parseRofanChatChunks(holder).chunks || [];
}

function fileContentToChunks(raw, fileName, bytes){
  const lower = String(fileName || '').toLowerCase();
  const text = String(raw || '');
  if(/\.(md|markdown)$/i.test(lower) || /<!--\s*rofan:/i.test(text)){
    const chunks = parseStructuredMarkdownToChunks(text);
    if(chunks && chunks.length) return chunks;
  }
  if(/\.(mht|mhtml)$/i.test(lower) || /MIME-Version:\s*1\.0/i.test(text) || /Content-Type:\s*multipart\/related/i.test(text)){
    const html = bytes ? (extractHTMLFromMHTBytes(bytes) || extractHTMLFromMHT(text)) : extractHTMLFromMHT(text);
    const chunks = parseHtmlToRofanChunks(html);
    if(chunks && chunks.length) return chunks;
  }
  if(/\.(html|htm)$/i.test(lower) || looksLikeHTML(text)){
    const chunks = parseHtmlToRofanChunks(text);
    if(chunks && chunks.length) return chunks;
  }
  return null;
}
function cloneChunks(chunks){
  return (chunks || []).map((c, idx) => Object.assign({}, c, {id:c.id || ('clone-' + idx)}));
}
function chunksDisplayText(chunks){
  return (chunks || []).map(c => c.text || '').filter(Boolean).join("\n\n").trim();
}
function sliceChunksByStartEnd(chunks, startNeedle, endNeedle){
  const records = [];
  let text = "";
  (chunks || []).forEach((c, idx) => {
    if(idx) text += "\n\n";
    const start = text.length;
    text += c.text || "";
    const end = text.length;
    records.push({chunk:c, start, end});
  });
  let rangeStart = 0, rangeEnd = text.length;
  const start = String(startNeedle || "").trim();
  const end = String(endNeedle || "").trim();
  if(start){ const i = text.indexOf(start); if(i >= 0) rangeStart = i; }
  if(end){ const j = text.indexOf(end, rangeStart); if(j >= 0) rangeEnd = j + end.length; }
  return records.filter(r => r.end > rangeStart && r.start < rangeEnd).map(r => Object.assign({}, r.chunk));
}
function fileContentToStructuredMarkdown(raw, fileName){
  const chunks = fileContentToChunks(raw, fileName);
  if(chunks && chunks.length) return chunksToStructuredMarkdown(chunks);
  return String(raw || '');
}

function exportedBodyHtml(){
  if(activeMode !== "epubedit" && lastStructuredItems && lastStructuredItems.length){
    return structuredItemsToHtml(lastStructuredItems);
  }
  return getExportChapters().map(ch => chapterBodyToXhtml(ch)).join("\n");
}

function buildStandaloneHTML(){
  const cfg = getEpubConfig();
  const chapters = getExportChapters();
  const toc = chapters.map((ch, idx) => `<li><a href="#ch${idx+1}">${escapeXML(ch.title)}</a></li>`).join("\n");
  const body = (activeMode !== "epubedit" && lastStructuredItems && lastStructuredItems.length)
    ? `<section id="ch1"><h1>${escapeXML(cfg.title)}</h1>${structuredItemsToHtml(lastStructuredItems)}</section>`
    : chapters.map((ch, idx) => `<section id="ch${idx+1}"><h1>${escapeXML(ch.title)}</h1>${chapterBodyToXhtml(ch)}</section>`).join("\n");
  return `<!doctype html><html lang="${escapeXML(cfg.language)}"><head><meta charset="utf-8"><title>${escapeXML(cfg.title)}</title><style>${getEpubCss()} nav{margin-bottom:2rem;padding:1rem;border:1px solid #ddd;border-radius:12px;} section{max-width:720px;margin:0 auto 3rem;}</style></head><body><nav><strong>목차</strong><ol>${toc}</ol></nav>${body}</body></html>`;
}
function downloadHtml(){
  const cfg = getEpubConfig();
  downloadBlob(new Blob([buildStandaloneHTML()], {type:"text/html;charset=utf-8"}), safeDownloadFileName(".html", cfg.title));
}
function downloadMarkdown(){
  const cfg = getEpubConfig();
  const chapters = getExportChapters(true);
  let md = `# ${cfg.title}\n\n`;
  if(cfg.subtitle) md += `_${cfg.subtitle}_\n\n`;
  if(cfg.author) md += `작가: ${cfg.author}\n\n`;
  if(cfg.description) md += `${cfg.description}\n\n`;
  if(activeMode !== "epubedit" && lastStructuredItems && lastStructuredItems.length){
    md += structuredItemsToMarkdown(lastStructuredItems) + "\n";
  }else if(activeMode === "epubedit" && editorStructuredMarkdown()){
    md += editorStructuredMarkdown() + "\n";
  }else if(activeMode === "epubedit"){
    md += editorHtmlForExport() + "\n";
  }else{
    chapters.forEach(ch => { md += `## ${ch.title}\n\n${ch.body}\n\n`; });
  }
  downloadBlob(new Blob([md], {type:"text/markdown;charset=utf-8"}), safeDownloadFileName(".md", cfg.title));
}
function downloadDoc(){
  const cfg = getEpubConfig();
  const html = buildStandaloneHTML();
  downloadBlob(new Blob([html], {type:"application/msword;charset=utf-8"}), safeDownloadFileName(".doc", cfg.title));
}
function makeXhtmlDoc(title, body){
  return `<?xml version="1.0" encoding="utf-8"?>\n<!DOCTYPE html>\n<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops" lang="${escapeXML(getEpubConfig().language)}" xml:lang="${escapeXML(getEpubConfig().language)}"><head><meta charset="utf-8"/><title>${escapeXML(title)}</title><link rel="stylesheet" type="text/css" href="styles.css"/></head><body>${body}</body></html>`;
}
async function getCoverInfo(){
  const file = epubCoverInputEl && epubCoverInputEl.files && epubCoverInputEl.files[0];
  const typeMap = {jpg:"image/jpeg", jpeg:"image/jpeg", png:"image/png", webp:"image/webp", gif:"image/gif"};
  if(file){
    const ext = (file.name.split(".").pop() || "jpg").toLowerCase().replace(/[^a-z0-9]/g,"") || "jpg";
    return {name:`cover.${ext}`, media:typeMap[ext] || file.type || "image/jpeg", data:new Uint8Array(await file.arrayBuffer())};
  }
  if(cachedCoverAsset && cachedCoverAsset.dataUrl){
    const ext = ((cachedCoverAsset.name || "cover.jpg").split(".").pop() || "jpg").toLowerCase().replace(/[^a-z0-9]/g,"") || "jpg";
    return {name:`cover.${ext}`, media:typeMap[ext] || cachedCoverAsset.type || "image/jpeg", data:dataUrlToUint8Array(cachedCoverAsset.dataUrl)};
  }
  return null;
}
function uuidLike(){
  const s = `${Date.now()}-${Math.random()}-${getEpubConfig().title}`;
  return "id-" + hashString(s);
}
async function downloadEpub(){
  const cfg = getEpubConfig();
  const chapters = getExportChapters();
  if(!chapters.length){ showToast("EPUB으로 만들 결과가 없습니다."); return; }
  const cover = await getCoverInfo();
  const entries = [];
  entries.push({name:"mimetype", data:"application/epub+zip"});
  entries.push({name:"META-INF/container.xml", data:`<?xml version="1.0" encoding="UTF-8"?><container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container"><rootfiles><rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/></rootfiles></container>`});
  entries.push({name:"OEBPS/styles.css", data:getEpubCss()});
  const chapterItems = [];
  chapters.forEach((ch, idx) => {
    const file = `chapter-${String(idx+1).padStart(3,"0")}.xhtml`;
    chapterItems.push({id:`ch${idx+1}`, href:file, title:ch.title});
    entries.push({name:`OEBPS/${file}`, data:makeXhtmlDoc(ch.title, `<h1>${escapeXML(ch.title)}</h1>${chapterBodyToXhtml(ch)}`)});
  });
  if(cachedEpubFontAsset && cachedEpubFontAsset.dataUrl){
    entries.push({name:`OEBPS/${cachedEpubFontAsset.epubName || cachedEpubFontAsset.name}`, data:dataUrlToUint8Array(cachedEpubFontAsset.dataUrl)});
  }
  if(cover){
    entries.push({name:`OEBPS/${cover.name}`, data:cover.data});
    entries.push({name:"OEBPS/cover.xhtml", data:makeXhtmlDoc("Cover", `<section class="cover"><img src="${escapeXML(cover.name)}" alt="cover"/></section>`)});
  }
  const navItems = chapterItems.map(item => `<li><a href="${escapeXML(item.href)}">${escapeXML(item.title)}</a></li>`).join("");
  entries.push({name:"OEBPS/nav.xhtml", data:makeXhtmlDoc("목차", `<nav epub:type="toc" id="toc"><h1>목차</h1><ol>${navItems}</ol></nav>`)});
  const uid = uuidLike();
  const metaTags = [
    `<dc:identifier id="pub-id">${escapeXML(uid)}</dc:identifier>`,
    `<dc:title>${escapeXML(cfg.title)}</dc:title>`,
    cfg.subtitle ? `<dc:title id="subtitle">${escapeXML(cfg.subtitle)}</dc:title>` : "",
    cfg.author ? `<dc:creator>${escapeXML(cfg.author)}</dc:creator>` : "",
    `<dc:language>${escapeXML(cfg.language)}</dc:language>`,
    cfg.description ? `<dc:description>${escapeXML(cfg.description)}</dc:description>` : "",
    ...cfg.tags.map(tag => `<dc:subject>${escapeXML(tag)}</dc:subject>`),
    cfg.series ? `<meta property="belongs-to-collection" id="series">${escapeXML(cfg.series)}</meta>` : "",
    cfg.volume ? `<meta property="group-position">${escapeXML(cfg.volume)}</meta>` : "",
    `<meta property="dcterms:modified">${new Date().toISOString().replace(/\.\d{3}Z$/, "Z")}</meta>`,
    cover ? `<meta name="cover" content="cover-image"/>` : ""
  ].filter(Boolean).join("\n");
  const manifest = [
    `<item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/>`,
    `<item id="css" href="styles.css" media-type="text/css"/>`,
    cover ? `<item id="cover" href="cover.xhtml" media-type="application/xhtml+xml"/>` : "",
    cover ? `<item id="cover-image" href="${escapeXML(cover.name)}" media-type="${escapeXML(cover.media)}" properties="cover-image"/>` : "",
    cachedEpubFontAsset ? `<item id="uploaded-font" href="${escapeXML(cachedEpubFontAsset.epubName || cachedEpubFontAsset.name)}" media-type="${escapeXML(cachedEpubFontAsset.type || "font/woff")}"/>` : "",
    ...chapterItems.map(item => `<item id="${item.id}" href="${escapeXML(item.href)}" media-type="application/xhtml+xml"/>`)
  ].filter(Boolean).join("\n");
  const spine = [cover ? `<itemref idref="cover" linear="no"/>` : "", ...chapterItems.map(item => `<itemref idref="${item.id}"/>`)].filter(Boolean).join("\n");
  const opf = `<?xml version="1.0" encoding="UTF-8"?><package version="3.0" unique-identifier="pub-id" xmlns="http://www.idpf.org/2007/opf" xmlns:dc="http://purl.org/dc/elements/1.1/"><metadata>${metaTags}</metadata><manifest>${manifest}</manifest><spine>${spine}</spine></package>`;
  entries.push({name:"OEBPS/content.opf", data:opf});
  const blob = createZipBlob(entries, "application/epub+zip");
  downloadBlob(blob, safeDownloadFileName(".epub", cfg.title));
}
let CRC_TABLE = null;
function getCRCTable(){
  if(CRC_TABLE) return CRC_TABLE;
  CRC_TABLE = new Uint32Array(256);
  for(let n=0; n<256; n++){
    let c=n;
    for(let k=0; k<8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    CRC_TABLE[n] = c >>> 0;
  }
  return CRC_TABLE;
}
function crc32(bytes){
  const table = getCRCTable();
  let c = 0 ^ -1;
  for(let i=0; i<bytes.length; i++) c = (c >>> 8) ^ table[(c ^ bytes[i]) & 0xff];
  return (c ^ -1) >>> 0;
}
function dosDateTime(date){
  const d = date || new Date();
  const time = ((d.getHours() & 31) << 11) | ((d.getMinutes() & 63) << 5) | ((Math.floor(d.getSeconds()/2)) & 31);
  const day = ((d.getFullYear() - 1980) << 9) | ((d.getMonth()+1) << 5) | d.getDate();
  return {time, day};
}
function writeU16(dv, offset, value){ dv.setUint16(offset, value, true); }
function writeU32(dv, offset, value){ dv.setUint32(offset, value >>> 0, true); }
function createZipBlob(entries, type){
  const enc = new TextEncoder();
  const chunks = [];
  const central = [];
  let offset = 0;
  const dt = dosDateTime(new Date());
  entries.forEach(entry => {
    const nameBytes = enc.encode(entry.name);
    const dataBytes = entry.data instanceof Uint8Array ? entry.data : enc.encode(String(entry.data || ""));
    const crc = crc32(dataBytes);
    const local = new Uint8Array(30 + nameBytes.length);
    const dv = new DataView(local.buffer);
    writeU32(dv,0,0x04034b50); writeU16(dv,4,20); writeU16(dv,6,0x0800); writeU16(dv,8,0);
    writeU16(dv,10,dt.time); writeU16(dv,12,dt.day); writeU32(dv,14,crc); writeU32(dv,18,dataBytes.length); writeU32(dv,22,dataBytes.length);
    writeU16(dv,26,nameBytes.length); writeU16(dv,28,0); local.set(nameBytes,30);
    chunks.push(local, dataBytes);
    const cd = new Uint8Array(46 + nameBytes.length);
    const cdv = new DataView(cd.buffer);
    writeU32(cdv,0,0x02014b50); writeU16(cdv,4,20); writeU16(cdv,6,20); writeU16(cdv,8,0x0800); writeU16(cdv,10,0);
    writeU16(cdv,12,dt.time); writeU16(cdv,14,dt.day); writeU32(cdv,16,crc); writeU32(cdv,20,dataBytes.length); writeU32(cdv,24,dataBytes.length);
    writeU16(cdv,28,nameBytes.length); writeU16(cdv,30,0); writeU16(cdv,32,0); writeU16(cdv,34,0); writeU16(cdv,36,0); writeU32(cdv,38,0); writeU32(cdv,42,offset);
    cd.set(nameBytes,46);
    central.push(cd);
    offset += local.length + dataBytes.length;
  });
  const centralSize = central.reduce((sum, c) => sum + c.length, 0);
  const centralOffset = offset;
  chunks.push(...central);
  const end = new Uint8Array(22);
  const edv = new DataView(end.buffer);
  writeU32(edv,0,0x06054b50); writeU16(edv,4,0); writeU16(edv,6,0); writeU16(edv,8,entries.length); writeU16(edv,10,entries.length); writeU32(edv,12,centralSize); writeU32(edv,16,centralOffset); writeU16(edv,20,0);
  chunks.push(end);
  return new Blob(chunks, {type:type || "application/zip"});
}
function collectPresetValues(){
  const ids = ["removeDetails","removeEmptyLines","removeCellEmptyLines","removeHTML","removeDecor","protectEnabled","protectToken","quoteStyle","indentOutput","deleteContainsEnabled","deleteContainsToken","deleteContainsMode","removeTables","reviewDuplicates","reviewOocPairs","oocCascadeMode","speakerLabelMode","labelSpeakers","userName","characterName","speakerMarkerPreset","speakerMarkerCustom","speakerLabelColor","speakerUserColor","speakerCharacterColor","speakerColorTarget","epubTitle","epubSubtitle","epubAuthor","epubSeries","epubVolume","epubDescription","epubTags","epubLanguage","chapterSplitMode","chapterSize","chapterSeparator","chapterTitlePrefix","chapterFirstTitle","chapterKeywordInput","chapterOrderInput","chapterPosition","epubStylePreset","epubTextMode","epubEditTextColor","epubQuoteColor","epubEditTextColorR","epubEditTextColorG","epubEditTextColorB","epubQuoteColorR","epubQuoteColorG","epubQuoteColorB"];
  const data = {};
  ids.forEach(id => {
    const el = document.getElementById(id);
    if(!el) return;
    data[id] = el.type === "checkbox" ? el.checked : el.value;
  });
  data.middleRangeRules = sanitizeMiddleRangeRules(middleRangeRules);
  return data;
}
function refreshColorWidgets(){
  syncRgbFromColor(epubEditTextColorEl, epubEditTextColorREl, epubEditTextColorGEl, epubEditTextColorBEl);
  syncRgbFromColor(epubQuoteColorEl, epubQuoteColorREl, epubQuoteColorGEl, epubQuoteColorBEl);
  [speakerUserColorEl, speakerCharacterColorEl].forEach(updateColorSwatch);
  updateQuoteColorPreview();
}
function applyPresetValues(data){
  Object.entries(data || {}).forEach(([id, value]) => {
    const el = document.getElementById(id);
    if(!el) return;
    if(el.type === "checkbox") el.checked = !!value;
    else el.value = value;
  });
  if(data && Object.prototype.hasOwnProperty.call(data, "middleRangeRules")) middleRangeRules = sanitizeMiddleRangeRules(data.middleRangeRules);
  renderMiddleRangePanel();
  refreshColorWidgets();
}
function saveCurrentPreset(){
  localStorage.setItem("rofan-cleaner-preset", JSON.stringify(collectPresetValues()));
  showToast("현재 옵션을 저장했습니다.");
  scheduleAutosave();
}
function loadSavedPreset(){
  const raw = localStorage.getItem("rofan-cleaner-preset");
  if(!raw){ showToast("저장된 프리셋이 없습니다."); return; }
  try{
    applyPresetValues(JSON.parse(raw));
    transformText();
    updateChapterDividerPanel();
    scheduleAutosave();
    showToast("프리셋을 불러왔습니다.");
  }catch(err){
    console.error(err);
    showToast("프리셋을 불러오지 못했습니다.");
  }
}
function clearSavedPreset(){
  if(!window.confirm("저장된 프리셋을 삭제하시겠습니까?")) return;
  localStorage.removeItem("rofan-cleaner-preset");
  showToast("저장된 프리셋을 삭제했습니다.");
}
function updateFileNameLabel(inputEl, labelEl, emptyText){
  if(!labelEl) return;
  const file = inputEl && inputEl.files && inputEl.files[0];
  labelEl.textContent = file ? (file.name || "선택됨") : (emptyText || "선택된 파일 없음");
}


wireAutosave();


// ------------------ EPUB 수정 탭 / 파일 발췌 ------------------
function plainTextToHtml(text){
  return String(text || "").replace(/\r/g, "").split(/\n\s*\n+/).map(p => `<p>${escapeHTML(p).replace(/\n/g,"<br>")}</p>`).join("\n");
}
function editorPlainText(el){
  if(!el) return "";
  return (el.innerText || el.textContent || "").replace(/\u00a0/g," ").trim();
}

async function readFileAsTextSmart(file){
  const buffer = await readFileAsArrayBuffer(file);
  const bytes = new Uint8Array(buffer);
  return decodeBytesSmart(bytes);
}
async function readFileAsBytesAndText(file){
  const buffer = await readFileAsArrayBuffer(file);
  const bytes = new Uint8Array(buffer);
  return {bytes, text:decodeBytesSmart(bytes)};
}
async function loadClassicFile(){
  const file = classicFileInput && classicFileInput.files && classicFileInput.files[0];
  if(!file) return;
  try{
    const fileData = await readFileAsBytesAndText(file);
    const raw = fileData.text;
    const chunks = fileContentToChunks(raw, file.name || "", fileData.bytes);
    if(chunks && chunks.length){
      classicLoadedChunks = chunks;
      classicLoadedFileText = chunksDisplayText(chunks);
    }else{
      classicLoadedChunks = null;
      classicLoadedFileText = String(raw || "");
    }
    applyClassicExcerpt();
    showToast("파일을 불러왔습니다.");
  }catch(err){ console.error(err); showToast("파일을 읽지 못했습니다."); }
}

function sliceByStartEnd(text, startNeedle, endNeedle){
  let s = String(text || "");
  const start = String(startNeedle || "").trim();
  const end = String(endNeedle || "").trim();
  if(start){ const i = s.indexOf(start); if(i >= 0) s = s.slice(i); }
  if(end){ const j = s.indexOf(end); if(j >= 0) s = s.slice(0, j + end.length); }
  return s.trim();
}
function applyClassicExcerpt(){
  const start = excerptStartTextEl ? excerptStartTextEl.value : "";
  const end = excerptEndTextEl ? excerptEndTextEl.value : "";
  let next = "";
  if(classicLoadedChunks && classicLoadedChunks.length){
    classicActiveChunks = sliceChunksByStartEnd(classicLoadedChunks, start, end);
    next = chunksDisplayText(classicActiveChunks);
  }else{
    const base = classicLoadedFileText || (input ? input.value : "");
    next = sliceByStartEnd(base, start, end);
    classicActiveChunks = null;
  }
  classicActiveDisplayText = next;
  isApplyingClassicExcerpt = true;
  if(input) input.value = next;
  isApplyingClassicExcerpt = false;
  transformText();
  scheduleAutosave();
}

function activateEpubEditTab(){
  activeMode = "epubedit";
  document.querySelectorAll(".tab").forEach(t => {
    const on = t.dataset.tab === activeMode;
    t.classList.toggle("active", on);
    t.setAttribute("aria-selected", on ? "true" : "false");
  });
  classicPanel.classList.add("hidden");
  chatPanel.classList.add("hidden");
  if(epubEditPanel) epubEditPanel.classList.remove("hidden");
  updateModeVisibility();
}
async function loadEpubEditFile(){
  const file = epubEditFileInput && epubEditFileInput.files && epubEditFileInput.files[0];
  if(!file) return;
  try{
    const lower = (file.name || "").toLowerCase();
    let html = "";
    if(/\.epub$/i.test(lower)){
      html = await extractHtmlFromEpubFile(file);
    }else{
      const raw = await readFileAsTextSmart(file);
      if(/\.(html|htm)$/i.test(lower) || looksLikeHTML(raw)) html = sanitizeEditorHTML(raw);
      else html = markdownOrTextToEditorHTML(raw, /\.(md|markdown)$/i.test(lower));
    }
    if(!html || !stripHTMLTags(html).trim()){ showToast("불러올 본문을 찾지 못했습니다."); return; }
    activateEpubEditTab();
    epubEditEditor.innerHTML = html;
    cachedEpubEditFileName = file.name || "원고 파일";
    transformText();
    scheduleAutosave();
    showToast("EPUB 수정 원고를 불러왔습니다.");
  }catch(err){ console.error(err); showToast("파일을 읽지 못했습니다."); }
}
function parseStructuredMarkdown(raw){
  const chunks = parseStructuredMarkdownToChunks(raw);
  if(!chunks || !chunks.length) return "";
  return structuredItemsToHtml(chunks.map(c => ({blockId:c.blockId, owner:c.owner, kind:c.kind, text:c.text})));
}

function markdownOrTextToEditorHTML(raw, isMarkdown){
  let text = String(raw || "").replace(/\r/g, "");
  if(isMarkdown){
    const structured = parseStructuredMarkdown(text);
    if(structured) return structured;
    text = text.replace(/^#{1,6}\s+/gm, "");
    text = text.replace(/\*\*([^*]+)\*\*/g, "$1").replace(/__([^_]+)__/g, "$1");
    text = text.replace(/\[([^\]]+)\]\([^\)]+\)/g, "$1");
    text = text.replace(/^>\s?/gm, "");
  }
  return plainTextToHtml(text);
}
function sanitizeInlineStyle(style){
  const allowed = [];
  String(style || "").split(";").forEach(part => {
    const [rawName, ...rest] = part.split(":");
    if(!rawName || !rest.length) return;
    const name = rawName.trim().toLowerCase();
    const value = rest.join(":").trim();
    if(!/^(color|font-size|font-family|background|background-color|border|border-color|border-left|border-left-color|border-top|border-top-color|border-bottom|border-bottom-color|border-radius|padding|margin|text-align|line-height|font-weight|font-style)$/.test(name)) return;
    if(/url\s*\(|expression\s*\(|javascript:/i.test(value)) return;
    allowed.push(`${name}:${value}`);
  });
  return allowed.join(";");
}
function sanitizeEditorHTML(html){
  const doc = new DOMParser().parseFromString(String(html || ""), "text/html");
  doc.querySelectorAll("script,style,meta,link,iframe,object,embed").forEach(n => n.remove());
  doc.body.querySelectorAll("*").forEach(el => {
    [...el.attributes].forEach(attr => {
      const name = attr.name.toLowerCase();
      if(name.startsWith("on")) el.removeAttribute(attr.name);
      else if(name === "style"){ const clean = sanitizeInlineStyle(attr.value); clean ? el.setAttribute("style", clean) : el.removeAttribute("style"); }
      else if(!(name === "class" || name === "style" || name === "data-owner" || name === "data-kind" || name === "title" || name === "lang" || name === "xml:lang")){ el.removeAttribute(attr.name); }
    });
  });
  return doc.body.innerHTML || plainTextToHtml(doc.body.innerText || "");
}
async function inflateRawDeflate(bytes){
  if(!("DecompressionStream" in window)) throw new Error("deflate unsupported");
  const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream("deflate-raw"));
  return new Uint8Array(await new Response(stream).arrayBuffer());
}
function readU16(bytes, o){ return bytes[o] | (bytes[o+1] << 8); }
function readU32(bytes, o){ return (bytes[o] | (bytes[o+1]<<8) | (bytes[o+2]<<16) | (bytes[o+3]<<24)) >>> 0; }
async function readZipTextEntries(bytes){
  const entries = [];
  let eocd = -1;
  for(let i=bytes.length-22; i>=0 && i>bytes.length-66000; i--){ if(readU32(bytes,i)===0x06054b50){ eocd=i; break; } }
  if(eocd < 0) throw new Error("zip eocd not found");
  const count = readU16(bytes, eocd+10);
  let pos = readU32(bytes, eocd+16);
  for(let n=0; n<count; n++){
    if(readU32(bytes,pos)!==0x02014b50) break;
    const method=readU16(bytes,pos+10), compSize=readU32(bytes,pos+20), nameLen=readU16(bytes,pos+28), extraLen=readU16(bytes,pos+30), commentLen=readU16(bytes,pos+32), localOff=readU32(bytes,pos+42);
    const name = new TextDecoder().decode(bytes.slice(pos+46,pos+46+nameLen));
    pos += 46 + nameLen + extraLen + commentLen;
    if(!/\.(xhtml|html|htm|opf|ncx)$/i.test(name)) continue;
    const lo = localOff;
    const lfNameLen=readU16(bytes,lo+26), lfExtraLen=readU16(bytes,lo+28);
    const dataStart = lo + 30 + lfNameLen + lfExtraLen;
    let data = bytes.slice(dataStart, dataStart + compSize);
    if(method === 8) data = await inflateRawDeflate(data);
    else if(method !== 0) continue;
    entries.push({name, text:new TextDecoder("utf-8").decode(data)});
  }
  return entries;
}
async function extractHtmlFromEpubFile(file){
  const bytes = new Uint8Array(await file.arrayBuffer());
  const entries = await readZipTextEntries(bytes);
  const bodyEntries = entries.filter(e => /\.(xhtml|html|htm)$/i.test(e.name) && !/nav|toc|cover/i.test(e.name)).sort((a,b)=>a.name.localeCompare(b.name));
  const html = bodyEntries.map(e => sanitizeEditorHTML(e.text)).join("\n<hr/>\n");
  return html || "";
}
function selectEditorRangeForText(query){
  if(!epubEditEditor || !query) return false;
  const walker = document.createTreeWalker(epubEditEditor, NodeFilter.SHOW_TEXT);
  let node;
  while((node = walker.nextNode())){
    const idx = node.nodeValue.toLowerCase().indexOf(String(query).toLowerCase());
    if(idx >= 0){
      const range = document.createRange();
      range.setStart(node, idx); range.setEnd(node, idx + query.length);
      const sel = window.getSelection(); sel.removeAllRanges(); sel.addRange(range);
      node.parentElement && node.parentElement.scrollIntoView({behavior:"smooth", block:"center"});
      return true;
    }
  }
  return false;
}
function findInEpubEditor(){
  const q = epubFindTextEl ? epubFindTextEl.value.trim() : "";
  if(!q){ showToast("찾을 내용을 입력하세요."); return; }
  showToast(selectEditorRangeForText(q) ? "찾았습니다." : "찾지 못했습니다.");
}
function replaceOneInEpubEditor(){
  const q = epubFindTextEl ? epubFindTextEl.value : "";
  const r = epubReplaceTextEl ? epubReplaceTextEl.value : "";
  if(!q) return;
  if(selectEditorRangeForText(q)){
    document.execCommand("insertText", false, r);
    transformText(); scheduleAutosave(); showToast("바꿨습니다.");
  }else showToast("찾지 못했습니다.");
}
function replaceAllInEpubEditor(){
  const q = epubFindTextEl ? epubFindTextEl.value : "";
  const r = epubReplaceTextEl ? epubReplaceTextEl.value : "";
  if(!q || !epubEditEditor) return;
  const re = new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g,"\\$&"), "gi");
  epubEditEditor.innerHTML = epubEditEditor.innerHTML.replace(re, escapeHTML(r));
  transformText(); scheduleAutosave(); showToast("모두 바꿨습니다.");
}
function rememberEditorSelection(){
  const sel = window.getSelection();
  if(!sel || !sel.rangeCount || !epubEditEditor) return;
  const range = sel.getRangeAt(0);
  if(epubEditEditor.contains(range.commonAncestorContainer)) savedEditorRange = range.cloneRange();
}
function restoreEditorSelection(){
  if(!savedEditorRange || !epubEditEditor) return false;
  try{
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(savedEditorRange.cloneRange());
    epubEditEditor.focus({preventScroll:true});
    return true;
  }catch(_err){ return false; }
}
function getActiveEditorRange(){
  let sel = window.getSelection();
  if(sel && sel.rangeCount){
    const range = sel.getRangeAt(0);
    if(epubEditEditor && epubEditEditor.contains(range.commonAncestorContainer)){
      savedEditorRange = range.cloneRange();
      return range;
    }
  }
  if(restoreEditorSelection()){
    sel = window.getSelection();
    if(sel && sel.rangeCount) return sel.getRangeAt(0);
  }
  return null;
}
function getSelectedHtml(){
  const range = getActiveEditorRange();
  if(!range || range.collapsed) return "";
  const div = document.createElement("div");
  div.appendChild(range.cloneContents());
  return div.innerHTML || escapeHTML(range.toString());
}
function replaceSelectionWithHtml(html){
  const range = getActiveEditorRange();
  if(!range || range.collapsed) return false;
  if(epubEditEditor && !epubEditEditor.contains(range.commonAncestorContainer)) return false;
  range.deleteContents();
  const frag = range.createContextualFragment(html);
  const last = frag.lastChild;
  range.insertNode(frag);
  const sel = window.getSelection();
  if(last){
    const next = document.createRange();
    next.setStartAfter(last);
    next.collapse(true);
    sel.removeAllRanges();
    sel.addRange(next);
    savedEditorRange = next.cloneRange();
  }
  epubEditEditor.focus({preventScroll:true});
  return true;
}
function clearQuoteLongPressTimer(){
  if(quoteLongPressTimer){ clearTimeout(quoteLongPressTimer); quoteLongPressTimer = null; }
  quoteLongPressMeta = null;
}
function closestEditorQuote(target){
  const quote = target && target.closest ? target.closest("blockquote") : null;
  return quote && epubEditEditor && epubEditEditor.contains(quote) ? quote : null;
}
function showQuoteContextMenu(quote, x, y){
  if(!quoteContextMenuEl || !quote) return;
  currentQuoteMenuTarget = quote;
  quoteContextMenuEl.hidden = false;
  quoteContextMenuEl.style.left = "0px";
  quoteContextMenuEl.style.top = "0px";
  const rect = quoteContextMenuEl.getBoundingClientRect();
  const pad = 10;
  const left = Math.max(pad, Math.min((x || pad), window.innerWidth - rect.width - pad));
  const top = Math.max(pad, Math.min((y || pad), window.innerHeight - rect.height - pad));
  quoteContextMenuEl.style.left = left + "px";
  quoteContextMenuEl.style.top = top + "px";
}
function hideQuoteContextMenu(){
  if(quoteContextMenuEl) quoteContextMenuEl.hidden = true;
  currentQuoteMenuTarget = null;
}
function handleQuoteContextMenu(e){
  const quote = closestEditorQuote(e.target);
  if(!quote) return;
  e.preventDefault();
  clearQuoteLongPressTimer();
  showQuoteContextMenu(quote, e.clientX, e.clientY);
}
function handleQuotePointerDown(e){
  if(activeMode !== "epubedit" || !epubEditEditor) return;
  const quote = closestEditorQuote(e.target);
  if(!quote) return;
  clearQuoteLongPressTimer();
  quoteLongPressMeta = {quote, x:e.clientX || 0, y:e.clientY || 0};
  quoteLongPressTimer = setTimeout(() => {
    const meta = quoteLongPressMeta;
    clearQuoteLongPressTimer();
    if(meta && meta.quote && epubEditEditor.contains(meta.quote)) showQuoteContextMenu(meta.quote, meta.x, meta.y);
  }, 650);
}
function handleQuotePointerMove(e){
  if(!quoteLongPressTimer || !quoteLongPressMeta) return;
  if(Math.abs((e.clientX || 0) - quoteLongPressMeta.x) > 9 || Math.abs((e.clientY || 0) - quoteLongPressMeta.y) > 9) clearQuoteLongPressTimer();
}
function unwrapQuoteBlock(quote){
  if(!quote || !quote.parentNode) return;
  const frag = document.createDocumentFragment();
  while(quote.firstChild) frag.appendChild(quote.firstChild);
  quote.parentNode.replaceChild(frag, quote);
  rememberEditorSelection();
  updateEpubPreview(); scheduleAutosave();
  showToast("인용구를 해제했습니다.");
}
function getQuoteColor(){
  return epubQuoteColorEl && /^#[0-9a-fA-F]{6}$/.test(epubQuoteColorEl.value) ? epubQuoteColorEl.value : "#4f8aa4";
}
function quoteStyleForType(type, color){
  if(type === "blog") return `border-top-color:${color};border-bottom-color:${color};`;
  if(type === "soft") return `border-color:${color};`;
  return `border-left-color:${color};`;
}
function makeQuoteHtml(type, content){
  const cls = type === "blog" ? "quoteBlog" : (type === "soft" ? "quoteSoft" : (type === "postype" ? "quotePostype" : "quoteLine"));
  const color = getQuoteColor();
  return `<blockquote class="${cls}" style="${quoteStyleForType(type, color)}">${content}</blockquote>`;
}
function getCustomQuoteTemplate(){
  const el = document.getElementById("epubQuoteCustomTemplate");
  return el ? el.value.trim() : "";
}
function applyQuoteStyle(type){
  if(!epubEditEditor) return;
  const selected = getSelectedHtml();
  if(!selected){ showToast("인용할 문장을 드래그하세요."); return; }
  let html = "";
  if(type === "custom"){
    const tpl = getCustomQuoteTemplate();
    if(!tpl){ showToast("직접 입력 형식을 입력하세요."); return; }
    html = tpl.includes("{{content}}") ? tpl.replace(/{{content}}/g, selected) : `${tpl}${selected}`;
  }else{
    html = makeQuoteHtml(type, selected);
  }
  const ok = replaceSelectionWithHtml(html);
  if(ok){ updateEpubPreview(); scheduleAutosave(); showToast("인용구를 적용했습니다."); }
  else showToast("선택 영역을 다시 드래그해 주세요.");
}
function selectionInsideEditor(){
  const sel = window.getSelection();
  return sel && sel.rangeCount && epubEditEditor && epubEditEditor.contains(sel.anchorNode);
}
function wrapRangeWithSpan(range, styleText){
  const html = getSelectedHtml();
  if(!html) return false;
  return replaceSelectionWithHtml(`<span style="${styleText}">${html}</span>`);
}
function applyEpubTextFormat(){
  if(!epubEditEditor) return;
  const size = Math.max(8, Math.min(72, parseInt(epubEditFontSizeEl ? epubEditFontSizeEl.value : "15",10) || 15));
  const color = epubEditTextColorEl ? epubEditTextColorEl.value : "#1f2d36";
  const range = getActiveEditorRange();
  if(range && !range.collapsed){
    const ok = wrapRangeWithSpan(range, `font-size:${size}px;color:${color};`);
    if(!ok){ showToast("선택 영역을 다시 드래그해 주세요."); return; }
  }else{
    epubEditEditor.style.setProperty("font-size", size + "px", "important");
    epubEditEditor.style.setProperty("color", color, "important");
    Array.from(epubEditEditor.children).forEach(el => {
      if(el.nodeType === 1){
        if(!el.style.fontSize) el.style.fontSize = "inherit";
        if(!el.style.color) el.style.color = "inherit";
      }
    });
  }
  rememberEditorSelection();
  updateEpubPreview(); scheduleAutosave(); showToast("서식을 적용했습니다.");
}

function adjustEpubFontSize(delta){
  if(!epubEditFontSizeEl) return;
  const cur = parseInt(epubEditFontSizeEl.value || '15', 10) || 15;
  epubEditFontSizeEl.value = String(Math.max(8, Math.min(72, cur + delta)));
  applyEpubTextFormat();
}
function clearEpubInlineFormat(){
  if(!epubEditEditor) return;
  const range = getActiveEditorRange();
  if(range && !range.collapsed){
    document.execCommand("removeFormat", false, null);
  }else {
    epubEditEditor.querySelectorAll("span,font").forEach(n => n.replaceWith(...n.childNodes));
    epubEditEditor.style.fontSize="";
    epubEditEditor.style.color="";
  }
  updateEpubPreview(); scheduleAutosave(); showToast("서식을 제거했습니다.");
}
async function loadEpubFontFile(){
  const file = epubFontInputEl && epubFontInputEl.files && epubFontInputEl.files[0];
  if(!file) return;
  const dataUrl = await new Promise((resolve, reject) => { const r=new FileReader(); r.onload=()=>resolve(r.result); r.onerror=()=>reject(r.error); r.readAsDataURL(file); });
  const ext = (file.name.split('.').pop() || 'woff').toLowerCase().replace(/[^a-z0-9]/g,'') || 'woff';
  cachedEpubFontAsset = {name:file.name || 'uploaded-font.'+ext, epubName:'uploaded-font.'+ext, type:file.type || 'font/'+ext, dataUrl};
  applyCachedEpubFont(); scheduleAutosave(); showToast("폰트를 적용했습니다.");
}
async function applyCachedEpubFont(){
  if(!cachedEpubFontAsset || !cachedEpubFontAsset.dataUrl) return;
  try{
    let styleEl = document.getElementById("uploadedEpubFontStyle");
    if(!styleEl){ styleEl = document.createElement("style"); styleEl.id = "uploadedEpubFontStyle"; document.head.appendChild(styleEl); }
    styleEl.textContent = `@font-face{font-family:"UploadedEpubFont";src:url("${cachedEpubFontAsset.dataUrl}");font-weight:normal;font-style:normal;}`;
    if("FontFace" in window){
      const font = new FontFace("UploadedEpubFont", `url(${cachedEpubFontAsset.dataUrl})`);
      await font.load(); document.fonts.add(font);
    }
    if(epubEditEditor) epubEditEditor.style.setProperty("font-family", 'UploadedEpubFont, serif', "important");
    updateEpubPreview();
  }catch(err){ console.warn(err); showToast("이 브라우저에서 폰트 미리보기를 적용하지 못했습니다."); }
}
function editorHtmlForExport(){
  if(activeMode !== "epubedit" || !epubEditEditor) return "";
  let html = sanitizeEditorHTML(epubEditEditor.innerHTML || "");
  const style = sanitizeInlineStyle(`font-size:${epubEditEditor.style.fontSize || ""};color:${epubEditEditor.style.color || ""};font-family:${epubEditEditor.style.fontFamily || ""}`);
  if(style) html = `<div class="epub-editor-body" style="${escapeAttr(style)}">${html}</div>`;
  return html;
}

function blockHtmlToText(html){
  const div=document.createElement('div'); div.innerHTML=html; return (div.innerText||div.textContent||'').trim();
}
function editorHtmlToChapterBlocks(html){
  const temp=document.createElement('div'); temp.innerHTML=html || '';
  const separator = (chapterSeparatorEl && chapterSeparatorEl.value.trim()) || "—————";
  const normalize = value => String(value || "").replace(/\s+/g, " ").trim();
  const blocks=[];
  Array.from(temp.childNodes).forEach(node => {
    const text = normalize(node.innerText || node.textContent || "");
    if(node.nodeType===Node.ELEMENT_NODE && node.tagName==='HR') blocks.push({sep:true});
    else if(separator && text === separator) blocks.push({sep:true});
    else if((node.textContent||'').trim() || node.nodeType===Node.ELEMENT_NODE) blocks.push({html: node.outerHTML || escapeHTML(node.textContent||'')});
  });
  return blocks;
}

function editorStructuredBlocks(){
  if(!epubEditEditor) return [];
  return Array.from(epubEditEditor.querySelectorAll('[data-owner][data-kind], .rofan-block')).map((el, idx) => ({
    blockId: el.getAttribute('data-block-id') || el.getAttribute('data-block') || ('editor-' + idx),
    owner: el.getAttribute('data-owner') || 'character',
    kind: el.getAttribute('data-kind') || 'normal',
    text: (el.innerText || el.textContent || '').trim()
  })).filter(it => it.text);
}
function editorStructuredMarkdown(){
  const items = editorStructuredBlocks();
  if(!items.length) return '';
  return structuredItemsToMarkdown(items);
}
function getExportChapters(markdownMode){
  if(activeMode !== "epubedit"){
    return splitTextIntoChapters(markdownMode ? stripHTMLTags(getPreparedOutputForExport()) : getPreparedOutputForExport());
  }
  const cfg = getEpubConfig();
  const html = editorHtmlForExport();
  const blocks = editorHtmlToChapterBlocks(html);
  const makeTitle = idx => getChapterTitle(idx, cfg);
  if(markdownMode){ return splitTextIntoChapters(blockHtmlToText(html)); }
  const makeChapter = (bucket, idxTitle) => ({title: idxTitle === null ? cfg.title : makeTitle(idxTitle), bodyHtml:bucket.join("\n"), body:blockHtmlToText(bucket.join("\n"))});
  if(cfg.chapterMode === "separator"){
    const chapters=[]; let bucket=[];
    blocks.forEach(b => { if(b.sep){ if(bucket.length){ chapters.push(makeChapter(bucket, chapters.length)); bucket=[]; } } else if(b.html) bucket.push(b.html); });
    if(bucket.length) chapters.push(makeChapter(bucket, chapters.length));
    return chapters.length ? chapters : [{title:cfg.title, bodyHtml:html, body:blockHtmlToText(html)}];
  }
  if(cfg.chapterMode === "chars" || cfg.chapterMode === "paragraphs"){
    const chapters=[]; let bucket=[]; let count=0;
    blocks.filter(b => b.html).forEach(b => {
      const t = blockHtmlToText(b.html);
      const unit = cfg.chapterMode === "paragraphs" ? 1 : t.length;
      if(bucket.length && count + unit > cfg.chapterSize){ chapters.push(makeChapter(bucket, chapters.length)); bucket=[]; count=0; }
      bucket.push(b.html); count += unit;
    });
    if(bucket.length) chapters.push(makeChapter(bucket, chapters.length));
    if(chapters.length) return chapters;
  }
  return html ? [{title:cfg.title, bodyHtml:html, body:blockHtmlToText(html)}] : [];
}

function chapterBodyToXhtml(ch){
  if(activeMode === "epubedit" && ch.bodyHtml) return sanitizeEditorHTML(ch.bodyHtml).replace(/<br>/g,"<br/>").replace(/<hr\s*\/?\s*>/gi,"");
  return textToXhtmlBody(ch.body || "");
}

window.addEventListener("resize", () => requestAnimationFrame(syncActiveResultHeight));
restoreSavedWork();
refreshColorWidgets();
renderMiddleRangePanel();
syncResultPreview(output);
syncResultPreview(chatOutput);
requestAnimationFrame(syncActiveResultHeight);

/* --- 2026-06-06 final UI/chapter hardening patch --- */
(function(){
  const CHAPTER_STATE_KEY = "rofan-manual-chapters-v2";
  const EMOJI_RE = /(?:[\u2600-\u27BF]|[\u{1F1E6}-\u{1F1FF}]|[\u{1F300}-\u{1FAFF}])\uFE0F?/u;
  const IMG_TYPES = "image/png,image/jpeg,image/jpg,image/webp,image/gif,image/svg+xml,.svg";
  let chapterStateCache = null;
  let chapterSearch = { keyword:"", order:"", page:0, editingId:null };
  let epubBoardCollapsedForTextTabs = true;

  function qs(sel, root=document){ return root.querySelector(sel); }
  function qsa(sel, root=document){ return Array.from(root.querySelectorAll(sel)); }
  function mode(){ return (typeof activeMode === "string" && activeMode) ? activeMode : "classic"; }
  function safeHtml(v){ return (typeof escapeHTML === "function") ? escapeHTML(v) : String(v||"").replace(/[&<>"']/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[ch])); }
  function safeAttr(v){ return (typeof escapeAttr === "function") ? escapeAttr(v) : safeHtml(v); }
  function toast(msg){ if(typeof showToast === "function") showToast(msg); }
  function uid(){ return "ch-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2,8); }
  function plainFromHtml(html){
    if(typeof blockHtmlToText === "function") return blockHtmlToText(html);
    const d = document.createElement("div"); d.innerHTML = html || ""; return (d.innerText || d.textContent || "").trim();
  }
  function stripTagsLocal(text){
    if(typeof stripHTMLTags === "function") return stripHTMLTags(text || "");
    return String(text || "").replace(/<[^>]*>/g, "");
  }
  function getChapterTitleFallback(idx){
    if(idx === 0 && typeof chapterFirstTitleEl !== "undefined" && chapterFirstTitleEl && chapterFirstTitleEl.value.trim()) return chapterFirstTitleEl.value.trim();
    const prefix = (typeof chapterTitlePrefixEl !== "undefined" && chapterTitlePrefixEl && chapterTitlePrefixEl.value.trim()) || "Chapter";
    return `${prefix} ${idx + 1}`;
  }
  function ensureState(){
    if(chapterStateCache) return chapterStateCache;
    try{ chapterStateCache = JSON.parse(localStorage.getItem(CHAPTER_STATE_KEY) || "{}"); }
    catch(_){ chapterStateCache = {}; }
    return chapterStateCache;
  }
  function saveState(){
    try{ localStorage.setItem(CHAPTER_STATE_KEY, JSON.stringify(ensureState())); }catch(_){ }
    if(typeof scheduleAutosave === "function") scheduleAutosave();
  }
  function getPlan(modeName=mode()){
    const state = ensureState();
    if(!state[modeName]) state[modeName] = { chapters: [] };
    if(!Array.isArray(state[modeName].chapters)) state[modeName].chapters = [];
    if(!state[modeName].chapters.length){
      state[modeName].chapters.push({ id: uid(), title: getChapterTitleFallback(0), endPara: null, note: "", imageData: "", imageName: "", imageType: "", imagePos: "belowTitle" });
    }
    state[modeName].chapters.forEach((ch, idx) => { if(!ch.id) ch.id = uid(); if(!ch.title) ch.title = getChapterTitleFallback(idx); });
    return state[modeName];
  }
  function currentPlan(){ return getPlan(mode()); }
  function sourceTextForChapters(){
    if(mode() === "epubedit"){
      return (typeof epubEditEditor !== "undefined" && epubEditEditor) ? (epubEditEditor.innerText || epubEditEditor.textContent || "") : "";
    }
    if(typeof getPreparedOutputForExport === "function") return getPreparedOutputForExport();
    if(mode() === "chat" && typeof chatOutput !== "undefined" && chatOutput) return chatOutput.value || "";
    if(typeof output !== "undefined" && output) return output.value || "";
    return "";
  }
  function getEditorUnits(){
    if(typeof epubEditEditor === "undefined" || !epubEditEditor) return [];
    const nodes = Array.from(epubEditEditor.childNodes).filter(node => {
      if(node.nodeType === Node.ELEMENT_NODE && node.classList && node.classList.contains("manual-chapter-separator")) return false;
      return (node.textContent || "").trim() || node.nodeType === Node.ELEMENT_NODE;
    });
    if(!nodes.length){
      const text = (epubEditEditor.innerText || epubEditEditor.textContent || "").trim();
      return splitTextUnits(text);
    }
    return nodes.map(node => {
      const html = node.outerHTML || safeHtml(node.textContent || "");
      return { text: plainFromHtml(html), html };
    }).filter(u => u.text || u.html);
  }
  function splitTextUnits(text){
    const raw = String(text || "").replace(/\r/g, "");
    const first = raw.split(/\n\s*\n+/).map(p => p.trim()).filter(Boolean);
    const pieces = [];
    first.forEach(part => {
      const plain = stripTagsLocal(part).replace(/\s+/g, " ").trim();
      if(!plain) return;
      // 파일/백업 결과가 한 덩어리로 붙어 들어온 경우 검색 카드에 전문이 뜨지 않도록
      // 줄 단위 → 문장 단위 순서로 안전하게 잘라 챕터 끝 지점 후보를 만듭니다.
      const lines = part.split(/\n+/).map(v => v.trim()).filter(Boolean);
      if(lines.length > 1){
        lines.forEach(line => {
          const t = stripTagsLocal(line).replace(/\s+/g, " ").trim();
          if(t) pieces.push({ text:t, body:line });
        });
        return;
      }
      if(plain.length > 900){
        const sentences = part.split(/(?<=[.!?。！？…]|[다요죠네까오음임함됨니다였다었다한다된다했다]|[”"])\s+/).map(v => v.trim()).filter(Boolean);
        if(sentences.length > 1){
          sentences.forEach(seg => {
            const t = stripTagsLocal(seg).replace(/\s+/g, " ").trim();
            if(t) pieces.push({ text:t, body:seg });
          });
          return;
        }
      }
      pieces.push({ text:plain, body:part });
    });
    return pieces;
  }
  function getChapterUnits(){
    if(mode() === "epubedit") return getEditorUnits();
    return splitTextUnits(sourceTextForChapters());
  }
  function clampPlanToUnits(plan, units){
    const max = Math.max(0, units.length - 1);
    plan.chapters.forEach(ch => {
      if(ch.endPara === "" || ch.endPara === undefined) ch.endPara = null;
      if(ch.endPara !== null){
        ch.endPara = Math.max(0, Math.min(max, Number(ch.endPara) || 0));
      }
    });
  }
  function ensureTrailingChapter(plan, units){
    if(!plan || !Array.isArray(plan.chapters) || !units || !units.length) return false;
    const last = plan.chapters[plan.chapters.length - 1];
    if(!last) return false;
    if(last.endPara !== null && last.endPara !== undefined && Number(last.endPara) < units.length - 1){
      plan.chapters.push({ id: uid(), title: getChapterTitleFallback(plan.chapters.length), endPara: null, note:"", imageData:"", imageName:"", imageType:"", imagePos:"belowTitle" });
      return true;
    }
    return false;
  }
  function chaptersFromManualPlan(markdownMode){
    const cfg = (typeof getEpubConfig === "function") ? getEpubConfig() : { title:"정리한 로그" };
    const plan = currentPlan();
    const units = getChapterUnits();
    clampPlanToUnits(plan, units);
    if(!units.length) return [];
    const chapters = [];
    let start = 0;
    plan.chapters.forEach((ch, idx) => {
      const lastChapter = idx === plan.chapters.length - 1;
      let end = ch.endPara;
      if(end === null || end === undefined) end = lastChapter ? units.length - 1 : start - 1;
      end = Math.max(start - 1, Math.min(units.length - 1, Number(end)));
      const slice = end >= start ? units.slice(start, end + 1) : [];
      const title = ch.title || getChapterTitleFallback(idx) || cfg.title;
      const body = slice.map(u => u.body !== undefined ? u.body : u.text).join("\n\n").trim();
      const bodyHtml = slice.map(u => u.html || (typeof paragraphToXhtml === "function" ? paragraphToXhtml(u.body || u.text || "") : `<p>${safeHtml(u.body || u.text || "")}</p>`)).join("\n");
      chapters.push({
        id: ch.id, title, body, bodyHtml, note: ch.note || "", imageData: ch.imageData || "", imageName: ch.imageName || "", imageType: ch.imageType || "", imagePos: ch.imagePos || "belowTitle"
      });
      start = end + 1;
    });
    if(start < units.length){
      const idx = chapters.length;
      const slice = units.slice(start);
      chapters.push({ id: uid(), title: getChapterTitleFallback(idx), body: slice.map(u => u.body !== undefined ? u.body : u.text).join("\n\n"), bodyHtml: slice.map(u => u.html || `<p>${safeHtml(u.body || u.text || "")}</p>`).join("\n"), note:"", imageData:"", imageName:"", imageType:"", imagePos:"belowTitle" });
    }
    return chapters.filter(ch => ch.body || ch.bodyHtml || ch.note || ch.imageData || chapters.length === 1);
  }
  function imageHtml(ch){
    if(!ch || !ch.imageData) return "";
    return `<figure class="chapterImage"><img src="${safeAttr(ch.imageData)}" alt="${safeAttr(ch.imageName || ch.title || "chapter image")}"></figure>`;
  }
  function noteHtml(ch){ return ch && ch.note ? `<p class="chapterNote">${safeHtml(ch.note).replace(/\n/g,"<br>")}</p>` : ""; }
  function bodyToHtml(ch){
    if(ch && ch.bodyHtml) return (typeof sanitizeEditorHTML === "function") ? sanitizeEditorHTML(ch.bodyHtml).replace(/<br>/g,"<br/>") : ch.bodyHtml;
    if(typeof textToXhtmlBody === "function") return textToXhtmlBody((ch && ch.body) || "");
    return splitTextUnits((ch && ch.body) || "").map(u => `<p>${safeHtml(u.body || u.text)}</p>`).join("\n");
  }
  function fullChapterHtml(ch, includeTitle=true){
    const above = ch.imagePos === "aboveTitle" ? imageHtml(ch) : "";
    const below = ch.imagePos === "belowTitle" ? imageHtml(ch) : "";
    const bottom = ch.imagePos === "bottom" ? imageHtml(ch) : "";
    return `${above}${includeTitle ? `<h1>${safeHtml(ch.title)}</h1>` : ""}${noteHtml(ch)}${below}${bodyToHtml(ch)}${bottom}`;
  }

  const originalGetExportChapters = (typeof getExportChapters === "function") ? getExportChapters : null;
  window.getExportChapters = getExportChapters = function(markdownMode){
    const chapters = chaptersFromManualPlan(markdownMode);
    if(chapters.length) return chapters;
    return originalGetExportChapters ? originalGetExportChapters(markdownMode) : [];
  };
  window.chapterBodyToXhtml = chapterBodyToXhtml = function(ch){ return fullChapterHtml(ch, false); };

  function renderManualChapterRows(){
    const box = qs("#manualChapterRows");
    if(!box) return;
    const plan = currentPlan();
    const units = getChapterUnits();
    clampPlanToUnits(plan, units);
    if(ensureTrailingChapter(plan, units)){ saveState(); }
    let start = 0;
    box.innerHTML = plan.chapters.map((ch, idx) => {
      const end = ch.endPara === null || ch.endPara === undefined ? (idx === plan.chapters.length - 1 ? units.length - 1 : start - 1) : Number(ch.endPara);
      const range = end >= start ? `${start + 1}–${Math.min(end + 1, units.length)}` : "끝 지점 미설정";
      start = Math.max(start, end + 1);
      return `<div class="manualChapterRow" data-id="${safeAttr(ch.id)}"><b>${idx + 1}</b><span><strong>${safeHtml(ch.title || getChapterTitleFallback(idx))}</strong><small>${range}${ch.note ? " · 문구 있음" : ""}${ch.imageData ? " · 이미지 있음" : ""}</small></span><button type="button" class="btn subtle" data-chapter-edit="${safeAttr(ch.id)}">편집</button>${plan.chapters.length > 1 ? `<button type="button" class="btn subtle warn" data-chapter-delete="${safeAttr(ch.id)}">삭제</button>` : ""}</div>`;
    }).join("");
  }
  function chapterSearchMatches(){
    const units = getChapterUnits();
    const q = String(chapterSearch.keyword || "").trim().toLowerCase();
    const order = String(chapterSearch.order || "").trim();
    let matches = units.map((u, idx) => ({...u, index:idx}));
    if(q) matches = matches.filter(u => String(u.text || "").toLowerCase().includes(q));
    if(order){
      const n = Number(order);
      if(Number.isFinite(n) && n > 0){
        matches = q ? matches.filter((_u, idx) => idx + 1 === n) : matches.filter(u => u.index + 1 === n);
      }
    }
    return matches;
  }
  function chapterMatchPreviewText(item){
    const text = String((item && item.text) || "").replace(/\s+/g, " ").trim();
    const q = String(chapterSearch.keyword || "").trim();
    if(!text || text.length <= 900) return text;
    if(q){
      const pos = text.toLowerCase().indexOf(q.toLowerCase());
      if(pos >= 0){
        const before = text.lastIndexOf(".", Math.max(0, pos - 1));
        const afterDot = text.indexOf(".", pos + q.length);
        const start = before >= 0 && pos - before < 450 ? before + 1 : Math.max(0, pos - 220);
        const end = afterDot >= 0 && afterDot - pos < 520 ? afterDot + 1 : Math.min(text.length, pos + q.length + 520);
        return `${start > 0 ? "…" : ""}${text.slice(start, end).trim()}${end < text.length ? "…" : ""}`;
      }
    }
    return text.slice(0, 900) + "…";
  }

  function renderManualChapterSearchResultsHtml(){
    const matches = chapterSearchMatches();
    const total = matches.length;
    chapterSearch.page = Math.max(0, Math.min(Math.max(0, total - 1), chapterSearch.page || 0));
    const current = total ? matches[chapterSearch.page] : null;
    return `<div class="miniToolHead"><div><strong>챕터 끝 지점</strong><span>검색한 문단을 이 챕터의 마지막 문단으로 설정합니다.</span></div><span>${total ? `${chapterSearch.page + 1}/${total}` : "0개"}</span></div>
      ${current ? `<div class="chapterMatchCard"><div class="dupeSummary withNav"><span><span class="pill">문단 ${current.index + 1}</span></span><span class="navButtons"><button type="button" class="navIconBtn" data-manual-chapter-page="prev" ${chapterSearch.page <= 0 ? "disabled" : ""}>‹</button><button type="button" class="navIconBtn" data-manual-chapter-page="next" ${chapterSearch.page >= total - 1 ? "disabled" : ""}>›</button></span></div><div class="previewText fullPreview chapterSearchPreview">${safeHtml(chapterMatchPreviewText(current))}</div><div class="chapterInsertRow"><button type="button" class="btn primary" data-chapter-set-end="${current.index}">이 문단을 끝 지점으로 설정</button><button type="button" class="btn subtle" data-chapter-clear-end="1">끝 지점 비우기</button></div></div>` : `<div class="emptyState">검색 결과가 없습니다. 키워드나 번호를 바꿔 보세요.</div>`}`;
  }
  function refreshManualChapterSearchResults(){
    const target = qs("#manualChapterSearchResults");
    if(target) target.innerHTML = renderManualChapterSearchResultsHtml();
  }
  function renderChapterEditPanel(chId){
    const host = qs("#manualChapterEditHost");
    if(!host) return;
    const plan = currentPlan();
    const ch = plan.chapters.find(c => c.id === chId) || plan.chapters[0];
    if(!ch){ host.innerHTML = `<div class="emptyState">편집할 챕터가 없습니다.</div>`; return; }
    chapterSearch.editingId = ch.id;
    host.innerHTML = `<details class="manualChapterEditor" open><summary>${safeHtml(ch.title || "챕터")} 편집</summary><div class="manualChapterEditorBody">
      <div class="manualChapterForm">
        <label class="control wide chapterTitleControl">챕터명 <input type="text" data-chapter-title value="${safeAttr(ch.title || "")}" placeholder="챕터 제목"></label>
        <label class="control wide">소제목 아래 문구 <textarea data-chapter-note rows="2" placeholder="소제목 아래에 넣을 짧은 문구">${safeHtml(ch.note || "")}</textarea></label>
        <label class="fileControl chapterImagePick"><span class="fileButtonText">이미지 선택</span><span class="fileNameText">${safeHtml(ch.imageName || "선택 없음")}</span><input type="file" data-chapter-image accept="${IMG_TYPES}"></label>
        <label class="control">이미지 위치 <select data-chapter-image-pos><option value="aboveTitle" ${ch.imagePos === "aboveTitle" ? "selected" : ""}>소제목 위</option><option value="belowTitle" ${(!ch.imagePos || ch.imagePos === "belowTitle") ? "selected" : ""}>소제목 아래</option><option value="bottom" ${ch.imagePos === "bottom" ? "selected" : ""}>맨 아래</option></select></label>
        ${ch.imageData ? `<button type="button" class="btn subtle warn" data-chapter-image-clear="1">이미지 제거</button>` : ""}
      </div>
      <div class="manualChapterSearch">
        <div class="miniToolHead"><div><strong>챕터 끝 지점</strong><span>검색한 문단을 이 챕터의 마지막 문단으로 설정합니다.</span></div></div>
        <div class="optionRow compactControls" id="manualChapterSearchFields"><span class="control">검색 <input type="search" data-chapter-end-keyword value="${safeAttr(chapterSearch.keyword || "")}" placeholder="끝나는 지점 키워드" autocomplete="off" autocapitalize="off" spellcheck="false"></span><span class="control">순서 <input type="number" min="1" data-chapter-end-order value="${safeAttr(chapterSearch.order || "")}" placeholder="번호" inputmode="numeric"></span></div>
        <div id="manualChapterSearchResults">${renderManualChapterSearchResultsHtml()}</div>
      </div>
    </div></details>`;
  }
  function renderManualChapterManager(){
    const toc = qs("#chapterTocInline");
    const div = qs("#chapterDividerPanel");
    if(!toc || !div) return;
    toc.innerHTML = `<div class="manualChapterHead"><strong>현재 챕터</strong><button type="button" class="btn primary" data-chapter-add="1">챕터 추가</button></div><div id="manualChapterRows" class="manualChapterRows"></div>`;
    div.innerHTML = `<div id="manualChapterEditHost"><div class="emptyState">편집을 누르면 챕터 끝 지점, 문구, 이미지를 설정할 수 있습니다.</div></div>`;
    renderManualChapterRows();
  }
  function installChapterManagerUi(){
    const details = qsa("#epubBoard details.foldBlock").find(d => (d.querySelector("summary") || {}).textContent && d.querySelector("summary").textContent.includes("챕터와 목차"));
    if(!details || details.dataset.manualChapterInstalled === "1") return;
    details.dataset.manualChapterInstalled = "1";
    const body = qs(".blockBody", details);
    if(!body) return;
    body.innerHTML = `<div class="manualChapterIntro">목차처럼 챕터를 관리합니다. 챕터를 추가한 뒤 편집에서 끝나는 지점을 정하세요.</div><div id="chapterTocInline" class="chapterTocInline"></div><div id="chapterDividerPanel" class="chapterDividerPanel"></div>`;
    renderManualChapterManager();
  }
  function findChapterById(id){ return currentPlan().chapters.find(ch => ch.id === id); }
  function addChapter(){
    const plan = currentPlan();
    plan.chapters.push({ id: uid(), title: getChapterTitleFallback(plan.chapters.length), endPara: null, note:"", imageData:"", imageName:"", imageType:"", imagePos:"belowTitle" });
    saveState();
    renderManualChapterManager();
    renderChapterEditPanel(plan.chapters[plan.chapters.length - 1].id);
    refreshChapterOutputs();
  }
  function deleteChapter(id){
    const plan = currentPlan();
    if(plan.chapters.length <= 1) return;
    plan.chapters = plan.chapters.filter(ch => ch.id !== id);
    saveState();
    renderManualChapterManager();
    refreshChapterOutputs();
  }
  function refreshChapterOutputs(){
    renderManualChapterRows();
    renderManualChapterSeparatorsInEditor();
    if(typeof updateEpubPreview === "function") updateEpubPreview();
    if(typeof scheduleAutosave === "function") scheduleAutosave();
  }
  function renderManualChapterSeparatorsInEditor(){
    if(mode() !== "epubedit" || typeof epubEditEditor === "undefined" || !epubEditEditor) return;
    qsa(".manual-chapter-separator", epubEditEditor).forEach(n => n.remove());
    const plan = currentPlan();
    const ends = new Set(plan.chapters.slice(0, -1).map(ch => ch.endPara).filter(v => v !== null && v !== undefined).map(Number));
    if(!ends.size) return;
    const nodes = Array.from(epubEditEditor.childNodes).filter(node => !(node.nodeType === Node.ELEMENT_NODE && node.classList && node.classList.contains("manual-chapter-separator")) && ((node.textContent || "").trim() || node.nodeType === Node.ELEMENT_NODE));
    nodes.forEach((node, idx) => {
      if(ends.has(idx)){
        const hr = document.createElement("hr");
        hr.className = "manual-chapter-separator chapter-editor-separator";
        hr.setAttribute("contenteditable", "false");
        hr.setAttribute("data-manual-chapter", "true");
        node.parentNode && node.parentNode.insertBefore(hr, node.nextSibling);
      }
    });
  }
  function handleChapterManagerClick(ev){
    const add = ev.target.closest("[data-chapter-add]");
    if(add){ addChapter(); return; }
    const edit = ev.target.closest("[data-chapter-edit]");
    if(edit){ chapterSearch = { keyword:"", order:"", page:0, editingId:edit.dataset.chapterEdit }; renderChapterEditPanel(edit.dataset.chapterEdit); return; }
    const del = ev.target.closest("[data-chapter-delete]");
    if(del){ if(confirm("이 챕터를 삭제하시겠습니까?")) deleteChapter(del.dataset.chapterDelete); return; }
    const prevNext = ev.target.closest("[data-manual-chapter-page]");
    if(prevNext){ const max = Math.max(0, chapterSearchMatches().length - 1); chapterSearch.page = prevNext.dataset.manualChapterPage === "next" ? Math.min(max, chapterSearch.page + 1) : Math.max(0, chapterSearch.page - 1); renderChapterEditPanel(chapterSearch.editingId); return; }
    const setEnd = ev.target.closest("[data-chapter-set-end]");
    if(setEnd){ const ch = findChapterById(chapterSearch.editingId); if(ch){ ch.endPara = Number(setEnd.dataset.chapterSetEnd); const plan = currentPlan(); const units = getChapterUnits(); ensureTrailingChapter(plan, units); saveState(); renderManualChapterManager(); renderChapterEditPanel(ch.id); refreshChapterOutputs(); toast("챕터 끝 지점을 설정했습니다."); } return; }
    const clearEnd = ev.target.closest("[data-chapter-clear-end]");
    if(clearEnd){ const ch = findChapterById(chapterSearch.editingId); if(ch){ ch.endPara = null; saveState(); renderChapterEditPanel(ch.id); refreshChapterOutputs(); } return; }
    const clearImg = ev.target.closest("[data-chapter-image-clear]");
    if(clearImg){ const ch = findChapterById(chapterSearch.editingId); if(ch){ ch.imageData=""; ch.imageName=""; ch.imageType=""; saveState(); renderChapterEditPanel(ch.id); refreshChapterOutputs(); } return; }
  }
  function handleChapterManagerInput(ev){
    const ch = findChapterById(chapterSearch.editingId);
    if(ev.target.matches("[data-chapter-title]") && ch){ ch.title = ev.target.value; saveState(); renderManualChapterRows(); refreshChapterOutputs(); return; }
    if(ev.target.matches("[data-chapter-note]") && ch){ ch.note = ev.target.value; saveState(); refreshChapterOutputs(); return; }
    if(ev.target.matches("[data-chapter-image-pos]") && ch){ ch.imagePos = ev.target.value; saveState(); refreshChapterOutputs(); return; }
    if(ev.target.matches("[data-chapter-end-keyword]")){ chapterSearch.keyword = ev.target.value; chapterSearch.page = 0; refreshManualChapterSearchResults(); saveState(); return; }
    if(ev.target.matches("[data-chapter-end-order]")){ chapterSearch.order = ev.target.value; chapterSearch.page = 0; refreshManualChapterSearchResults(); saveState(); return; }
  }
  function handleChapterImageChange(ev){
    const input = ev.target.closest("[data-chapter-image]");
    if(!input) return;
    const ch = findChapterById(chapterSearch.editingId);
    const file = input.files && input.files[0];
    if(!ch || !file) return;
    if(file.size > 6 * 1024 * 1024){ toast("이미지는 6MB 이하만 권장합니다."); return; }
    const reader = new FileReader();
    reader.onload = () => { ch.imageData = String(reader.result || ""); ch.imageName = file.name || "chapter-image"; ch.imageType = file.type || (file.name.toLowerCase().endsWith(".svg") ? "image/svg+xml" : "image/png"); saveState(); renderChapterEditPanel(ch.id); refreshChapterOutputs(); };
    reader.onerror = () => toast("이미지를 읽지 못했습니다.");
    reader.readAsDataURL(file);
  }

  function renderChapterTocClickable(chapters){
    if(!chapters || !chapters.length) return `<div class="emptyState">챕터가 아직 없습니다. 결과가 생기면 표시됩니다.</div>`;
    return chapters.map((ch, idx) => {
      const text = (ch.body ? ch.body : plainFromHtml(ch.bodyHtml || "")).replace(/\s+/g," ").trim();
      const preview = text.slice(0, 180);
      return `<details class="chapterPreviewItem"><summary><b>${idx + 1}</b><span><strong>${safeHtml(ch.title)}</strong>${preview ? `<small>${safeHtml(preview)}</small>` : ""}</span><em>${Number(text.length || 0).toLocaleString("ko-KR")}자</em></summary><div class="bookPreview chapterPreviewBody">${fullChapterHtml(ch, false) || `<p class="mutedText">미리보기 없음</p>`}</div></details>`;
    }).join("");
  }
  window.renderChapterTocHtml = renderChapterTocHtml = function(chapters, compact){
    if(compact){
      if(!chapters || !chapters.length) return `<div class="emptyState">현재 챕터가 없습니다.</div>`;
      return `<div class="chapterTocBox"><div class="tocSummary"><strong>현재 목차</strong><span>${chapters.length}개 챕터</span></div>${chapters.map((ch,idx)=>`<div class="chapterTocRow"><b>${idx+1}</b><span><strong>${safeHtml(ch.title)}</strong><small>${safeHtml((ch.body || plainFromHtml(ch.bodyHtml || "")).replace(/\s+/g," ").slice(0,70))}</small></span><em>${Number((ch.body || plainFromHtml(ch.bodyHtml || "")).length).toLocaleString("ko-KR")}자</em></div>`).join("")}</div>`;
    }
    return renderChapterTocClickable(chapters);
  };
  window.updateEpubPreview = updateEpubPreview = function(){
    const chapters = getExportChapters();
    const cfg = (typeof getEpubConfig === "function") ? getEpubConfig() : {title:"정리한 로그", author:""};
    if(chapterPreviewEl) chapterPreviewEl.innerHTML = renderChapterTocClickable(chapters);
    // 수동 관리 UI가 설치되어 있으면 위쪽 목차는 관리 UI가 담당합니다. 미설치 상태에서는 간단 목차를 표시합니다.
    if(chapterTocInlineEl && !qs("#manualChapterRows")) chapterTocInlineEl.innerHTML = renderChapterTocHtml(chapters, true);
    if(epubPreviewEl){
      const first = chapters[0];
      epubPreviewEl.innerHTML = `<div class="previewMeta"><b>${safeHtml(cfg.title || "정리한 로그")}</b>${cfg.author ? `<span>${safeHtml(cfg.author)}</span>` : ""}<span>${chapters.length || 0}개 챕터</span></div><div class="bookPreview">${first ? fullChapterHtml(first, true) : `<p class="mutedText">미리보기 없음</p>`}</div>`;
    }
  };

  window.buildStandaloneHTML = buildStandaloneHTML = function(){
    const cfg = (typeof getEpubConfig === "function") ? getEpubConfig() : {title:"정리한 로그", language:"ko"};
    const chapters = getExportChapters();
    const toc = chapters.map((ch, idx) => `<li><a href="#ch${idx+1}">${safeHtml(ch.title)}</a></li>`).join("\n");
    const body = chapters.map((ch, idx) => `<section id="ch${idx+1}">${fullChapterHtml(ch, true)}</section>`).join("\n");
    return `<!doctype html><html lang="${safeAttr(cfg.language || "ko")}"><head><meta charset="utf-8"><title>${safeHtml(cfg.title || "정리한 로그")}</title><style>${typeof getEpubCss === "function" ? getEpubCss() : ""} nav{margin-bottom:2rem;padding:1rem;border:1px solid #ddd;border-radius:12px;} section{max-width:720px;margin:0 auto 3rem;} .chapterNote{color:#6f8b9b;} .chapterImage img{max-width:100%;height:auto;display:block;margin:1em auto;}</style></head><body><nav><strong>목차</strong><ol>${toc}</ol></nav>${body}</body></html>`;
  };
  window.chapterBodyToXhtml = chapterBodyToXhtml = function(ch){ return fullChapterHtml(ch, false); };

  const originalDownloadEpub = (typeof downloadEpub === "function") ? downloadEpub : null;
  window.downloadEpub = downloadEpub = async function(){
    // 기존 ZIP 생성기를 유지하면서 챕터 HTML만 확실히 수동 챕터 기준으로 들어가게 합니다.
    if(typeof createZipBlob !== "function" || typeof makeXhtmlDoc !== "function" || typeof getCoverInfo !== "function"){
      return originalDownloadEpub ? originalDownloadEpub() : undefined;
    }
    const cfg = (typeof getEpubConfig === "function") ? getEpubConfig() : {title:"정리한 로그", language:"ko", tags:[]};
    const chapters = getExportChapters();
    if(!chapters.length){ toast("EPUB으로 만들 결과가 없습니다."); return; }
    const cover = await getCoverInfo();
    const entries = [];
    entries.push({name:"mimetype", data:"application/epub+zip"});
    entries.push({name:"META-INF/container.xml", data:`<?xml version="1.0" encoding="UTF-8"?><container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container"><rootfiles><rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/></rootfiles></container>`});
    entries.push({name:"OEBPS/styles.css", data:(typeof getEpubCss === "function" ? getEpubCss() : "") + `.chapterNote{color:#6f8b9b;margin:.3em 0 1em}.chapterImage{text-align:center;margin:1em 0}.chapterImage img{max-width:100%;height:auto}`});
    const chapterItems = [];
    chapters.forEach((ch, idx) => {
      const file = `chapter-${String(idx+1).padStart(3,"0")}.xhtml`;
      chapterItems.push({id:`ch${idx+1}`, href:file, title:ch.title});
      entries.push({name:`OEBPS/${file}`, data:makeXhtmlDoc(ch.title, fullChapterHtml(ch, true))});
    });
    if(cover){
      entries.push({name:`OEBPS/${cover.name}`, data:cover.data});
      entries.push({name:"OEBPS/cover.xhtml", data:makeXhtmlDoc("Cover", `<section class="cover"><img src="${safeAttr(cover.name)}" alt="cover"/></section>`)});
    }
    const navItems = chapterItems.map(item => `<li><a href="${safeAttr(item.href)}">${safeHtml(item.title)}</a></li>`).join("");
    entries.push({name:"OEBPS/nav.xhtml", data:makeXhtmlDoc("목차", `<nav epub:type="toc" id="toc"><h1>목차</h1><ol>${navItems}</ol></nav>`)});
    const uidValue = (typeof uuidLike === "function") ? uuidLike() : ("id-" + Date.now());
    const metaTags = [`<dc:identifier id="pub-id">${safeHtml(uidValue)}</dc:identifier>`,`<dc:title>${safeHtml(cfg.title || "정리한 로그")}</dc:title>`, cfg.subtitle ? `<dc:title id="subtitle">${safeHtml(cfg.subtitle)}</dc:title>` : "", cfg.author ? `<dc:creator>${safeHtml(cfg.author)}</dc:creator>` : "", `<dc:language>${safeHtml(cfg.language || "ko")}</dc:language>`, cfg.description ? `<dc:description>${safeHtml(cfg.description)}</dc:description>` : "", ...((cfg.tags||[]).map(tag => `<dc:subject>${safeHtml(tag)}</dc:subject>`)), cfg.series ? `<meta property="belongs-to-collection" id="series">${safeHtml(cfg.series)}</meta>` : "", cfg.volume ? `<meta property="group-position">${safeHtml(cfg.volume)}</meta>` : "", `<meta property="dcterms:modified">${new Date().toISOString().replace(/\.\d{3}Z$/, "Z")}</meta>`, cover ? `<meta name="cover" content="cover-image"/>` : ""].filter(Boolean).join("\n");
    const manifest = [`<item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/>`, `<item id="css" href="styles.css" media-type="text/css"/>`, cover ? `<item id="cover" href="cover.xhtml" media-type="application/xhtml+xml"/>` : "", cover ? `<item id="cover-image" href="${safeAttr(cover.name)}" media-type="${safeAttr(cover.media)}" properties="cover-image"/>` : "", ...chapterItems.map(item => `<item id="${item.id}" href="${safeAttr(item.href)}" media-type="application/xhtml+xml"/>`)].filter(Boolean).join("\n");
    const spine = [cover ? `<itemref idref="cover" linear="no"/>` : "", ...chapterItems.map(item => `<itemref idref="${item.id}"/>`)].filter(Boolean).join("\n");
    const opf = `<?xml version="1.0" encoding="UTF-8"?><package version="3.0" unique-identifier="pub-id" xmlns="http://www.idpf.org/2007/opf" xmlns:dc="http://purl.org/dc/elements/1.1/"><metadata>${metaTags}</metadata><manifest>${manifest}</manifest><spine>${spine}</spine></package>`;
    entries.push({name:"OEBPS/content.opf", data:opf});
    const blob = createZipBlob(entries, "application/epub+zip");
    downloadBlob(blob, (typeof safeDownloadFileName === "function" ? safeDownloadFileName(".epub", cfg.title) : `${cfg.title || "book"}.epub`));
  };

  function installEmojiControl(){
    if(qs("#removeEmojiParagraphs")) return;
    const row = qs(".basicOptionsRow") || qs("#optionsBoard .optionRow");
    if(!row) return;
    const label = document.createElement("label");
    label.className = "toggle compactToggle";
    label.innerHTML = `<input type="checkbox" id="removeEmojiParagraphs">이모지 포함 문단 제거`;
    row.insertBefore(label, row.querySelector("#protectEnabled") ? row.querySelector("#protectEnabled").closest("label") : null);
    qs("#removeEmojiParagraphs").addEventListener("change", () => { if(typeof transformText === "function") transformText(); saveState(); });
  }
  const originalStructuralPlan = (typeof createStructuralDeletePlan === "function") ? createStructuralDeletePlan : null;
  window.createStructuralDeletePlan = createStructuralDeletePlan = function(chunks, dropBlockIds){
    const plan = originalStructuralPlan ? originalStructuralPlan(chunks, dropBlockIds) : { dropBlockIds: dropBlockIds || new Set(), dropChunkIds: new Set() };
    const enabled = qs("#removeEmojiParagraphs") && qs("#removeEmojiParagraphs").checked;
    if(enabled){
      const tokens = (typeof getProtectTokens === "function") ? getProtectTokens() : [];
      (chunks || []).forEach(chunk => {
        if(!chunk || (plan.dropBlockIds && plan.dropBlockIds.has(chunk.blockId))) return;
        const text = String(chunk.text || "");
        if(EMOJI_RE.test(text) && !(typeof isProtectedText === "function" && isProtectedText(text, tokens))) plan.dropChunkIds.add(chunk.id);
      });
    }
    return plan;
  };

  function removeWorkflowBlock(){
    qsa("aside.sidebar").forEach(n => n.remove());
    qsa(".sideCard").forEach(n => { if(qs(".flowList", n) || /입력과 결과|정리 옵션|검토 보드|EPUB 제작|내보내기/.test(n.textContent || "")) n.remove(); });
    qsa(".flowList").forEach(n => { const card = n.closest(".sideCard,.card,aside"); (card || n).remove(); });
  }

  function applyModeLayout(){
    const isEdit = mode() === "epubedit";
    const options = qs("#optionsBoard");
    const review = qs("#reviewBoard");
    if(options) options.classList.toggle("hidden", isEdit);
    if(review) review.classList.toggle("hidden", isEdit);
    const epubBoard = qs("#epubBoard");
    if(epubBoard){
      epubBoard.classList.toggle("epubCollapsed", !isEdit && epubBoardCollapsedForTextTabs);
      const btn = qs("#epubBoardToggleBtn");
      if(btn){ btn.textContent = (!isEdit && epubBoardCollapsedForTextTabs) ? "펼치기" : "접기"; btn.classList.toggle("hidden", isEdit); }
    }
    qsa(".flowItem").forEach(btn => {
      const text = btn.textContent || "";
      if(/정리 옵션|검토 보드/.test(text)) btn.classList.toggle("hidden", isEdit);
    });
  }
  function installEpubBoardCollapse(){
    const board = qs("#epubBoard");
    if(!board || qs("#epubBoardToggleBtn")) return;
    const head = qs(".sectionHead", board);
    if(!head) return;
    const btn = document.createElement("button");
    btn.type = "button";
    btn.id = "epubBoardToggleBtn";
    btn.className = "btn subtle";
    btn.textContent = "펼치기";
    btn.addEventListener("click", () => { epubBoardCollapsedForTextTabs = !epubBoardCollapsedForTextTabs; applyModeLayout(); });
    head.appendChild(btn);
  }
  function closeEpubEditToolsOnLoad(){
    qsa("#epubEditPanel .epubToolStack details.foldBlock").forEach(d => d.removeAttribute("open"));
  }
  const originalSyncActiveResultHeight = (typeof syncActiveResultHeight === "function") ? syncActiveResultHeight : null;
  window.syncActiveResultHeight = syncActiveResultHeight = function(){
    if(mode() !== "classic" && mode() !== "chat") return;
    const panel = mode() === "chat" ? qs("#chatPanel") : qs("#classicPanel");
    if(!panel || panel.classList.contains("hidden")) return;
    const leftInput = mode() === "chat" ? qs("#chatPaste", panel) : qs("#inputText", panel);
    const preview = mode() === "chat" ? qs("#chatOutputTextPreview", panel) : qs("#outputTextPreview", panel);
    const resultBox = preview ? preview.closest(".resultBox") : null;
    if(!leftInput || !preview) return;
    const apply = () => {
      preview.style.overflow = "auto";
      preview.style.boxSizing = "border-box";
      preview.style.flex = "0 0 auto";
      if(window.matchMedia("(max-width: 860px)").matches){
        preview.style.height = "420px";
        preview.style.maxHeight = "420px";
        preview.style.minHeight = "320px";
        if(resultBox) resultBox.style.height = "auto";
        return;
      }
      // 왼쪽 입력창의 실제 밑변을 기준으로 오른쪽 결과창 밑변을 고정합니다.
      // 결과 내용이 길어져도 카드 자체가 늘어나지 않고 내부 스크롤만 생기게 합니다.
      const bottom = leftInput.getBoundingClientRect().bottom;
      const top = preview.getBoundingClientRect().top;
      const h = Math.max(320, Math.round(bottom - top));
      preview.style.setProperty("--synced-result-height", h + "px");
      preview.style.height = h + "px";
      preview.style.maxHeight = h + "px";
      preview.style.minHeight = "0";
      if(resultBox){
        resultBox.style.height = Math.round(leftInput.getBoundingClientRect().bottom - resultBox.getBoundingClientRect().top) + "px";
        resultBox.style.minHeight = "0";
        resultBox.style.alignSelf = "start";
        resultBox.style.overflow = "visible";
      }
    };
    requestAnimationFrame(apply);
    setTimeout(apply, 80);
    setTimeout(apply, 240);
  };
  const originalSetResultOutput = (typeof setResultOutput === "function") ? setResultOutput : null;
  if(originalSetResultOutput){
    window.setResultOutput = setResultOutput = function(el, value){ originalSetResultOutput(el, value); setTimeout(syncActiveResultHeight, 0); };
  }

  function installPatchCss(){
    if(qs("#rofanFinalPatchCss")) return;
    const style = document.createElement("style");
    style.id = "rofanFinalPatchCss";
    style.textContent = `
      aside.sidebar,.sideCard:has(.flowList),.workflowBlock,.flowList{display:none!important;}
      #epubBoard.epubCollapsed .epubGrid,#epubBoard.epubCollapsed .epubPreviewGrid{display:none!important;}
      .chapterTitleControl{grid-column:1/-1!important;}
      .actionDock .downloadNameControl{white-space:nowrap!important;}
      #epubBoardToggleBtn{margin-left:auto;}
      #optionsBoard.hidden,#reviewBoard.hidden,.flowItem.hidden{display:none!important;}
      .editorGrid{align-items:start!important;}
      .editorBox.resultBox{align-self:start!important;min-height:0!important;overflow:visible!important;}
      .editorBox.resultBox .rawResultStorage{display:none!important;}
      .editorBox.resultBox .richResultBox{display:block!important;height:var(--synced-result-height,520px)!important;min-height:0!important;max-height:var(--synced-result-height,520px)!important;overflow:auto!important;flex:0 0 auto!important;box-sizing:border-box!important;}
      .manualChapterIntro{padding:10px 12px;border:1px dashed var(--line);border-radius:14px;background:var(--paper2);color:var(--muted);font-size:12px;line-height:1.6;margin-bottom:12px;}
      .manualChapterHead{display:flex;justify-content:space-between;gap:10px;align-items:center;margin-bottom:10px;}
      .manualChapterRows{display:grid;gap:8px;}
      .manualChapterRow{display:grid;grid-template-columns:30px minmax(0,1fr) auto auto;gap:8px;align-items:center;border:1px solid var(--line);border-radius:14px;background:#fff;padding:9px 10px;}
      .manualChapterRow b{width:24px;height:24px;border-radius:8px;background:var(--paper2);display:grid;place-items:center;color:var(--sub);font-size:12px;}
      .manualChapterRow span{min-width:0;display:flex;flex-direction:column;gap:2px;}
      .manualChapterRow strong{font-weight:760;color:rgba(31,45,54,.76);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
      .manualChapterRow small{color:var(--muted);font-size:11px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
      .manualChapterEditor{border:1px solid var(--line);border-radius:16px;background:#fff;overflow:hidden;margin-top:12px;}
      .manualChapterEditor>summary{list-style:none;cursor:pointer;padding:13px 15px;font-weight:760;color:rgba(31,45,54,.76);display:flex;justify-content:space-between;}
      .manualChapterEditor>summary::-webkit-details-marker{display:none;}
      .manualChapterEditorBody{border-top:1px solid var(--line2);padding:14px;display:grid;gap:14px;}
      .manualChapterForm{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;}
      .manualChapterForm .wide{grid-column:1/-1;}
      .manualChapterSearch{border:1px solid var(--line2);border-radius:16px;background:var(--paper2);padding:12px;}
      .chapterPreviewItem{border:1px solid var(--line);border-radius:16px;background:#fff;margin:8px 0;overflow:hidden;}
      .chapterPreviewItem>summary{list-style:none;display:grid;grid-template-columns:30px minmax(0,1fr) auto;gap:9px;align-items:center;cursor:pointer;padding:10px 12px;}
      .chapterPreviewItem>summary::-webkit-details-marker{display:none;}
      .chapterPreviewItem>summary b{width:24px;height:24px;border-radius:8px;background:var(--paper2);display:grid;place-items:center;color:var(--sub);font-size:11px;}
      .chapterPreviewItem>summary span{min-width:0;display:flex;flex-direction:column;gap:2px;}
      .chapterPreviewItem>summary strong{font-weight:760;color:rgba(31,45,54,.76);}
      .chapterPreviewItem>summary small{color:var(--muted);font-size:11px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
      .chapterPreviewItem>summary em{font-style:normal;color:var(--muted);font-size:11px;white-space:nowrap;}
      .chapterPreviewBody{border-top:1px solid var(--line2);border-radius:0!important;max-height:420px;}
      .chapterNote{color:var(--muted);font-size:.95em;margin:.2em 0 1em;}
      .chapterImage{text-align:center;margin:1em 0;}
      .chapterImage img{max-width:100%;height:auto;border-radius:12px;}
      .manual-chapter-separator{border:0;border-top:2px dashed var(--line);margin:18px 0;position:relative;}
      .manual-chapter-separator:after{content:"챕터 구분";display:inline-block;position:relative;top:-13px;background:var(--paper);border:1px solid var(--line);border-radius:999px;padding:2px 8px;color:var(--muted);font-size:11px;}
      @media(max-width:860px){.manualChapterForm{grid-template-columns:1fr}.manualChapterRow{grid-template-columns:26px minmax(0,1fr);}.manualChapterRow .btn{font-size:11px;padding:6px 8px;min-height:30px}.chapterPreviewItem>summary{grid-template-columns:26px minmax(0,1fr)}.chapterPreviewItem>summary em{grid-column:2}.editorBox.resultBox .richResultBox{height:420px!important;max-height:420px!important;min-height:320px!important;}}
    `;
    document.head.appendChild(style);
  }

  document.addEventListener("click", ev => {
    if(ev.target.closest("#chapterTocInline") || ev.target.closest("#chapterDividerPanel")) handleChapterManagerClick(ev);
  });
  document.addEventListener("input", ev => {
    if(ev.target.closest("#chapterTocInline") || ev.target.closest("#chapterDividerPanel")) handleChapterManagerInput(ev);
  });
  document.addEventListener("change", ev => {
    if(ev.target.closest("#chapterTocInline") || ev.target.closest("#chapterDividerPanel")) handleChapterImageChange(ev);
  });
  qsa(".tab").forEach(tab => tab.addEventListener("click", () => setTimeout(() => { installChapterManagerUi(); renderManualChapterManager(); applyModeLayout(); renderManualChapterSeparatorsInEditor(); updateEpubPreview(); syncActiveResultHeight(); }, 0)));
  ["input","change"].forEach(evt => {
    if(typeof epubEditEditor !== "undefined" && epubEditEditor) epubEditEditor.addEventListener(evt, () => setTimeout(() => { renderManualChapterRows(); renderManualChapterSeparatorsInEditor(); updateEpubPreview(); }, 0));
  });


  function installResultHeightWatchers(){
    const targets = [qs("#chatPaste"), qs("#inputText"), qs("#chatOutputTextPreview"), qs("#outputTextPreview")].filter(Boolean);
    if(window.ResizeObserver){
      const ro = new ResizeObserver(() => syncActiveResultHeight());
      targets.forEach(t => ro.observe(t));
    }
    ["load","resize","orientationchange"].forEach(ev => window.addEventListener(ev, () => setTimeout(syncActiveResultHeight, 60), {passive:true}));
    setInterval(() => { if(mode() === "classic" || mode() === "chat") syncActiveResultHeight(); }, 800);
  }

  function initFinalPatch(){
    removeWorkflowBlock();
    installPatchCss();
    installEmojiControl();
    installEpubBoardCollapse();
    installResultHeightWatchers();
    closeEpubEditToolsOnLoad();
    installChapterManagerUi();
    renderManualChapterManager();
    applyModeLayout();
    renderManualChapterSeparatorsInEditor();
    if(typeof transformText === "function") transformText();
    updateEpubPreview();
    setTimeout(syncActiveResultHeight, 40);
  }
  if(document.readyState === "loading") document.addEventListener("DOMContentLoaded", initFinalPatch);
  else initFinalPatch();
})();

/* --- 2026-06-07 stable chapter split + epub-edit layout patch --- */
(function(){
  function qs(sel, root=document){ return root.querySelector(sel); }
  function qsa(sel, root=document){ return Array.from(root.querySelectorAll(sel)); }
  function safeHtmlLocal(v){
    if(typeof escapeHTML === 'function') return escapeHTML(v || '');
    return String(v || '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  }
  function safeAttrLocal(v){
    if(typeof escapeAttr === 'function') return escapeAttr(v || '');
    return safeHtmlLocal(v || '').replace(/`/g,'&#096;');
  }
  function plainLocal(html){
    if(typeof blockHtmlToText === 'function') return blockHtmlToText(html || '');
    const d = document.createElement('div');
    d.innerHTML = html || '';
    return (d.innerText || d.textContent || '').trim();
  }
  function stripTagsLocal2(v){
    if(typeof stripHTMLTags === 'function') return stripHTMLTags(v || '');
    const d = document.createElement('div');
    d.innerHTML = String(v || '');
    return d.textContent || d.innerText || '';
  }
  function currentMode(){ return (typeof activeMode === 'string' && activeMode) ? activeMode : 'classic'; }
  function getActiveOutputValueForPatch(){
    if(currentMode() === 'chat' && typeof chatOutput !== 'undefined' && chatOutput) return chatOutput.value || '';
    if(currentMode() === 'classic' && typeof output !== 'undefined' && output) return output.value || '';
    return '';
  }
  function sourceTextForPatch(){
    if(currentMode() === 'epubedit'){
      return (typeof epubEditEditor !== 'undefined' && epubEditEditor) ? (epubEditEditor.innerText || epubEditEditor.textContent || '') : '';
    }
    const activeVal = getActiveOutputValueForPatch();
    if(activeVal) return activeVal;
    if(typeof getPreparedOutputForExport === 'function') return getPreparedOutputForExport() || '';
    return '';
  }
  function splitLongSegment(seg){
    const text = String(seg || '').trim();
    if(!text) return [];
    if(text.length <= 650) return [text];
    const out = [];
    let rest = text;
    while(rest.length > 650){
      let cut = Math.max(
        rest.lastIndexOf('。', 640), rest.lastIndexOf('.', 640), rest.lastIndexOf('?', 640), rest.lastIndexOf('!', 640),
        rest.lastIndexOf('다 ', 640), rest.lastIndexOf('요 ', 640), rest.lastIndexOf('죠 ', 640), rest.lastIndexOf('네 ', 640), rest.lastIndexOf('까 ', 640)
      );
      if(cut < 220) cut = rest.lastIndexOf(' ', 640);
      if(cut < 220) cut = 640;
      const piece = rest.slice(0, cut + 1).trim();
      if(piece) out.push(piece);
      rest = rest.slice(cut + 1).trim();
    }
    if(rest) out.push(rest);
    return out;
  }
  function splitProseUnits(text){
    const raw = String(text || '')
      .replace(/\r/g, '')
      .replace(/<!--\s*rofan:[\s\S]*?-->/gi, '')
      .replace(/<hr[^>]*data-manual-chapter[^>]*>/gi, '\n\n')
      .trim();
    if(!raw) return [];
    const base = raw.split(/\n\s*\n+/).map(v => v.trim()).filter(Boolean);
    const out = [];
    const addPiece = (piece) => {
      const cleanText = stripTagsLocal2(piece).replace(/\s+/g, ' ').trim();
      if(!cleanText) return;
      splitLongSegment(piece).forEach(p => {
        const t = stripTagsLocal2(p).replace(/\s+/g, ' ').trim();
        if(t) out.push({ text:t, body:p });
      });
    };
    base.forEach(block => {
      const plain = stripTagsLocal2(block).replace(/\s+/g, ' ').trim();
      if(!plain) return;
      const hardLines = block.split(/\n+/).map(v => v.trim()).filter(Boolean);
      if(hardLines.length > 1){ hardLines.forEach(addPiece); return; }
      // 결과가 한 문단으로 붙는 경우에도 검색/챕터 분할용으로 문장 단위 후보를 만듭니다.
      const marked = block
        .replace(/([.!?。！？…]+[”"'’]?)(\s+)/g, '$1\n')
        .replace(/((?:습니다|습니까|입니다|입니까|했다|한다|된다|였다|었다|이다|였다|다|요|죠|네|까|오|음|임|함|됨)[”"'’]?)(\s+)/g, '$1\n')
        .replace(/([”"])(\s+)(?=[가-힣A-Za-z0-9“"])/g, '$1\n');
      const sentenceParts = marked.split(/\n+/).map(v => v.trim()).filter(Boolean);
      if(sentenceParts.length > 1){ sentenceParts.forEach(addPiece); return; }
      addPiece(block);
    });
    return out;
  }
  function editorUnitsPatch(){
    if(typeof epubEditEditor === 'undefined' || !epubEditEditor) return [];
    const nodes = Array.from(epubEditEditor.childNodes).filter(node => {
      if(node.nodeType === Node.ELEMENT_NODE && node.classList && node.classList.contains('manual-chapter-separator')) return false;
      return (node.textContent || '').trim() || node.nodeType === Node.ELEMENT_NODE;
    });
    if(!nodes.length) return splitProseUnits(epubEditEditor.innerText || epubEditEditor.textContent || '');
    const out = [];
    nodes.forEach(node => {
      const html = node.outerHTML || safeHtmlLocal(node.textContent || '');
      const text = plainLocal(html).replace(/\s+/g,' ').trim();
      if(!text) return;
      if(text.length > 900){
        splitProseUnits(text).forEach(u => out.push(u));
      }else{
        out.push({ text, body:text, html });
      }
    });
    return out;
  }
  function chapterUnitsPatch(){
    if(currentMode() === 'epubedit') return editorUnitsPatch();
    return splitProseUnits(sourceTextForPatch());
  }
  function getChapterPlanPatch(){
    try{
      const raw = JSON.parse(localStorage.getItem('rofan-manual-chapters-v2') || '{}');
      if(!raw[currentMode()]) raw[currentMode()] = { chapters: [] };
      if(!Array.isArray(raw[currentMode()].chapters)) raw[currentMode()].chapters = [];
      if(!raw[currentMode()].chapters.length){
        raw[currentMode()].chapters.push({ id:'ch-' + Date.now().toString(36), title:'Prologue', endPara:null, note:'', imageData:'', imageName:'', imageType:'', imagePos:'belowTitle' });
        localStorage.setItem('rofan-manual-chapters-v2', JSON.stringify(raw));
      }
      return raw[currentMode()];
    }catch(_){ return { chapters:[{id:'ch-fallback', title:'Prologue', endPara:null, note:'', imageData:'', imageName:'', imageType:'', imagePos:'belowTitle'}] }; }
  }
  function saveChapterPlanPatch(plan){
    try{
      const raw = JSON.parse(localStorage.getItem('rofan-manual-chapters-v2') || '{}');
      raw[currentMode()] = plan;
      localStorage.setItem('rofan-manual-chapters-v2', JSON.stringify(raw));
    }catch(_){ }
  }
  function titleFallbackPatch(idx){
    if(idx === 0) return 'Prologue';
    return 'Chapter ' + (idx + 1);
  }
  function normalizePlanPatch(plan, units, mutate){
    if(!plan || !Array.isArray(plan.chapters)) plan = {chapters:[]};
    if(!plan.chapters.length) plan.chapters.push({id:'ch-' + Date.now().toString(36), title:titleFallbackPatch(0), endPara:null, note:'', imageData:'', imageName:'', imageType:'', imagePos:'belowTitle'});
    const max = Math.max(0, units.length - 1);
    let prevEnd = -1;
    plan.chapters.forEach((ch, idx) => {
      if(!ch.id) ch.id = 'ch-' + idx + '-' + Date.now().toString(36);
      if(!ch.title) ch.title = titleFallbackPatch(idx);
      if(ch.endPara === '' || ch.endPara === undefined || ch.endPara === null){ ch.endPara = null; return; }
      let end = Math.max(0, Math.min(max, Number(ch.endPara) || 0));
      if(end <= prevEnd) end = null;
      ch.endPara = end;
      if(end !== null) prevEnd = end;
    });
    const last = plan.chapters[plan.chapters.length - 1];
    if(units.length && last && last.endPara !== null && last.endPara !== undefined && Number(last.endPara) < max){
      plan.chapters.push({id:'ch-' + Date.now().toString(36) + '-auto', title:titleFallbackPatch(plan.chapters.length), endPara:null, note:'', imageData:'', imageName:'', imageType:'', imagePos:'belowTitle'});
    }
    if(mutate) saveChapterPlanPatch(plan);
    return plan;
  }
  function paraHtmlPatch(u){
    if(u && u.html) return u.html;
    const body = (u && (u.body || u.text)) || '';
    if(typeof paragraphToXhtml === 'function') return paragraphToXhtml(body);
    return '<p>' + safeHtmlLocal(body).replace(/\n/g,'<br>') + '</p>';
  }
  function imageHtmlPatch(ch){
    if(!ch || !ch.imageData) return '';
    return `<figure class="chapterImage"><img src="${safeAttrLocal(ch.imageData)}" alt="${safeAttrLocal(ch.imageName || ch.title || 'chapter image')}"></figure>`;
  }
  function fullChapterHtmlPatch(ch, includeTitle){
    const note = ch.note ? `<p class="chapterNote">${safeHtmlLocal(ch.note).replace(/\n/g,'<br>')}</p>` : '';
    const img = imageHtmlPatch(ch);
    const top = ch.imagePos === 'aboveTitle' ? img : '';
    const mid = (!ch.imagePos || ch.imagePos === 'belowTitle') ? img : '';
    const bottom = ch.imagePos === 'bottom' ? img : '';
    return `${top}${includeTitle ? `<h1>${safeHtmlLocal(ch.title || '')}</h1>` : ''}${note}${mid}${ch.bodyHtml || ''}${bottom}`;
  }
  function chaptersFromPlanPatch(markdownMode){
    const units = chapterUnitsPatch();
    const plan = normalizePlanPatch(getChapterPlanPatch(), units, true);
    if(!units.length) return [];
    const chapters = [];
    let start = 0;
    plan.chapters.forEach((ch, idx) => {
      let end = ch.endPara;
      if(end === null || end === undefined) end = (idx === plan.chapters.length - 1) ? units.length - 1 : start - 1;
      end = Math.max(start - 1, Math.min(units.length - 1, Number(end)));
      const slice = end >= start ? units.slice(start, end + 1) : [];
      const body = slice.map(u => u.body || u.text || '').join('\n\n').trim();
      const bodyHtml = slice.map(paraHtmlPatch).join('\n');
      chapters.push({
        id: ch.id, title: ch.title || titleFallbackPatch(idx), body, bodyHtml,
        note: ch.note || '', imageData: ch.imageData || '', imageName: ch.imageName || '', imageType: ch.imageType || '', imagePos: ch.imagePos || 'belowTitle',
        startIndex: start, endIndex: end
      });
      start = end + 1;
    });
    return chapters.filter((ch, idx) => ch.body || ch.bodyHtml || ch.note || ch.imageData || idx === 0);
  }
  window.__rofanChapterUnitsPatch = chapterUnitsPatch;
  window.getExportChapters = window.getExportChapters = function(markdownMode){ return chaptersFromPlanPatch(markdownMode); };
  if(typeof getExportChapters !== 'undefined') getExportChapters = window.getExportChapters;
  window.chapterBodyToXhtml = window.chapterBodyToXhtml = function(ch){ return fullChapterHtmlPatch(ch, false); };
  if(typeof chapterBodyToXhtml !== 'undefined') chapterBodyToXhtml = window.chapterBodyToXhtml;

  function renderRowsPatch(){
    const box = qs('#manualChapterRows');
    if(!box) return;
    const units = chapterUnitsPatch();
    const plan = normalizePlanPatch(getChapterPlanPatch(), units, true);
    let start = 0;
    box.innerHTML = plan.chapters.map((ch, idx) => {
      let end = ch.endPara;
      if(end === null || end === undefined) end = idx === plan.chapters.length - 1 ? units.length - 1 : start - 1;
      end = Math.max(start - 1, Math.min(units.length - 1, Number(end)));
      const range = end >= start ? `${start + 1}–${Math.min(end + 1, units.length)}` : '끝 지점 미설정';
      start = end + 1;
      return `<div class="manualChapterRow" data-id="${safeAttrLocal(ch.id)}"><b>${idx + 1}</b><span><strong>${safeHtmlLocal(ch.title || titleFallbackPatch(idx))}</strong><small>${range}${ch.note ? ' · 문구 있음' : ''}${ch.imageData ? ' · 이미지 있음' : ''}</small></span><button type="button" class="btn subtle" data-chapter-edit="${safeAttrLocal(ch.id)}">편집</button>${plan.chapters.length > 1 ? `<button type="button" class="btn subtle warn" data-chapter-delete="${safeAttrLocal(ch.id)}">삭제</button>` : ''}</div>`;
    }).join('');
  }
  function updatePreviewPatch(){
    const chapters = chaptersFromPlanPatch(false);
    if(typeof renderChapterTocHtml === 'function'){
      const cp = qs('#chapterPreview');
      if(cp) cp.innerHTML = renderChapterTocHtml(chapters, false);
    }
    const epubPrev = qs('#epubPreview');
    if(epubPrev){
      const first = chapters[0];
      epubPrev.innerHTML = `<div class="previewMeta"><b>미리보기</b><span>${chapters.length}개 챕터</span></div><div class="bookPreview">${first ? fullChapterHtmlPatch(first, true) : '<p class="mutedText">미리보기 없음</p>'}</div>`;
    }
  }
  function currentEditId(){
    const open = qs('[data-chapter-title]');
    if(open){
      const editor = open.closest('.manualChapterEditor');
      const title = open.value;
      const plan = getChapterPlanPatch();
      const found = plan.chapters.find(ch => ch.title === title);
      if(found) return found.id;
    }
    const row = qs('.manualChapterRow [data-chapter-edit]');
    return row ? row.dataset.chapterEdit : null;
  }
  function searchMatchesPatch(){
    const units = chapterUnitsPatch();
    const qInput = qs('[data-chapter-end-keyword]');
    const oInput = qs('[data-chapter-end-order]');
    const q = (qInput ? qInput.value : '').trim().toLowerCase();
    const order = (oInput ? oInput.value : '').trim();
    let matches = units.map((u, idx) => ({...u, index:idx}));
    if(q) matches = matches.filter(u => String(u.text || '').toLowerCase().includes(q));
    if(order){
      const n = Number(order);
      if(Number.isFinite(n) && n > 0){ matches = q ? matches.filter((_u, idx) => idx + 1 === n) : matches.filter(u => u.index + 1 === n); }
    }
    return matches;
  }
  let searchPagePatch = 0;
  function matchPreviewPatch(item){
    const text = String((item && item.text) || '').replace(/\s+/g,' ').trim();
    const q = (qs('[data-chapter-end-keyword]') || {}).value || '';
    if(!q || text.length <= 450) return text;
    const pos = text.toLowerCase().indexOf(q.toLowerCase());
    if(pos < 0) return text.slice(0, 450) + '…';
    const s = Math.max(0, pos - 160), e = Math.min(text.length, pos + q.length + 260);
    return `${s ? '…' : ''}${text.slice(s, e)}${e < text.length ? '…' : ''}`;
  }
  function renderSearchResultsPatch(){
    const target = qs('#manualChapterSearchResults');
    if(!target) return;
    const matches = searchMatchesPatch();
    searchPagePatch = Math.max(0, Math.min(searchPagePatch, Math.max(0, matches.length - 1)));
    const cur = matches[searchPagePatch];
    target.innerHTML = `<div class="miniToolHead"><div><strong>챕터 끝 지점</strong><span>검색한 문단을 이 챕터의 마지막 문단으로 설정합니다.</span></div><span>${matches.length ? `${searchPagePatch + 1}/${matches.length}` : '0개'}</span></div>` +
      (cur ? `<div class="chapterMatchCard"><div class="dupeSummary withNav"><span><span class="pill">문단 ${cur.index + 1}</span></span><span class="navButtons"><button type="button" class="navIconBtn" data-patch-chapter-page="prev" ${searchPagePatch <= 0 ? 'disabled' : ''}>‹</button><button type="button" class="navIconBtn" data-patch-chapter-page="next" ${searchPagePatch >= matches.length - 1 ? 'disabled' : ''}>›</button></span></div><div class="previewText fullPreview chapterSearchPreview">${safeHtmlLocal(matchPreviewPatch(cur))}</div><div class="chapterInsertRow"><button type="button" class="btn primary" data-patch-chapter-set-end="${cur.index}">이 문단을 끝 지점으로 설정</button><button type="button" class="btn subtle" data-patch-chapter-clear-end="1">끝 지점 비우기</button></div></div>` : '<div class="emptyState">검색 결과가 없습니다. 키워드나 번호를 바꿔 보세요.</div>');
  }
  function setEndPatch(endIndex){
    const plan = getChapterPlanPatch();
    const titleInput = qs('[data-chapter-title]');
    let ch = null;
    if(titleInput){ ch = plan.chapters.find(c => c.title === titleInput.value) || plan.chapters[0]; }
    if(!ch) ch = plan.chapters[0];
    ch.endPara = Number(endIndex);
    normalizePlanPatch(plan, chapterUnitsPatch(), true);
    if(typeof showToast === 'function') showToast('챕터 끝 지점을 설정했습니다.');
    renderRowsPatch(); renderSearchResultsPatch(); updatePreviewPatch();
  }
  document.addEventListener('input', function(ev){
    if(ev.target && ev.target.matches && ev.target.matches('[data-chapter-end-keyword], [data-chapter-end-order]')){
      searchPagePatch = 0;
      setTimeout(renderSearchResultsPatch, 0);
    }
  }, true);
  document.addEventListener('click', function(ev){
    const nav = ev.target.closest && ev.target.closest('[data-patch-chapter-page]');
    if(nav){ const m = searchMatchesPatch(); searchPagePatch += nav.dataset.patchChapterPage === 'next' ? 1 : -1; searchPagePatch = Math.max(0, Math.min(searchPagePatch, Math.max(0,m.length-1))); renderSearchResultsPatch(); ev.preventDefault(); ev.stopPropagation(); return; }
    const set = ev.target.closest && ev.target.closest('[data-patch-chapter-set-end]');
    if(set){ setEndPatch(set.dataset.patchChapterSetEnd); ev.preventDefault(); ev.stopPropagation(); return; }
    const clear = ev.target.closest && ev.target.closest('[data-patch-chapter-clear-end]');
    if(clear){ const plan = getChapterPlanPatch(); const titleInput = qs('[data-chapter-title]'); const ch = titleInput ? (plan.chapters.find(c => c.title === titleInput.value) || plan.chapters[0]) : plan.chapters[0]; if(ch){ ch.endPara = null; saveChapterPlanPatch(plan); renderRowsPatch(); renderSearchResultsPatch(); updatePreviewPatch(); } ev.preventDefault(); ev.stopPropagation(); return; }
    if(ev.target.closest && ev.target.closest('[data-chapter-edit]')) setTimeout(() => { searchPagePatch = 0; renderSearchResultsPatch(); }, 40);
  }, true);

  function hideEditOnlyBoards(){
    const isEdit = currentMode() === 'epubedit';
    document.body.classList.toggle('rofan-epubedit-mode', isEdit);
    ['optionsBoard','reviewBoard'].forEach(id => {
      const el = document.getElementById(id);
      if(el) el.style.display = isEdit ? 'none' : '';
    });
  }
  function hardSyncResultHeight(){
    if(currentMode() !== 'classic' && currentMode() !== 'chat') return;
    const panel = currentMode() === 'chat' ? qs('#chatPanel') : qs('#classicPanel');
    if(!panel || panel.classList.contains('hidden')) return;
    const left = currentMode() === 'chat' ? qs('#chatPaste', panel) : (qs('#inputTextPreview', panel) || qs('#inputText', panel));
    const preview = currentMode() === 'chat' ? qs('#chatOutputTextPreview', panel) : qs('#outputTextPreview', panel);
    const box = preview && preview.closest('.resultBox');
    if(!left || !preview) return;
    if(window.matchMedia('(max-width: 860px)').matches){
      preview.style.height = '420px'; preview.style.maxHeight = '420px'; preview.style.overflow = 'auto'; return;
    }
    const apply = () => {
      const h = Math.max(320, Math.round(left.getBoundingClientRect().bottom - preview.getBoundingClientRect().top));
      preview.style.height = h + 'px'; preview.style.maxHeight = h + 'px'; preview.style.minHeight = '0'; preview.style.overflow = 'auto'; preview.style.flex = '0 0 auto';
      if(box){ box.style.height = Math.max(h, Math.round(left.getBoundingClientRect().bottom - box.getBoundingClientRect().top)) + 'px'; box.style.overflow = 'visible'; box.style.minHeight = '0'; }
    };
    requestAnimationFrame(apply); setTimeout(apply, 60); setTimeout(apply, 180);
  }
  function installPatchStyle(){
    if(qs('#rofanActuallyFinalPatchStyle')) return;
    const style = document.createElement('style');
    style.id = 'rofanActuallyFinalPatchStyle';
    style.textContent = `body.rofan-epubedit-mode #optionsBoard,body.rofan-epubedit-mode #reviewBoard{display:none!important}.editorBox.resultBox .richResultBox{overflow:auto!important;flex:0 0 auto!important}.chapterSearchPreview{max-height:360px!important;overflow:auto!important}`;
    document.head.appendChild(style);
  }
  const oldUpdatePreview = window.updateEpubPreview;
  window.updateEpubPreview = function(){
    updatePreviewPatch();
    if(typeof oldUpdatePreview === 'function'){
      // 기존 함수가 덮어쓰는 경우가 있어 한 번 더 보정합니다.
      try{ oldUpdatePreview(); }catch(_){ }
      setTimeout(updatePreviewPatch, 0);
    }
  };
  if(typeof updateEpubPreview !== 'undefined') updateEpubPreview = window.updateEpubPreview;
  const oldSync = window.syncActiveResultHeight;
  window.syncActiveResultHeight = function(){ if(typeof oldSync === 'function') try{ oldSync(); }catch(_){} hardSyncResultHeight(); };
  if(typeof syncActiveResultHeight !== 'undefined') syncActiveResultHeight = window.syncActiveResultHeight;

  function bootFinalFix(){
    installPatchStyle();
    hideEditOnlyBoards();
    renderRowsPatch();
    renderSearchResultsPatch();
    updatePreviewPatch();
    hardSyncResultHeight();
  }
  document.addEventListener('click', () => setTimeout(() => { hideEditOnlyBoards(); hardSyncResultHeight(); updatePreviewPatch(); }, 20), true);
  document.addEventListener('input', () => setTimeout(() => { hideEditOnlyBoards(); hardSyncResultHeight(); updatePreviewPatch(); }, 20), true);
  window.addEventListener('resize', () => setTimeout(hardSyncResultHeight, 50), {passive:true});
  setInterval(() => { hideEditOnlyBoards(); hardSyncResultHeight(); }, 700);
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bootFinalFix); else bootFinalFix();
})();


/* --- 2026-06-07 chapter edit persistence and preview fix --- */
(function(){
  const KEY = 'rofan-manual-chapters-v2';
  let pointerSnapshot = null;
  let activeChapterId = null;
  const openPreviewIndexes = new Set();

  function qs(sel, root=document){ return root.querySelector(sel); }
  function qsa(sel, root=document){ return Array.from(root.querySelectorAll(sel)); }
  function mode(){ return (typeof activeMode === 'string' && activeMode) ? activeMode : 'classic'; }
  function esc(v){
    if(typeof escapeHTML === 'function') return escapeHTML(v || '');
    return String(v || '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  }
  function getState(){
    try{ return JSON.parse(localStorage.getItem(KEY) || '{}') || {}; }
    catch(_){ return {}; }
  }
  function saveStateObj(state){
    try{ localStorage.setItem(KEY, JSON.stringify(state || {})); }catch(_){ }
    if(typeof scheduleAutosave === 'function') scheduleAutosave();
  }
  function getPlan(){
    const state = getState();
    if(!state[mode()]) state[mode()] = {chapters:[]};
    if(!Array.isArray(state[mode()].chapters)) state[mode()].chapters = [];
    if(!state[mode()].chapters.length) state[mode()].chapters.push({id:'ch-' + Date.now().toString(36), title:titleFor(0), endPara:null, note:'', imageData:'', imageName:'', imageType:'', imagePos:'belowTitle'});
    return {state, plan: state[mode()]};
  }
  function savePlan(plan){
    const state = getState();
    state[mode()] = plan;
    saveStateObj(state);
  }
  function titleFor(idx){ return idx === 0 ? 'Prologue' : 'Chapter ' + (idx + 1); }
  function plainFromHtml(html){
    if(typeof blockHtmlToText === 'function') return blockHtmlToText(html || '');
    const d = document.createElement('div'); d.innerHTML = html || ''; return (d.innerText || d.textContent || '').trim();
  }
  function strip(v){
    if(typeof stripHTMLTags === 'function') return stripHTMLTags(v || '');
    const d = document.createElement('div'); d.innerHTML = String(v || ''); return d.textContent || d.innerText || '';
  }
  function sourceText(){
    if(mode() === 'epubedit') return epubEditEditor ? (epubEditEditor.innerText || epubEditEditor.textContent || '') : '';
    if(mode() === 'chat' && chatOutput && chatOutput.value) return chatOutput.value;
    if(mode() === 'classic' && output && output.value) return output.value;
    if(typeof getPreparedOutputForExport === 'function') return getPreparedOutputForExport() || '';
    return '';
  }
  function splitLong(text){
    const t = String(text || '').trim();
    if(!t) return [];
    if(t.length <= 650) return [t];
    const out = [];
    let rest = t;
    while(rest.length > 650){
      let cut = Math.max(rest.lastIndexOf('。', 640), rest.lastIndexOf('.', 640), rest.lastIndexOf('?', 640), rest.lastIndexOf('!', 640), rest.lastIndexOf('다 ', 640), rest.lastIndexOf('요 ', 640), rest.lastIndexOf('죠 ', 640), rest.lastIndexOf('네 ', 640), rest.lastIndexOf('까 ', 640));
      if(cut < 220) cut = rest.lastIndexOf(' ', 640);
      if(cut < 220) cut = 640;
      out.push(rest.slice(0, cut + 1).trim());
      rest = rest.slice(cut + 1).trim();
    }
    if(rest) out.push(rest);
    return out.filter(Boolean);
  }
  function splitUnitsFromText(text){
    const raw = String(text || '').replace(/\r/g, '').replace(/<!--\s*rofan:[\s\S]*?-->/gi, '').replace(/<hr[^>]*data-manual-chapter[^>]*>/gi, '\n\n').trim();
    if(!raw) return [];
    const base = raw.split(/\n\s*\n+/).map(v => v.trim()).filter(Boolean);
    const out = [];
    const add = (piece) => {
      const clean = strip(piece).replace(/\s+/g, ' ').trim();
      if(!clean) return;
      splitLong(piece).forEach(p => {
        const text = strip(p).replace(/\s+/g, ' ').trim();
        if(text) out.push({text, body:p});
      });
    };
    base.forEach(block => {
      const lines = block.split(/\n+/).map(v => v.trim()).filter(Boolean);
      if(lines.length > 1){ lines.forEach(add); return; }
      const marked = block
        .replace(/([.!?。！？…]+[”"'’]?)(\s+)/g, '$1\n')
        .replace(/((?:습니다|습니까|입니다|입니까|했다|한다|된다|였다|었다|이다|다|요|죠|네|까|오|음|임|함|됨)[”"'’]?)(\s+)/g, '$1\n')
        .replace(/([”"])(\s+)(?=[가-힣A-Za-z0-9“"])/g, '$1\n');
      const parts = marked.split(/\n+/).map(v => v.trim()).filter(Boolean);
      if(parts.length > 1){ parts.forEach(add); return; }
      add(block);
    });
    return out;
  }
  function editorUnits(){
    if(!epubEditEditor) return [];
    const nodes = Array.from(epubEditEditor.childNodes).filter(node => {
      if(node.nodeType === Node.ELEMENT_NODE && node.classList && node.classList.contains('manual-chapter-separator')) return false;
      return (node.textContent || '').trim() || node.nodeType === Node.ELEMENT_NODE;
    });
    if(!nodes.length) return splitUnitsFromText(epubEditEditor.innerText || epubEditEditor.textContent || '');
    const out = [];
    nodes.forEach(node => {
      const html = node.outerHTML || esc(node.textContent || '');
      const text = plainFromHtml(html).replace(/\s+/g, ' ').trim();
      if(!text) return;
      if(text.length > 900) splitUnitsFromText(text).forEach(u => out.push(u));
      else out.push({text, body:text, html});
    });
    return out;
  }
  function units(){ return mode() === 'epubedit' ? editorUnits() : splitUnitsFromText(sourceText()); }
  function normalizePlan(plan, unitList, opts={}){
    if(!plan || !Array.isArray(plan.chapters)) plan = {chapters:[]};
    if(!plan.chapters.length) plan.chapters.push({id:'ch-' + Date.now().toString(36), title:titleFor(0), endPara:null, note:'', imageData:'', imageName:'', imageType:'', imagePos:'belowTitle'});
    const max = Math.max(0, unitList.length - 1);
    let prevEnd = -1;
    plan.chapters.forEach((ch, idx) => {
      if(!ch.id) ch.id = 'ch-' + idx + '-' + Date.now().toString(36);
      if(!ch.title) ch.title = titleFor(idx);
      if(ch.endPara === '' || ch.endPara === undefined || ch.endPara === null){ ch.endPara = null; return; }
      let end = Math.max(0, Math.min(max, Number(ch.endPara) || 0));
      if(end <= prevEnd){
        // 뒤 챕터가 앞 챕터 범위를 침범할 때만 뒤 챕터를 비웁니다. 앞 챕터 값은 절대 재설정하지 않습니다.
        ch.endPara = null;
        return;
      }
      ch.endPara = end;
      prevEnd = end;
    });
    const last = plan.chapters[plan.chapters.length - 1];
    if(unitList.length && last && last.endPara !== null && last.endPara !== undefined && Number(last.endPara) < max){
      plan.chapters.push({id:'ch-' + Date.now().toString(36) + '-auto', title:titleFor(plan.chapters.length), endPara:null, note:'', imageData:'', imageName:'', imageType:'', imagePos:'belowTitle'});
    }
    return plan;
  }
  function paraHtml(u){
    if(u && u.html) return u.html;
    const body = (u && (u.body || u.text)) || '';
    if(typeof paragraphToXhtml === 'function') return paragraphToXhtml(body);
    return '<p>' + esc(body).replace(/\n/g, '<br>') + '</p>';
  }
  function imageHtml(ch){ return ch && ch.imageData ? `<figure class="chapterImage"><img src="${esc(ch.imageData)}" alt="${esc(ch.imageName || ch.title || 'chapter image')}"></figure>` : ''; }
  function fullChapterHtml(ch, includeTitle){
    const note = ch.note ? `<p class="chapterNote">${esc(ch.note).replace(/\n/g,'<br>')}</p>` : '';
    const img = imageHtml(ch);
    return `${ch.imagePos === 'aboveTitle' ? img : ''}${includeTitle ? `<h1>${esc(ch.title || '')}</h1>` : ''}${note}${(!ch.imagePos || ch.imagePos === 'belowTitle') ? img : ''}${ch.bodyHtml || ''}${ch.imagePos === 'bottom' ? img : ''}`;
  }
  function chaptersFromPlan(markdownMode){
    const unitList = units();
    const got = getPlan();
    const plan = normalizePlan(got.plan, unitList);
    savePlan(plan);
    if(!unitList.length) return [];
    const chapters = [];
    let start = 0;
    plan.chapters.forEach((ch, idx) => {
      let end = ch.endPara;
      if(end === null || end === undefined) end = (idx === plan.chapters.length - 1) ? unitList.length - 1 : start - 1;
      end = Math.max(start - 1, Math.min(unitList.length - 1, Number(end)));
      const slice = end >= start ? unitList.slice(start, end + 1) : [];
      const body = slice.map(u => u.body || u.text || '').join('\n\n').trim();
      const bodyHtml = slice.map(paraHtml).join('\n');
      chapters.push({id:ch.id, title:ch.title || titleFor(idx), body, bodyHtml, note:ch.note || '', imageData:ch.imageData || '', imageName:ch.imageName || '', imageType:ch.imageType || '', imagePos:ch.imagePos || 'belowTitle', startIndex:start, endIndex:end});
      start = end + 1;
    });
    return chapters.filter((ch, idx) => ch.body || ch.bodyHtml || ch.note || ch.imageData || idx === 0);
  }
  function renderRows(){
    const box = qs('#manualChapterRows');
    if(!box) return;
    const unitList = units();
    const got = getPlan();
    const plan = normalizePlan(got.plan, unitList);
    savePlan(plan);
    let start = 0;
    box.innerHTML = plan.chapters.map((ch, idx) => {
      let end = ch.endPara;
      if(end === null || end === undefined) end = idx === plan.chapters.length - 1 ? unitList.length - 1 : start - 1;
      end = Math.max(start - 1, Math.min(unitList.length - 1, Number(end)));
      const range = end >= start ? `${start + 1}–${Math.min(end + 1, unitList.length)}` : '끝 지점 미설정';
      start = end + 1;
      return `<div class="manualChapterRow" data-id="${esc(ch.id)}"><b>${idx + 1}</b><span><strong>${esc(ch.title || titleFor(idx))}</strong><small>${range}${ch.note ? ' · 문구 있음' : ''}${ch.imageData ? ' · 이미지 있음' : ''}</small></span><button type="button" class="btn subtle" data-chapter-edit="${esc(ch.id)}">편집</button>${plan.chapters.length > 1 ? `<button type="button" class="btn subtle warn" data-chapter-delete="${esc(ch.id)}">삭제</button>` : ''}</div>`;
    }).join('');
  }
  function currentEditId(){
    const ed = qs('.manualChapterEditor');
    if(ed && ed.dataset.editingId) return ed.dataset.editingId;
    if(activeChapterId) return activeChapterId;
    const titleInput = qs('[data-chapter-title]');
    if(titleInput){
      const got = getPlan();
      const byId = got.plan.chapters.find(ch => ch.id === titleInput.dataset.chapterId);
      if(byId) return byId.id;
      const byTitle = got.plan.chapters.find(ch => ch.title === titleInput.value);
      if(byTitle) return byTitle.id;
    }
    return null;
  }
  function decorateEditor(id){
    const ed = qs('.manualChapterEditor');
    if(ed && id) ed.dataset.editingId = id;
    const titleInput = qs('[data-chapter-title]');
    if(titleInput && id) titleInput.dataset.chapterId = id;
  }
  function setEndForActive(endIndex){
    const unitList = units();
    const before = pointerSnapshot || getPlan().plan;
    const plan = JSON.parse(JSON.stringify(before));
    const id = currentEditId() || (plan.chapters[0] && plan.chapters[0].id);
    const ch = plan.chapters.find(c => c.id === id) || plan.chapters[0];
    if(!ch) return;
    ch.endPara = Math.max(0, Math.min(Math.max(0, unitList.length - 1), Number(endIndex) || 0));
    normalizePlan(plan, unitList);
    savePlan(plan);
    pointerSnapshot = null;
    renderRows();
    updatePreview();
    setTimeout(() => { renderRows(); updatePreview(); }, 30);
    if(typeof showToast === 'function') showToast('챕터 끝 지점을 설정했습니다.');
  }
  function searchMatches(){
    const unitList = units();
    const qInput = qs('[data-chapter-end-keyword]');
    const oInput = qs('[data-chapter-end-order]');
    const q = (qInput ? qInput.value : '').trim().toLowerCase();
    const order = (oInput ? oInput.value : '').trim();
    let list = unitList.map((u, idx) => ({...u, index:idx}));
    if(q) list = list.filter(u => String(u.text || '').toLowerCase().includes(q));
    if(order){
      const n = Number(order);
      if(Number.isFinite(n) && n > 0) list = q ? list.filter((_u, idx) => idx + 1 === n) : list.filter(u => u.index + 1 === n);
    }
    return list;
  }
  function previewText(item){
    const text = String((item && item.text) || '').replace(/\s+/g, ' ').trim();
    const q = (qs('[data-chapter-end-keyword]') || {}).value || '';
    if(!q || text.length <= 450) return text;
    const pos = text.toLowerCase().indexOf(q.toLowerCase());
    if(pos < 0) return text.slice(0, 450) + '…';
    const s = Math.max(0, pos - 160), e = Math.min(text.length, pos + q.length + 260);
    return `${s ? '…' : ''}${text.slice(s, e)}${e < text.length ? '…' : ''}`;
  }
  let localSearchPage = 0;
  function renderSearch(){
    const target = qs('#manualChapterSearchResults');
    if(!target) return;
    const matches = searchMatches();
    localSearchPage = Math.max(0, Math.min(localSearchPage, Math.max(0, matches.length - 1)));
    const cur = matches[localSearchPage];
    target.innerHTML = `<div class="miniToolHead"><div><strong>챕터 끝 지점</strong><span>검색한 문단을 이 챕터의 마지막 문단으로 설정합니다.</span></div><span>${matches.length ? `${localSearchPage + 1}/${matches.length}` : '0개'}</span></div>` +
      (cur ? `<div class="chapterMatchCard"><div class="dupeSummary withNav"><span><span class="pill">문단 ${cur.index + 1}</span></span><span class="navButtons"><button type="button" class="navIconBtn" data-final-chapter-page="prev" ${localSearchPage <= 0 ? 'disabled' : ''}>‹</button><button type="button" class="navIconBtn" data-final-chapter-page="next" ${localSearchPage >= matches.length - 1 ? 'disabled' : ''}>›</button></span></div><div class="previewText fullPreview chapterSearchPreview">${esc(previewText(cur))}</div><div class="chapterInsertRow"><button type="button" class="btn primary" data-final-chapter-set-end="${cur.index}">이 문단을 끝 지점으로 설정</button><button type="button" class="btn subtle" data-final-chapter-clear-end="1">끝 지점 비우기</button></div></div>` : '<div class="emptyState">검색 결과가 없습니다. 키워드나 번호를 바꿔 보세요.</div>');
  }
  function renderToc(chapters){
    if(!chapters || !chapters.length) return '<div class="emptyState">챕터가 아직 없습니다.</div>';
    return '<div class="chapterPreviewList">' + chapters.map((ch, idx) => {
      const text = String(ch.body || '').replace(/\s+/g, ' ').trim();
      const lead = text.slice(0, 80);
      const isOpen = openPreviewIndexes.has(idx);
      return `<details class="chapterPreviewItem" data-preview-idx="${idx}" ${isOpen ? 'open' : ''}><summary><b>${idx + 1}</b><span><strong>${esc(ch.title)}</strong>${lead ? `<small>${esc(lead)}</small>` : ''}</span><em>${Number(text.length || 0).toLocaleString('ko-KR')}자</em></summary><div class="bookPreview chapterPreviewBody">${fullChapterHtml(ch, false) || '<p class="mutedText">미리보기 없음</p>'}</div></details>`;
    }).join('') + '</div>';
  }
  function updatePreview(){
    const chapters = chaptersFromPlan(false);
    if(chapterPreviewEl) chapterPreviewEl.innerHTML = renderToc(chapters);
    const epubPrev = qs('#epubPreview');
    if(epubPrev){
      const first = chapters[0];
      epubPrev.innerHTML = `<div class="previewMeta"><b>미리보기</b><span>${chapters.length}개 챕터</span></div><div class="bookPreview">${first ? fullChapterHtml(first, true) : '<p class="mutedText">미리보기 없음</p>'}</div>`;
    }
  }
  window.getExportChapters = function(markdownMode){ return chaptersFromPlan(markdownMode); };
  if(typeof getExportChapters !== 'undefined') getExportChapters = window.getExportChapters;
  window.chapterBodyToXhtml = function(ch){ return fullChapterHtml(ch, false); };
  if(typeof chapterBodyToXhtml !== 'undefined') chapterBodyToXhtml = window.chapterBodyToXhtml;
  window.renderChapterTocHtml = function(chapters){ return renderToc(chapters); };
  if(typeof renderChapterTocHtml !== 'undefined') renderChapterTocHtml = window.renderChapterTocHtml;

  document.addEventListener('pointerdown', ev => {
    const set = ev.target.closest && (ev.target.closest('[data-final-chapter-set-end]') || ev.target.closest('[data-patch-chapter-set-end]') || ev.target.closest('[data-chapter-set-end]'));
    if(set) pointerSnapshot = JSON.parse(JSON.stringify(getPlan().plan));
  }, true);
  document.addEventListener('click', ev => {
    const edit = ev.target.closest && ev.target.closest('[data-chapter-edit]');
    if(edit){ activeChapterId = edit.dataset.chapterEdit; setTimeout(() => { decorateEditor(activeChapterId); renderSearch(); }, 20); }
    const nav = ev.target.closest && ev.target.closest('[data-final-chapter-page]');
    if(nav){
      const len = searchMatches().length;
      localSearchPage += nav.dataset.finalChapterPage === 'next' ? 1 : -1;
      localSearchPage = Math.max(0, Math.min(localSearchPage, Math.max(0, len - 1)));
      renderSearch(); ev.preventDefault(); ev.stopImmediatePropagation(); return;
    }
    const set = ev.target.closest && (ev.target.closest('[data-final-chapter-set-end]') || ev.target.closest('[data-patch-chapter-set-end]') || ev.target.closest('[data-chapter-set-end]'));
    if(set){ setEndForActive(set.dataset.finalChapterSetEnd || set.dataset.patchChapterSetEnd || set.dataset.chapterSetEnd); ev.preventDefault(); ev.stopImmediatePropagation(); return; }
    const clear = ev.target.closest && (ev.target.closest('[data-final-chapter-clear-end]') || ev.target.closest('[data-patch-chapter-clear-end]') || ev.target.closest('[data-chapter-clear-end]'));
    if(clear){ const got = getPlan(); const ch = got.plan.chapters.find(c => c.id === currentEditId()) || got.plan.chapters[0]; if(ch){ ch.endPara = null; normalizePlan(got.plan, units()); savePlan(got.plan); renderRows(); renderSearch(); updatePreview(); } ev.preventDefault(); ev.stopImmediatePropagation(); return; }
    const summary = ev.target.closest && ev.target.closest('#chapterPreview .chapterPreviewItem > summary');
    if(summary){
      const details = summary.parentElement;
      const idx = Number(details.dataset.previewIdx);
      setTimeout(() => {
        if(details.open) openPreviewIndexes.add(idx); else openPreviewIndexes.delete(idx);
        setTimeout(() => {
          const after = qs(`#chapterPreview .chapterPreviewItem[data-preview-idx="${idx}"]`);
          if(after) after.open = openPreviewIndexes.has(idx);
        }, 35);
      }, 0);
    }
  }, true);
  document.addEventListener('input', ev => {
    if(ev.target.matches && ev.target.matches('[data-chapter-title]')){
      const got = getPlan(); const id = currentEditId(); const ch = got.plan.chapters.find(c => c.id === id); if(ch){ ch.title = ev.target.value; savePlan(got.plan); renderRows(); updatePreview(); }
    }
    if(ev.target.matches && ev.target.matches('[data-chapter-end-keyword], [data-chapter-end-order]')){ localSearchPage = 0; setTimeout(renderSearch, 0); }
  }, true);
  function enforceBoardsOpen(){
    if(mode() === 'epubedit') return;
    qsa('#optionsBoard details.foldBlock, #reviewBoard details.foldBlock').forEach(d => { d.open = true; });
  }
  function boot(){
    renderRows(); renderSearch(); updatePreview(); enforceBoardsOpen();
    setTimeout(() => { renderRows(); renderSearch(); updatePreview(); enforceBoardsOpen(); }, 80);
  }
  qsa('.tab').forEach(tab => tab.addEventListener('click', () => setTimeout(boot, 30)));
  window.addEventListener('beforeunload', () => { const got = getPlan(); savePlan(got.plan); });
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();

/* --- 2026-06-07 chapter boundary isolation final patch --- */
(function(){
  const KEY = 'rofan-manual-chapters-v2';
  const OPEN_KEY = 'rofan-chapter-preview-open-v1';
  let activeId = null;
  let page = 0;

  function qs(sel, root=document){ return root.querySelector(sel); }
  function qsa(sel, root=document){ return Array.from(root.querySelectorAll(sel)); }
  function mode(){ return (typeof activeMode === 'string' && activeMode) ? activeMode : 'classic'; }
  function esc(v){
    if(typeof escapeHTML === 'function') return escapeHTML(v || '');
    return String(v || '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  }
  function attr(v){
    if(typeof escapeAttr === 'function') return escapeAttr(v || '');
    return esc(v).replace(/`/g, '&#096;');
  }
  function strip(v){
    if(typeof stripHTMLTags === 'function') return stripHTMLTags(v || '');
    const d = document.createElement('div');
    d.innerHTML = String(v || '');
    return d.textContent || d.innerText || '';
  }
  function htmlToText(html){
    if(typeof blockHtmlToText === 'function') return blockHtmlToText(html || '');
    const d = document.createElement('div');
    d.innerHTML = html || '';
    return (d.innerText || d.textContent || '').trim();
  }
  function titleFor(idx){ return idx === 0 ? 'Prologue' : 'Chapter ' + (idx + 1); }
  function uid(){ return 'ch-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2,7); }
  function defaultChapter(idx){ return {id:uid(), title:titleFor(idx), endPara:null, note:'', imageData:'', imageName:'', imageType:'', imagePos:'belowTitle'}; }

  function state(){
    try{ return JSON.parse(localStorage.getItem(KEY) || '{}') || {}; }
    catch(_){ return {}; }
  }
  function saveState(st){
    try{ localStorage.setItem(KEY, JSON.stringify(st || {})); }catch(_){ }
    if(typeof scheduleAutosave === 'function') scheduleAutosave();
  }
  function plan(){
    const st = state();
    const m = mode();
    if(!st[m]) st[m] = {chapters:[]};
    if(!Array.isArray(st[m].chapters)) st[m].chapters = [];
    if(!st[m].chapters.length) st[m].chapters.push(defaultChapter(0));
    st[m].chapters.forEach((ch, idx) => { if(!ch.id) ch.id = uid(); if(!ch.title) ch.title = titleFor(idx); });
    saveState(st);
    return st[m];
  }
  function savePlan(pl){ const st = state(); st[mode()] = pl; saveState(st); }

  function sourceText(){
    if(mode() === 'epubedit') return (typeof epubEditEditor !== 'undefined' && epubEditEditor) ? (epubEditEditor.innerText || epubEditEditor.textContent || '') : '';
    if(mode() === 'chat' && typeof chatOutput !== 'undefined' && chatOutput && chatOutput.value) return chatOutput.value;
    if(mode() === 'classic' && typeof output !== 'undefined' && output && output.value) return output.value;
    if(typeof getPreparedOutputForExport === 'function') return getPreparedOutputForExport() || '';
    return '';
  }
  function splitLong(piece){
    const text = String(piece || '').trim();
    if(!text) return [];
    if(strip(text).replace(/\s+/g,' ').trim().length <= 700) return [text];
    const out = [];
    let rest = text;
    while(strip(rest).replace(/\s+/g,' ').trim().length > 700){
      let cut = Math.max(
        rest.lastIndexOf('。', 680), rest.lastIndexOf('.', 680), rest.lastIndexOf('?', 680), rest.lastIndexOf('!', 680), rest.lastIndexOf('…', 680),
        rest.lastIndexOf('다 ', 680), rest.lastIndexOf('요 ', 680), rest.lastIndexOf('죠 ', 680), rest.lastIndexOf('네 ', 680), rest.lastIndexOf('까 ', 680)
      );
      if(cut < 220) cut = rest.lastIndexOf(' ', 680);
      if(cut < 220) cut = 680;
      const head = rest.slice(0, cut + 1).trim();
      if(head) out.push(head);
      rest = rest.slice(cut + 1).trim();
      if(!rest) break;
    }
    if(rest) out.push(rest);
    return out.filter(Boolean);
  }
  function splitUnitsFromText(txt){
    const raw = String(txt || '').replace(/\r/g,'').replace(/<!--\s*rofan:[\s\S]*?-->/gi,'').replace(/<hr[^>]*data-manual-chapter[^>]*>/gi,'\n\n').trim();
    if(!raw) return [];
    const units = [];
    const addPiece = (p) => {
      splitLong(p).forEach(x => {
        const t = strip(x).replace(/\s+/g,' ').trim();
        if(t) units.push({text:t, body:x});
      });
    };
    raw.split(/\n\s*\n+/).map(v=>v.trim()).filter(Boolean).forEach(block => {
      const lines = block.split(/\n+/).map(v=>v.trim()).filter(Boolean);
      if(lines.length > 1){ lines.forEach(addPiece); return; }
      const marked = block
        .replace(/([.!?。！？…]+[”"'’]?)(\s+)/g, '$1\n')
        .replace(/((?:습니다|습니까|입니다|입니까|했다|한다|된다|였다|었다|이다|다|요|죠|네|까|오|음|임|함|됨)[”"'’]?)(\s+)/g, '$1\n')
        .replace(/([”"])(\s+)(?=[가-힣A-Za-z0-9“"])/g, '$1\n');
      const parts = marked.split(/\n+/).map(v=>v.trim()).filter(Boolean);
      if(parts.length > 1){ parts.forEach(addPiece); return; }
      addPiece(block);
    });
    return units;
  }
  function editorUnits(){
    if(typeof epubEditEditor === 'undefined' || !epubEditEditor) return [];
    const nodes = Array.from(epubEditEditor.childNodes).filter(n => {
      if(n.nodeType === Node.ELEMENT_NODE && n.classList && n.classList.contains('manual-chapter-separator')) return false;
      return (n.textContent || '').trim() || n.nodeType === Node.ELEMENT_NODE;
    });
    if(!nodes.length) return splitUnitsFromText(epubEditEditor.innerText || epubEditEditor.textContent || '');
    const out = [];
    nodes.forEach(node => {
      const html = node.outerHTML || esc(node.textContent || '');
      const text = htmlToText(html).replace(/\s+/g,' ').trim();
      if(!text) return;
      if(text.length > 900) splitUnitsFromText(text).forEach(u => out.push(u));
      else out.push({text, body:text, html});
    });
    return out;
  }
  function units(){ return mode() === 'epubedit' ? editorUnits() : splitUnitsFromText(sourceText()); }

  function sanitizePlan(pl, unitList){
    if(!pl || !Array.isArray(pl.chapters)) pl = {chapters:[]};
    if(!pl.chapters.length) pl.chapters.push(defaultChapter(0));
    const max = Math.max(0, unitList.length - 1);
    pl.chapters.forEach((ch, idx) => {
      if(!ch.id) ch.id = uid();
      if(!ch.title) ch.title = titleFor(idx);
      if(ch.endPara === '' || ch.endPara === undefined || ch.endPara === null){ ch.endPara = null; return; }
      ch.endPara = Math.max(0, Math.min(max, Number(ch.endPara) || 0));
    });
    return pl;
  }
  function fixLaterChapters(pl, editedIdx, unitList){
    const editedEnd = Number(pl.chapters[editedIdx].endPara);
    for(let i = editedIdx + 1; i < pl.chapters.length; i++){
      const val = pl.chapters[i].endPara;
      if(val !== null && val !== undefined && val !== '' && Number(val) <= editedEnd){
        pl.chapters[i].endPara = null;
      }
    }
    const max = Math.max(0, unitList.length - 1);
    const last = pl.chapters[pl.chapters.length - 1];
    if(unitList.length && last && last.endPara !== null && last.endPara !== undefined && Number(last.endPara) < max){
      pl.chapters.push(defaultChapter(pl.chapters.length));
    }
  }
  function chapterRanges(pl, unitList){
    pl = sanitizePlan(pl, unitList);
    const ranges = [];
    let start = 0;
    pl.chapters.forEach((ch, idx) => {
      let end = ch.endPara;
      if(end === null || end === undefined || end === '') end = (idx === pl.chapters.length - 1) ? unitList.length - 1 : start - 1;
      end = Math.max(start - 1, Math.min(unitList.length - 1, Number(end)));
      ranges.push({start, end});
      start = end + 1;
    });
    return ranges;
  }
  function paraHtml(u){
    if(u && u.html) return u.html;
    const body = (u && (u.body || u.text)) || '';
    if(typeof paragraphToXhtml === 'function') return paragraphToXhtml(body);
    return '<p>' + esc(body).replace(/\n/g,'<br>') + '</p>';
  }
  function imageHtml(ch){ return ch && ch.imageData ? `<figure class="chapterImage"><img src="${attr(ch.imageData)}" alt="${attr(ch.imageName || ch.title || 'chapter image')}"></figure>` : ''; }
  function fullHtml(ch, includeTitle){
    const note = ch.note ? `<p class="chapterNote">${esc(ch.note).replace(/\n/g,'<br>')}</p>` : '';
    const img = imageHtml(ch);
    return `${ch.imagePos === 'aboveTitle' ? img : ''}${includeTitle ? `<h1>${esc(ch.title || '')}</h1>` : ''}${note}${(!ch.imagePos || ch.imagePos === 'belowTitle') ? img : ''}${ch.bodyHtml || ''}${ch.imagePos === 'bottom' ? img : ''}`;
  }
  function chaptersFromPlan(){
    const unitList = units();
    const pl = sanitizePlan(plan(), unitList);
    const ranges = chapterRanges(pl, unitList);
    const chs = pl.chapters.map((ch, idx) => {
      const r = ranges[idx] || {start:0,end:-1};
      const slice = r.end >= r.start ? unitList.slice(r.start, r.end + 1) : [];
      return Object.assign({}, ch, {
        title: ch.title || titleFor(idx),
        body: slice.map(u => u.body || u.text || '').join('\n\n').trim(),
        bodyHtml: slice.map(paraHtml).join('\n'),
        startIndex: r.start,
        endIndex: r.end
      });
    });
    return chs.filter((ch, idx) => ch.body || ch.bodyHtml || ch.note || ch.imageData || idx === 0);
  }

  function getActiveId(){
    const ed = qs('.manualChapterEditor[data-editing-id]');
    if(ed && ed.dataset.editingId) return ed.dataset.editingId;
    const inp = qs('[data-chapter-title][data-chapter-id]');
    if(inp && inp.dataset.chapterId) return inp.dataset.chapterId;
    if(activeId) return activeId;
    const edit = qs('[data-chapter-edit]');
    return edit ? edit.dataset.chapterEdit : null;
  }
  function decorateEditor(id){
    if(!id) return;
    activeId = id;
    const ed = qs('.manualChapterEditor');
    if(ed) ed.dataset.editingId = id;
    const title = qs('[data-chapter-title]');
    if(title) title.dataset.chapterId = id;
  }

  function renderRows(){
    const box = qs('#manualChapterRows');
    if(!box) return;
    const unitList = units();
    const pl = sanitizePlan(plan(), unitList);
    savePlan(pl);
    const ranges = chapterRanges(pl, unitList);
    box.innerHTML = pl.chapters.map((ch, idx) => {
      const r = ranges[idx] || {start:0,end:-1};
      const range = r.end >= r.start ? `${r.start + 1}–${Math.min(r.end + 1, unitList.length)}` : '끝 지점 미설정';
      return `<div class="manualChapterRow" data-id="${attr(ch.id)}"><b>${idx + 1}</b><span><strong>${esc(ch.title || titleFor(idx))}</strong><small>${range}${ch.note ? ' · 문구 있음' : ''}${ch.imageData ? ' · 이미지 있음' : ''}</small></span><button type="button" class="btn subtle" data-chapter-edit="${attr(ch.id)}">편집</button>${pl.chapters.length > 1 ? `<button type="button" class="btn subtle warn" data-chapter-delete="${attr(ch.id)}">삭제</button>` : ''}</div>`;
    }).join('');
  }
  function searchMatches(){
    const unitList = units();
    const q = (qs('[data-chapter-end-keyword]') || {}).value || '';
    const order = (qs('[data-chapter-end-order]') || {}).value || '';
    let list = unitList.map((u, idx) => Object.assign({}, u, {index:idx}));
    const query = String(q).trim().toLowerCase();
    if(query) list = list.filter(u => String(u.text || '').toLowerCase().includes(query));
    const n = Number(String(order).trim());
    if(Number.isFinite(n) && n > 0) list = query ? list.filter((_u, idx) => idx + 1 === n) : list.filter(u => u.index + 1 === n);
    return list;
  }
  function previewText(item){
    const t = String((item && item.text) || '').replace(/\s+/g,' ').trim();
    const q = ((qs('[data-chapter-end-keyword]') || {}).value || '').trim().toLowerCase();
    if(!q || t.length <= 450) return t;
    const pos = t.toLowerCase().indexOf(q);
    if(pos < 0) return t.slice(0,450) + '…';
    const s = Math.max(0, pos - 160), e = Math.min(t.length, pos + q.length + 260);
    return `${s ? '…' : ''}${t.slice(s,e)}${e < t.length ? '…' : ''}`;
  }
  function renderSearch(){
    const target = qs('#manualChapterSearchResults');
    if(!target) return;
    const matches = searchMatches();
    page = Math.max(0, Math.min(page, Math.max(0, matches.length - 1)));
    const cur = matches[page];
    target.innerHTML = `<div class="miniToolHead"><div><strong>챕터 끝 지점</strong><span>검색한 문단을 이 챕터의 마지막 문단으로 설정합니다.</span></div><span>${matches.length ? `${page + 1}/${matches.length}` : '0개'}</span></div>` +
      (cur ? `<div class="chapterMatchCard"><div class="dupeSummary withNav"><span><span class="pill">문단 ${cur.index + 1}</span></span><span class="navButtons"><button type="button" class="navIconBtn" data-stable-chapter-page="prev" ${page <= 0 ? 'disabled' : ''}>‹</button><button type="button" class="navIconBtn" data-stable-chapter-page="next" ${page >= matches.length - 1 ? 'disabled' : ''}>›</button></span></div><div class="previewText fullPreview chapterSearchPreview">${esc(previewText(cur))}</div><div class="chapterInsertRow"><button type="button" class="btn primary" data-stable-chapter-set-end="${cur.index}">이 문단을 끝 지점으로 설정</button><button type="button" class="btn subtle" data-stable-chapter-clear-end="1">끝 지점 비우기</button></div></div>` : '<div class="emptyState">검색 결과가 없습니다. 키워드나 번호를 바꿔 보세요.</div>');
  }
  function openIndexes(){ try{ return new Set(JSON.parse(localStorage.getItem(OPEN_KEY) || '[]')); }catch(_){ return new Set(); } }
  function saveOpenIndexes(set){ try{ localStorage.setItem(OPEN_KEY, JSON.stringify(Array.from(set))); }catch(_){} }
  function renderToc(chs, compact){
    if(!chs || !chs.length) return '<div class="emptyState">챕터가 아직 없습니다.</div>';
    if(compact){
      return `<div class="chapterTocBox"><div class="tocSummary"><strong>현재 목차</strong><span>${chs.length}개 챕터</span></div>${chs.map((ch, idx)=>{ const text = String(ch.body || htmlToText(ch.bodyHtml || '')).replace(/\s+/g,' ').trim(); return `<div class="chapterTocRow"><b>${idx+1}</b><span><strong>${esc(ch.title)}</strong><small>${esc(text.slice(0,70))}</small></span><em>${Number(text.length).toLocaleString('ko-KR')}자</em></div>`; }).join('')}</div>`;
    }
    const opens = openIndexes();
    return `<div class="chapterPreviewList">${chs.map((ch, idx)=>{ const text = String(ch.body || htmlToText(ch.bodyHtml || '')).replace(/\s+/g,' ').trim(); return `<details class="chapterPreviewItem" data-preview-idx="${idx}" ${opens.has(idx) ? 'open' : ''}><summary><b>${idx+1}</b><span><strong>${esc(ch.title)}</strong>${text ? `<small>${esc(text.slice(0,120))}</small>` : ''}</span><em>${Number(text.length).toLocaleString('ko-KR')}자</em></summary><div class="bookPreview chapterPreviewBody">${fullHtml(ch,false) || '<p class="mutedText">미리보기 없음</p>'}</div></details>`; }).join('')}</div>`;
  }
  function updatePreview(){
    const chs = chaptersFromPlan();
    if(typeof chapterPreviewEl !== 'undefined' && chapterPreviewEl) chapterPreviewEl.innerHTML = renderToc(chs, false);
    const epubPrev = qs('#epubPreview');
    if(epubPrev){ const first = chs[0]; epubPrev.innerHTML = `<div class="previewMeta"><b>미리보기</b><span>${chs.length}개 챕터</span></div><div class="bookPreview">${first ? fullHtml(first,true) : '<p class="mutedText">미리보기 없음</p>'}</div>`; }
  }
  function refresh(){ renderRows(); renderSearch(); updatePreview(); }

  window.getExportChapters = function(){ return chaptersFromPlan(); };
  if(typeof getExportChapters !== 'undefined') getExportChapters = window.getExportChapters;
  window.chapterBodyToXhtml = function(ch){ return fullHtml(ch, false); };
  if(typeof chapterBodyToXhtml !== 'undefined') chapterBodyToXhtml = window.chapterBodyToXhtml;
  window.renderChapterTocHtml = function(chs, compact){ return renderToc(chs, compact); };
  if(typeof renderChapterTocHtml !== 'undefined') renderChapterTocHtml = window.renderChapterTocHtml;
  const prevUpdate = window.updateEpubPreview;
  window.updateEpubPreview = function(){ try{ if(typeof prevUpdate === 'function') prevUpdate(); }catch(_){} refresh(); };
  if(typeof updateEpubPreview !== 'undefined') updateEpubPreview = window.updateEpubPreview;

  window.addEventListener('click', function(ev){
    const summary = ev.target.closest && ev.target.closest('#chapterPreview .chapterPreviewItem > summary');
    if(summary){
      ev.preventDefault(); ev.stopImmediatePropagation();
      const d = summary.parentElement;
      const idx = Number(d.dataset.previewIdx);
      d.open = !d.open;
      const set = openIndexes();
      if(d.open) set.add(idx); else set.delete(idx);
      saveOpenIndexes(set);
      return;
    }
    const edit = ev.target.closest && ev.target.closest('[data-chapter-edit]');
    if(edit){ activeId = edit.dataset.chapterEdit; setTimeout(()=>{ decorateEditor(activeId); page = 0; renderSearch(); }, 20); return; }
    const nav = ev.target.closest && ev.target.closest('[data-stable-chapter-page], [data-final-chapter-page], [data-patch-chapter-page], [data-manual-chapter-page]');
    if(nav){
      ev.preventDefault(); ev.stopImmediatePropagation();
      const len = searchMatches().length;
      const v = nav.dataset.stableChapterPage || nav.dataset.finalChapterPage || nav.dataset.patchChapterPage || nav.dataset.manualChapterPage;
      page += v === 'next' ? 1 : -1;
      page = Math.max(0, Math.min(page, Math.max(0, len - 1)));
      renderSearch(); return;
    }
    const setBtn = ev.target.closest && ev.target.closest('[data-stable-chapter-set-end], [data-final-chapter-set-end], [data-patch-chapter-set-end], [data-chapter-set-end]');
    if(setBtn){
      ev.preventDefault(); ev.stopImmediatePropagation();
      const end = Number(setBtn.dataset.stableChapterSetEnd || setBtn.dataset.finalChapterSetEnd || setBtn.dataset.patchChapterSetEnd || setBtn.dataset.chapterSetEnd);
      const unitList = units();
      const pl = sanitizePlan(plan(), unitList);
      const id = getActiveId() || (pl.chapters[0] && pl.chapters[0].id);
      const idx = Math.max(0, pl.chapters.findIndex(ch => ch.id === id));
      pl.chapters[idx].endPara = Math.max(0, Math.min(Math.max(0, unitList.length - 1), end || 0));
      fixLaterChapters(pl, idx, unitList);
      savePlan(pl);
      activeId = pl.chapters[idx].id;
      if(typeof showToast === 'function') showToast('챕터 끝 지점을 설정했습니다.');
      refresh();
      setTimeout(()=>{ decorateEditor(activeId); renderSearch(); refresh(); }, 40);
      return;
    }
    const clearBtn = ev.target.closest && ev.target.closest('[data-stable-chapter-clear-end], [data-final-chapter-clear-end], [data-patch-chapter-clear-end], [data-chapter-clear-end]');
    if(clearBtn){
      ev.preventDefault(); ev.stopImmediatePropagation();
      const unitList = units();
      const pl = sanitizePlan(plan(), unitList);
      const id = getActiveId() || (pl.chapters[0] && pl.chapters[0].id);
      const ch = pl.chapters.find(c => c.id === id);
      if(ch) ch.endPara = null;
      savePlan(pl); refresh(); setTimeout(()=>decorateEditor(id), 30); return;
    }
    const add = ev.target.closest && ev.target.closest('[data-chapter-add]');
    if(add){
      ev.preventDefault(); ev.stopImmediatePropagation();
      const unitList = units();
      const pl = sanitizePlan(plan(), unitList);
      pl.chapters.push(defaultChapter(pl.chapters.length));
      savePlan(pl); activeId = pl.chapters[pl.chapters.length-1].id; refresh();
      setTimeout(()=>{ const btn = qs(`[data-chapter-edit="${CSS.escape(activeId)}"]`); if(btn) btn.click(); }, 40);
      return;
    }
  }, true);

  document.addEventListener('input', function(ev){
    if(ev.target.matches && ev.target.matches('[data-chapter-title]')){
      const pl = plan(); const id = getActiveId(); const ch = pl.chapters.find(c => c.id === id); if(ch){ ch.title = ev.target.value; savePlan(pl); renderRows(); updatePreview(); }
    }
    if(ev.target.matches && ev.target.matches('[data-chapter-end-keyword], [data-chapter-end-order]')){ page = 0; setTimeout(renderSearch,0); }
  }, true);

  function enforceBoards(){
    if(mode() === 'epubedit') return;
    qsa('#optionsBoard details.foldBlock, #reviewBoard details.foldBlock').forEach(d => d.open = true);
  }
  function boot(){ refresh(); enforceBoards(); setTimeout(()=>{ refresh(); enforceBoards(); }, 120); }
  qsa('.tab').forEach(tab => tab.addEventListener('click', () => setTimeout(boot, 60)));
  window.addEventListener('beforeunload', () => savePlan(plan()));
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();

/* --- 2026-06-07 final chapter unit + preview readability patch --- */
(function(){
  const KEY = 'rofan-manual-chapters-v2';
  const OPEN_KEY = 'rofan-chapter-preview-open-v2';
  let page = 0;
  let activeId = null;

  function qs(sel, root=document){ return root.querySelector(sel); }
  function qsa(sel, root=document){ return Array.from(root.querySelectorAll(sel)); }
  function mode(){ return (typeof activeMode === 'string' && activeMode) ? activeMode : 'classic'; }
  function esc(v){
    if(typeof escapeHTML === 'function') return escapeHTML(v || '');
    return String(v || '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  }
  function attr(v){
    if(typeof escapeAttr === 'function') return escapeAttr(v || '');
    return esc(v).replace(/`/g, '&#096;');
  }
  function plainFromHtml(html){
    if(typeof blockHtmlToText === 'function') return blockHtmlToText(html || '');
    const d = document.createElement('div');
    d.innerHTML = html || '';
    return (d.innerText || d.textContent || '').trim();
  }
  function stripHtml(v){
    if(typeof stripHTMLTags === 'function') return stripHTMLTags(v || '');
    const d = document.createElement('div');
    d.innerHTML = String(v || '');
    return d.textContent || d.innerText || '';
  }
  function titleFor(idx){ return idx === 0 ? 'Prologue' : 'Chapter ' + (idx + 1); }
  function uid(){ return 'ch-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2,7); }
  function defaultChapter(idx){ return {id:uid(), title:titleFor(idx), endPara:null, note:'', imageData:'', imageName:'', imageType:'', imagePos:'belowTitle'}; }
  function normalizeText(v){ return String(v || '').replace(/\r/g, '').trim(); }
  function fileNameForMode(){
    try{
      if(mode() === 'epubedit') return String((typeof cachedEpubEditFileName !== 'undefined' && cachedEpubEditFileName) || (qs('#epubEditFileName') && qs('#epubEditFileName').textContent) || '');
      if(mode() === 'chat') return String((typeof cachedChatFileName !== 'undefined' && cachedChatFileName) || (qs('#chatFileName') && qs('#chatFileName').textContent) || '');
      return String((qs('#classicFileName') && qs('#classicFileName').textContent) || '');
    }catch(_){ return ''; }
  }
  function isTxtSource(){ return /\.txt$/i.test(fileNameForMode()); }
  function isStructuredFileHint(){ return /\.(md|markdown|html|htm|mht|mhtml)$/i.test(fileNameForMode()); }

  function state(){
    try{ return JSON.parse(localStorage.getItem(KEY) || '{}') || {}; }
    catch(_){ return {}; }
  }
  function saveState(st){
    try{ localStorage.setItem(KEY, JSON.stringify(st || {})); }catch(_){ }
    if(typeof scheduleAutosave === 'function') scheduleAutosave();
  }
  function plan(){
    const st = state();
    const m = mode();
    if(!st[m]) st[m] = {chapters:[]};
    if(!Array.isArray(st[m].chapters)) st[m].chapters = [];
    if(!st[m].chapters.length) st[m].chapters.push(defaultChapter(0));
    st[m].chapters.forEach((ch, idx) => { if(!ch.id) ch.id = uid(); if(!ch.title) ch.title = titleFor(idx); });
    saveState(st);
    return st[m];
  }
  function savePlan(pl){ const st = state(); st[mode()] = pl; saveState(st); }

  function htmlParagraphsFromText(text){
    const src = String(text || '').replace(/\r/g, '').trim();
    if(!src) return '';
    const lines = src.split(/\n+/).map(v => v.trim()).filter(Boolean);
    if(!lines.length) return '';
    return lines.map(line => {
      if(typeof paragraphToXhtml === 'function') return paragraphToXhtml(line);
      return '<p>' + esc(line) + '</p>';
    }).join('\n');
  }
  function unitFromText(body, extra){
    const clean = stripHtml(body).replace(/\s+/g, ' ').trim();
    if(!clean) return null;
    return Object.assign({ text: clean, body: String(body || '').trim(), bodyHtml: htmlParagraphsFromText(body) }, extra || {});
  }
  function lineUnitsFromText(text){
    return String(text || '').replace(/\r/g, '').split(/\n+/).map(v => v.trim()).filter(Boolean).map(line => unitFromText(line)).filter(Boolean);
  }
  function topParagraphUnits(text){
    const raw = normalizeText(text).replace(/<!--\s*rofan:[\s\S]*?-->/gi, '').replace(/<hr[^>]*data-manual-chapter[^>]*>/gi, '\n');
    if(!raw) return [];
    const pieces = raw.split(/\n\s*\n+/).map(v => v.trim()).filter(Boolean);
    if(pieces.length) return pieces.map(p => unitFromText(p)).filter(Boolean);
    return lineUnitsFromText(raw);
  }
  function mergeItemsByBlock(items){
    const map = new Map();
    const order = [];
    (items || []).forEach((item, idx) => {
      if(!item || !String(item.text || '').trim()) return;
      const blockId = item.blockId || item.block || ('block-' + idx);
      if(!map.has(blockId)){
        map.set(blockId, { blockId, owner:item.owner || 'character', kind:item.kind || 'normal', parts:[] });
        order.push(blockId);
      }
      const entry = map.get(blockId);
      entry.parts.push(String(item.text || '').trim());
      if(!entry.owner && item.owner) entry.owner = item.owner;
      if(!entry.kind && item.kind) entry.kind = item.kind;
    });
    return order.map(id => {
      const entry = map.get(id);
      const body = entry.parts.join('\n').trim();
      if(!body) return null;
      let html = '';
      if(typeof structuredItemsToHtml === 'function'){
        try{ html = structuredItemsToHtml([{blockId:entry.blockId, owner:entry.owner || 'character', kind:entry.kind || 'normal', text:body}]); }catch(_){ html = ''; }
      }
      return unitFromText(body, { html: html || `<div class="rofan-block" data-block-id="${attr(entry.blockId)}" data-owner="${attr(entry.owner || 'character')}" data-kind="${attr(entry.kind || 'normal')}">${htmlParagraphsFromText(body)}</div>` });
    }).filter(Boolean);
  }
  function structuredUnitsFromCurrentOutput(){
    if(isTxtSource()) return [];
    if(typeof lastStructuredItems !== 'undefined' && Array.isArray(lastStructuredItems) && lastStructuredItems.length){
      const units = mergeItemsByBlock(lastStructuredItems);
      if(units.length) return units;
    }
    return [];
  }
  function sourceText(){
    if(mode() === 'epubedit') return (typeof epubEditEditor !== 'undefined' && epubEditEditor) ? (epubEditEditor.innerText || epubEditEditor.textContent || '') : '';
    if(mode() === 'chat' && typeof chatOutput !== 'undefined' && chatOutput && chatOutput.value) return chatOutput.value;
    if(mode() === 'classic' && typeof output !== 'undefined' && output && output.value) return output.value;
    if(typeof getPreparedOutputForExport === 'function') return getPreparedOutputForExport() || '';
    return '';
  }
  function cleanEditorNodeList(){
    if(typeof epubEditEditor === 'undefined' || !epubEditEditor) return [];
    return Array.from(epubEditEditor.childNodes).filter(node => {
      if(node.nodeType === Node.ELEMENT_NODE && node.classList && node.classList.contains('manual-chapter-separator')) return false;
      return (node.textContent || '').trim() || node.nodeType === Node.ELEMENT_NODE;
    });
  }
  function unitsFromRofanBlocksInEditor(){
    if(typeof epubEditEditor === 'undefined' || !epubEditEditor) return [];
    const blocks = Array.from(epubEditEditor.querySelectorAll('.rofan-block,[data-owner][data-kind]')).filter(el => !el.closest('.manual-chapter-separator'));
    if(!blocks.length) return [];
    return blocks.map((el, idx) => {
      const html = el.outerHTML || '';
      const text = (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
      if(!text) return null;
      return { text, body:(el.innerText || el.textContent || '').trim(), bodyHtml:html, html, blockId: el.getAttribute('data-block-id') || ('editor-block-' + idx) };
    }).filter(Boolean);
  }
  function editorUnits(){
    if(typeof epubEditEditor === 'undefined' || !epubEditEditor) return [];
    if(isTxtSource()) return lineUnitsFromText(epubEditEditor.innerText || epubEditEditor.textContent || '');
    const structured = unitsFromRofanBlocksInEditor();
    if(structured.length) return structured;
    const nodes = cleanEditorNodeList();
    if(!nodes.length) return topParagraphUnits(epubEditEditor.innerText || epubEditEditor.textContent || '');
    const units = [];
    nodes.forEach((node, idx) => {
      const html = node.outerHTML || '';
      const text = (node.innerText || node.textContent || '').trim();
      if(!text && !html) return;
      if(node.nodeType === Node.ELEMENT_NODE){
        const tag = node.tagName ? node.tagName.toLowerCase() : '';
        if(tag === 'p' && /<br\s*\/?\s*>/i.test(html) && /\.txt$/i.test(fileNameForMode())){
          lineUnitsFromText(text).forEach(u => units.push(u));
        }else{
          const plain = plainFromHtml(html).replace(/\s+/g, ' ').trim();
          if(plain) units.push({ text:plain, body:text, bodyHtml:html, html });
        }
      }else{
        lineUnitsFromText(text).forEach(u => units.push(u));
      }
    });
    return units.length ? units : topParagraphUnits(epubEditEditor.innerText || epubEditEditor.textContent || '');
  }
  function chapterUnits(){
    if(mode() === 'epubedit') return editorUnits();
    const structured = structuredUnitsFromCurrentOutput();
    if(structured.length) return structured;
    if(isStructuredFileHint() && typeof lastStructuredItems !== 'undefined' && Array.isArray(lastStructuredItems) && lastStructuredItems.length){
      const units = mergeItemsByBlock(lastStructuredItems);
      if(units.length) return units;
    }
    return lineUnitsFromText(sourceText());
  }

  function sanitizePlan(pl, unitList){
    if(!pl || !Array.isArray(pl.chapters)) pl = {chapters:[]};
    if(!pl.chapters.length) pl.chapters.push(defaultChapter(0));
    const max = Math.max(0, unitList.length - 1);
    pl.chapters.forEach((ch, idx) => {
      if(!ch.id) ch.id = uid();
      if(!ch.title) ch.title = titleFor(idx);
      if(ch.endPara === '' || ch.endPara === undefined || ch.endPara === null){ ch.endPara = null; return; }
      ch.endPara = Math.max(0, Math.min(max, Number(ch.endPara) || 0));
    });
    return pl;
  }
  function ensureTrailingChapter(pl, unitList){
    if(!unitList.length || !pl.chapters.length) return;
    const max = unitList.length - 1;
    const last = pl.chapters[pl.chapters.length - 1];
    if(last && last.endPara !== null && last.endPara !== undefined && last.endPara !== '' && Number(last.endPara) < max){
      pl.chapters.push(defaultChapter(pl.chapters.length));
    }
  }
  function chapterRanges(pl, unitList){
    pl = sanitizePlan(pl, unitList);
    const ranges = [];
    let start = 0;
    pl.chapters.forEach((ch, idx) => {
      let end = ch.endPara;
      if(end === null || end === undefined || end === '') end = (idx === pl.chapters.length - 1) ? unitList.length - 1 : start - 1;
      end = Math.max(start - 1, Math.min(unitList.length - 1, Number(end)));
      ranges.push({start, end});
      start = end + 1;
    });
    return ranges;
  }
  function unitHtml(u){ return (u && (u.bodyHtml || u.html)) || htmlParagraphsFromText((u && (u.body || u.text)) || ''); }
  function imageHtml(ch){ return ch && ch.imageData ? `<figure class="chapterImage"><img src="${attr(ch.imageData)}" alt="${attr(ch.imageName || ch.title || 'chapter image')}"></figure>` : ''; }
  function fullHtml(ch, includeTitle){
    const note = ch.note ? `<p class="chapterNote">${esc(ch.note).replace(/\n/g,'<br>')}</p>` : '';
    const img = imageHtml(ch);
    return `${ch.imagePos === 'aboveTitle' ? img : ''}${includeTitle ? `<h1>${esc(ch.title || '')}</h1>` : ''}${note}${(!ch.imagePos || ch.imagePos === 'belowTitle') ? img : ''}${ch.bodyHtml || ''}${ch.imagePos === 'bottom' ? img : ''}`;
  }
  function chaptersFromPlan(){
    const unitList = chapterUnits();
    const pl = sanitizePlan(plan(), unitList);
    ensureTrailingChapter(pl, unitList);
    savePlan(pl);
    const ranges = chapterRanges(pl, unitList);
    const chs = pl.chapters.map((ch, idx) => {
      const r = ranges[idx] || {start:0,end:-1};
      const slice = r.end >= r.start ? unitList.slice(r.start, r.end + 1) : [];
      const body = slice.map(u => u.body || u.text || '').join('\n\n').trim();
      const bodyHtml = slice.map(unitHtml).join('\n');
      return Object.assign({}, ch, { title: ch.title || titleFor(idx), body, bodyHtml, startIndex:r.start, endIndex:r.end });
    });
    return chs.filter((ch, idx) => ch.body || ch.bodyHtml || ch.note || ch.imageData || idx === 0);
  }
  function activeEditorId(){
    const ed = qs('.manualChapterEditor[data-editing-id]');
    if(ed && ed.dataset.editingId) return ed.dataset.editingId;
    const title = qs('[data-chapter-title][data-chapter-id]');
    if(title && title.dataset.chapterId) return title.dataset.chapterId;
    if(activeId) return activeId;
    const first = qs('[data-chapter-edit]');
    return first ? first.dataset.chapterEdit : null;
  }
  function decorateEditor(id){
    if(!id) return;
    activeId = id;
    const ed = qs('.manualChapterEditor');
    if(ed) ed.dataset.editingId = id;
    const title = qs('[data-chapter-title]');
    if(title) title.dataset.chapterId = id;
  }
  function renderRows(){
    const box = qs('#manualChapterRows');
    if(!box) return;
    const unitList = chapterUnits();
    const pl = sanitizePlan(plan(), unitList);
    ensureTrailingChapter(pl, unitList);
    savePlan(pl);
    const ranges = chapterRanges(pl, unitList);
    box.innerHTML = pl.chapters.map((ch, idx) => {
      const r = ranges[idx] || {start:0,end:-1};
      const range = r.end >= r.start ? `${r.start + 1}–${Math.min(r.end + 1, unitList.length)}` : '끝 지점 미설정';
      return `<div class="manualChapterRow" data-id="${attr(ch.id)}"><b>${idx + 1}</b><span><strong>${esc(ch.title || titleFor(idx))}</strong><small>${range}${ch.note ? ' · 문구 있음' : ''}${ch.imageData ? ' · 이미지 있음' : ''}</small></span><button type="button" class="btn subtle" data-chapter-edit="${attr(ch.id)}">편집</button>${pl.chapters.length > 1 ? `<button type="button" class="btn subtle warn" data-chapter-delete="${attr(ch.id)}">삭제</button>` : ''}</div>`;
    }).join('');
  }
  function searchMatches(){
    const unitList = chapterUnits();
    const q = (qs('[data-chapter-end-keyword]') || {}).value || '';
    const order = (qs('[data-chapter-end-order]') || {}).value || '';
    let list = unitList.map((u, idx) => Object.assign({}, u, {index:idx}));
    const query = String(q).trim().toLowerCase();
    if(query) list = list.filter(u => String(u.text || '').toLowerCase().includes(query));
    const n = Number(String(order).trim());
    if(Number.isFinite(n) && n > 0) list = query ? list.filter((_u, idx) => idx + 1 === n) : list.filter(u => u.index + 1 === n);
    return list;
  }
  function matchPreview(item){
    const text = String((item && item.text) || '').replace(/\s+/g,' ').trim();
    const q = ((qs('[data-chapter-end-keyword]') || {}).value || '').trim().toLowerCase();
    if(!q || text.length <= 520) return text;
    const pos = text.toLowerCase().indexOf(q);
    if(pos < 0) return text.slice(0,520) + '…';
    const s = Math.max(0, pos - 180), e = Math.min(text.length, pos + q.length + 320);
    return `${s ? '…' : ''}${text.slice(s,e)}${e < text.length ? '…' : ''}`;
  }
  function renderSearch(){
    const target = qs('#manualChapterSearchResults');
    if(!target) return;
    const matches = searchMatches();
    page = Math.max(0, Math.min(page, Math.max(0, matches.length - 1)));
    const cur = matches[page];
    target.innerHTML = `<div class="miniToolHead"><div><strong>챕터 끝 지점</strong><span>검색한 단위를 이 챕터의 마지막 단위로 설정합니다.</span></div><span>${matches.length ? `${page + 1}/${matches.length}` : '0개'}</span></div>` +
      (cur ? `<div class="chapterMatchCard"><div class="dupeSummary withNav"><span><span class="pill">단위 ${cur.index + 1}</span></span><span class="navButtons"><button type="button" class="navIconBtn" data-unitfix-chapter-page="prev" ${page <= 0 ? 'disabled' : ''}>‹</button><button type="button" class="navIconBtn" data-unitfix-chapter-page="next" ${page >= matches.length - 1 ? 'disabled' : ''}>›</button></span></div><div class="previewText fullPreview chapterSearchPreview">${esc(matchPreview(cur))}</div><div class="chapterInsertRow"><button type="button" class="btn primary" data-unitfix-chapter-set-end="${cur.index}">이 단위를 끝 지점으로 설정</button><button type="button" class="btn subtle" data-unitfix-chapter-clear-end="1">끝 지점 비우기</button></div></div>` : '<div class="emptyState">검색 결과가 없습니다. 키워드나 번호를 바꿔 보세요.</div>');
  }
  function openIndexes(){ try{ return new Set(JSON.parse(localStorage.getItem(OPEN_KEY) || '[]')); }catch(_){ return new Set(); } }
  function saveOpenIndexes(set){ try{ localStorage.setItem(OPEN_KEY, JSON.stringify(Array.from(set))); }catch(_){} }
  function countText(ch){ return String(ch.body || plainFromHtml(ch.bodyHtml || '')).replace(/\s+/g,' ').trim(); }
  function renderToc(chs, compact){
    if(!chs || !chs.length) return '<div class="emptyState">챕터가 아직 없습니다.</div>';
    if(compact){
      return `<div class="chapterTocBox"><div class="tocSummary"><strong>현재 목차</strong><span>${chs.length}개 챕터</span></div>${chs.map((ch, idx)=>{ const text = countText(ch); const range = ch.endIndex >= ch.startIndex ? `${ch.startIndex + 1}–${ch.endIndex + 1}` : '빈 챕터'; return `<div class="chapterTocRow"><b>${idx+1}</b><span><strong>${esc(ch.title)}</strong><small>${esc(range)} · ${esc(text.slice(0,70))}</small></span><em>${Number(text.length).toLocaleString('ko-KR')}자</em></div>`; }).join('')}</div>`;
    }
    const opens = openIndexes();
    return `<div class="chapterPreviewList polishedChapterPreview">${chs.map((ch, idx)=>{ const text = countText(ch); const lead = text.slice(0,140); const range = ch.endIndex >= ch.startIndex ? `${ch.startIndex + 1}–${ch.endIndex + 1}` : '빈 챕터'; return `<details class="unitChapterPreviewItem polishedChapterItem" data-preview-idx="${idx}" ${opens.has(idx) ? 'open' : ''}><summary><b>${idx+1}</b><span><strong>${esc(ch.title)}</strong><small>${esc(range)} · ${Number(text.length).toLocaleString('ko-KR')}자${lead ? ` · ${esc(lead)}` : ''}</small></span><em>${opens.has(idx) ? '접기' : '펼치기'}</em></summary><div class="chapterPreviewBody"><div class="chapterPreviewInner">${fullHtml(ch,false) || '<p class="mutedText">미리보기 없음</p>'}</div></div></details>`; }).join('')}</div>`;
  }
  function updatePreview(){
    const chs = chaptersFromPlan();
    if(typeof chapterPreviewEl !== 'undefined' && chapterPreviewEl) chapterPreviewEl.innerHTML = renderToc(chs, false);
    const epubPrev = qs('#epubPreview');
    if(epubPrev){ const first = chs[0]; epubPrev.innerHTML = `<div class="previewMeta"><b>미리보기</b><span>${chs.length}개 챕터</span></div><div class="bookPreview">${first ? fullHtml(first,true) : '<p class="mutedText">미리보기 없음</p>'}</div>`; }
  }
  function refreshAll(){ renderRows(); renderSearch(); updatePreview(); }

  window.__rofanFinalChapterUnits = chapterUnits;
  window.getExportChapters = function(){ return chaptersFromPlan(); };
  if(typeof getExportChapters !== 'undefined') getExportChapters = window.getExportChapters;
  window.chapterBodyToXhtml = function(ch){ return fullHtml(ch, false); };
  if(typeof chapterBodyToXhtml !== 'undefined') chapterBodyToXhtml = window.chapterBodyToXhtml;
  window.renderChapterTocHtml = function(chs, compact){ return renderToc(chs, compact); };
  if(typeof renderChapterTocHtml !== 'undefined') renderChapterTocHtml = window.renderChapterTocHtml;
  const previousUpdate = window.updateEpubPreview;
  window.updateEpubPreview = function(){ try{ if(typeof previousUpdate === 'function') previousUpdate(); }catch(_){} refreshAll(); };
  if(typeof updateEpubPreview !== 'undefined') updateEpubPreview = window.updateEpubPreview;

  document.addEventListener('click', function(ev){
    const nav = ev.target.closest && ev.target.closest('[data-unitfix-chapter-page]');
    if(nav){
      ev.preventDefault(); ev.stopImmediatePropagation();
      const total = searchMatches().length;
      page += nav.dataset.unitfixChapterPage === 'next' ? 1 : -1;
      page = Math.max(0, Math.min(page, Math.max(0, total - 1)));
      renderSearch();
      return;
    }
    const set = ev.target.closest && ev.target.closest('[data-unitfix-chapter-set-end]');
    if(set){
      ev.preventDefault(); ev.stopImmediatePropagation();
      const unitList = chapterUnits();
      const pl = sanitizePlan(plan(), unitList);
      const id = activeEditorId() || (pl.chapters[0] && pl.chapters[0].id);
      const ch = pl.chapters.find(c => c.id === id) || pl.chapters[0];
      if(ch){ ch.endPara = Math.max(0, Math.min(Math.max(0, unitList.length - 1), Number(set.dataset.unitfixChapterSetEnd) || 0)); }
      ensureTrailingChapter(pl, unitList);
      savePlan(pl);
      decorateEditor(ch && ch.id);
      if(typeof showToast === 'function') showToast('챕터 끝 지점을 설정했습니다.');
      refreshAll();
      return;
    }
    const clear = ev.target.closest && ev.target.closest('[data-unitfix-chapter-clear-end]');
    if(clear){
      ev.preventDefault(); ev.stopImmediatePropagation();
      const unitList = chapterUnits();
      const pl = sanitizePlan(plan(), unitList);
      const id = activeEditorId() || (pl.chapters[0] && pl.chapters[0].id);
      const ch = pl.chapters.find(c => c.id === id) || pl.chapters[0];
      if(ch) ch.endPara = null;
      savePlan(pl);
      decorateEditor(id);
      refreshAll();
      return;
    }
    const edit = ev.target.closest && ev.target.closest('[data-chapter-edit]');
    if(edit){ activeId = edit.dataset.chapterEdit; setTimeout(()=>{ decorateEditor(activeId); page = 0; renderSearch(); refreshAll(); }, 30); }
    const summary = ev.target.closest && ev.target.closest('#chapterPreview .unitChapterPreviewItem > summary');
    if(summary){
      ev.preventDefault(); ev.stopImmediatePropagation();
      const details = summary.parentElement;
      const idx = Number(details.dataset.previewIdx);
      details.open = !details.open;
      const setOpen = openIndexes();
      if(details.open) setOpen.add(idx); else setOpen.delete(idx);
      saveOpenIndexes(setOpen);
      updatePreview();
    }
  }, true);
  document.addEventListener('input', function(ev){
    if(ev.target && ev.target.matches && ev.target.matches('[data-chapter-end-keyword], [data-chapter-end-order]')){ page = 0; setTimeout(renderSearch, 0); }
    if(ev.target && ev.target.matches && ev.target.matches('[data-chapter-title]')){ setTimeout(()=>{ renderRows(); updatePreview(); }, 0); }
  }, true);
  function installStyle(){
    if(qs('#rofanChapterUnitPreviewPolish')) return;
    const style = document.createElement('style');
    style.id = 'rofanChapterUnitPreviewPolish';
    style.textContent = `
      .polishedChapterPreview{display:grid;gap:10px;}
      .unitChapterPreviewItem{border:1px solid var(--line)!important;border-radius:18px!important;background:#fff!important;box-shadow:0 6px 20px rgba(63,107,128,.045);overflow:hidden;}
      .unitChapterPreviewItem>summary{padding:12px 14px!important;grid-template-columns:32px minmax(0,1fr) auto!important;align-items:center!important;}
      .unitChapterPreviewItem>summary b{width:26px!important;height:26px!important;border-radius:9px!important;}
      .unitChapterPreviewItem>summary strong{font-size:14px;color:rgba(31,45,54,.82)!important;}
      .unitChapterPreviewItem>summary small{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%;font-size:11.5px!important;line-height:1.45;}
      .unitChapterPreviewItem>summary em{font-size:11px!important;border:1px solid var(--line2);border-radius:999px;padding:4px 8px;background:var(--paper2);}
      .chapterPreviewBody{border-top:1px solid var(--line2);background:#fff;max-height:520px;overflow:auto;padding:0!important;}
      .chapterPreviewInner{padding:18px 20px;line-height:1.85;word-break:keep-all;overflow-wrap:break-word;}
      .chapterPreviewInner p{margin:0 0 1em;}
      .chapterPreviewInner .rofan-block{margin:0 0 1.15em;}
      .chapterPreviewInner .rofan-block p{margin:.2em 0 .75em;}
      .chapterPreviewInner blockquote{margin:1em 0;}
      .chapterSearchPreview{white-space:pre-wrap!important;line-height:1.8!important;}
      @media(max-width:860px){.unitChapterPreviewItem>summary{grid-template-columns:28px minmax(0,1fr)!important}.unitChapterPreviewItem>summary em{grid-column:2;justify-self:start}.chapterPreviewInner{padding:14px 15px;font-size:12.5px;}}
    `;
    document.head.appendChild(style);
  }
  function boot(){ installStyle(); refreshAll(); setTimeout(refreshAll, 80); setTimeout(refreshAll, 260); }
  qsa('.tab').forEach(tab => tab.addEventListener('click', () => setTimeout(boot, 80)));
  if(typeof epubEditEditor !== 'undefined' && epubEditEditor){ epubEditEditor.addEventListener('input', () => setTimeout(boot, 80)); }
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();

/* --- final chapter state manager fix: append-only add, stable editing id, reset/cache clear --- */
(function(){
  const KEY = 'rofan-manual-chapters-v2';
  const OPEN_KEY = 'rofan-chapter-preview-open-v2';
  const ACTIVE_KEY = 'rofan-active-chapter-id-v2';
  let searchPage = 0;
  let refreshTimer = null;

  function qs(sel, root=document){ return root.querySelector(sel); }
  function qsa(sel, root=document){ return Array.from(root.querySelectorAll(sel)); }
  function mode(){ return (typeof activeMode === 'string' && activeMode) ? activeMode : 'classic'; }
  function esc(v){
    if(typeof escapeHTML === 'function') return escapeHTML(v == null ? '' : String(v));
    return String(v == null ? '' : v).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  }
  function attr(v){
    if(typeof escapeAttr === 'function') return escapeAttr(v == null ? '' : String(v));
    return esc(v);
  }
  function show(msg){ if(typeof showToast === 'function') showToast(msg); }
  function uid(){ return 'ch-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 8); }
  function titleFor(idx){ return idx === 0 ? 'Prologue' : 'Chapter ' + (idx + 1); }
  function defaultChapter(idx){ return { id: uid(), title: titleFor(idx), endPara: null, note: '', imageData: '', imageName: '', imageType: '', imagePos: 'belowTitle' }; }
  function readAllPlans(){ try{ return JSON.parse(localStorage.getItem(KEY) || '{}') || {}; }catch(_){ return {}; } }
  function writeAllPlans(all){
    try{ localStorage.setItem(KEY, JSON.stringify(all || {})); }catch(_){ }
    if(typeof scheduleAutosave === 'function') scheduleAutosave();
  }
  function getRawPlan(){
    const all = readAllPlans();
    const m = mode();
    if(!all[m] || !Array.isArray(all[m].chapters)) all[m] = { chapters: [] };
    if(!all[m].chapters.length) all[m].chapters.push(defaultChapter(0));
    return { all, plan: all[m] };
  }
  function savePlan(plan){ const all = readAllPlans(); all[mode()] = plan || { chapters: [] }; writeAllPlans(all); }
  function activeId(){
    const editor = qs('.manualChapterEditor[data-editing-id]');
    if(editor && editor.dataset.editingId) return editor.dataset.editingId;
    const input = qs('[data-chapter-title][data-chapter-id]');
    if(input && input.dataset.chapterId) return input.dataset.chapterId;
    try{ return localStorage.getItem(ACTIVE_KEY + ':' + mode()) || ''; }catch(_){ return ''; }
  }
  function setActiveId(id){ try{ localStorage.setItem(ACTIVE_KEY + ':' + mode(), id || ''); }catch(_){ } }
  function chapterById(plan, id){ return plan && Array.isArray(plan.chapters) ? plan.chapters.find(ch => ch.id === id) : null; }
  function saveOpenIndexes(set){ try{ localStorage.setItem(OPEN_KEY, JSON.stringify(Array.from(set || []))); }catch(_){ } }
  function openIndexes(){ try{ return new Set(JSON.parse(localStorage.getItem(OPEN_KEY) || '[]')); }catch(_){ return new Set(); } }

  function textFromHtml(html){
    if(typeof blockHtmlToText === 'function') return blockHtmlToText(html || '');
    const d = document.createElement('div'); d.innerHTML = html || ''; return (d.innerText || d.textContent || '').trim();
  }
  function htmlFromText(text){
    const raw = String(text || '').replace(/\r/g, '').trim();
    if(!raw) return '';
    return raw.split(/\n\s*\n+/).map(p => '<p>' + esc(p).replace(/\n/g, '<br>') + '</p>').join('\n');
  }
  function normalizeUnit(u){
    if(!u) return null;
    const html = u.bodyHtml || u.html || '';
    const body = u.body || u.text || (html ? textFromHtml(html) : '');
    const text = String(u.text || body || (html ? textFromHtml(html) : '') || '').trim();
    if(!text && !html) return null;
    return { text, body: String(body || text || ''), html: html || htmlFromText(body || text) };
  }
  function fallbackUnitsFromText(text){
    return String(text || '').replace(/\r/g, '').split(/\n\s*\n+/).map(s => s.trim()).filter(Boolean).map(s => ({ text: s.replace(/<[^>]*>/g, '').trim(), body: s, html: htmlFromText(s) }));
  }
  function getUnits(){
    try{
      if(typeof window.__rofanFinalChapterUnits === 'function'){
        const list = window.__rofanFinalChapterUnits().map(normalizeUnit).filter(Boolean);
        if(list.length) return list;
      }
      if(typeof window.__rofanChapterUnitsPatch === 'function'){
        const list = window.__rofanChapterUnitsPatch().map(normalizeUnit).filter(Boolean);
        if(list.length) return list;
      }
    }catch(err){ console.warn('chapter unit source failed', err); }
    if(mode() === 'epubedit' && typeof epubEditEditor !== 'undefined' && epubEditEditor){
      const nodes = Array.from(epubEditEditor.childNodes).filter(n => !(n.nodeType === 1 && n.classList && n.classList.contains('manual-chapter-separator')) && ((n.textContent || '').trim() || n.nodeType === 1));
      if(nodes.length) return nodes.map(n => normalizeUnit({ html: n.outerHTML || esc(n.textContent || ''), text: (n.innerText || n.textContent || '').trim() })).filter(Boolean);
      return fallbackUnitsFromText(epubEditEditor.innerText || epubEditEditor.textContent || '');
    }
    let text = '';
    try{
      if(mode() === 'chat' && typeof chatOutput !== 'undefined' && chatOutput) text = chatOutput.value || '';
      else if(mode() === 'classic' && typeof output !== 'undefined' && output) text = output.value || '';
      else if(typeof getPreparedOutputForExport === 'function') text = getPreparedOutputForExport() || '';
    }catch(_){ }
    return fallbackUnitsFromText(text);
  }
  function normalizePlan(plan, units){
    if(!plan || !Array.isArray(plan.chapters)) plan = { chapters: [] };
    if(!plan.chapters.length) plan.chapters.push(defaultChapter(0));
    const max = Math.max(0, (units || []).length - 1);
    plan.chapters.forEach((ch, idx) => {
      if(!ch.id) ch.id = uid();
      if(!ch.title) ch.title = titleFor(idx);
      if(ch.endPara === '' || ch.endPara === undefined || ch.endPara === null){ ch.endPara = null; }
      else {
        const num = Number(ch.endPara);
        ch.endPara = Number.isFinite(num) ? Math.max(0, Math.min(max, Math.floor(num))) : null;
      }
      ch.note = ch.note || '';
      ch.imageData = ch.imageData || '';
      ch.imageName = ch.imageName || '';
      ch.imageType = ch.imageType || '';
      ch.imagePos = ch.imagePos || 'belowTitle';
    });
    return plan;
  }
  function ensureTrailingChapter(plan, units){
    const max = Math.max(0, (units || []).length - 1);
    const last = plan && plan.chapters && plan.chapters[plan.chapters.length - 1];
    if(units && units.length && last && last.endPara !== null && last.endPara !== undefined && Number(last.endPara) < max){
      plan.chapters.push(defaultChapter(plan.chapters.length));
      return true;
    }
    return false;
  }
  function planAndUnits(save){
    const obj = getRawPlan();
    const units = getUnits();
    const plan = normalizePlan(obj.plan, units);
    if(save){ ensureTrailingChapter(plan, units); savePlan(plan); }
    return { plan, units };
  }
  function rangesFor(plan, units){
    const max = Math.max(-1, (units || []).length - 1);
    let start = 0;
    return plan.chapters.map((ch, idx) => {
      let end = ch.endPara;
      if(end === null || end === undefined || end === '') end = idx === plan.chapters.length - 1 ? max : start - 1;
      else end = Number(end);
      if(!Number.isFinite(end)) end = start - 1;
      end = Math.max(start - 1, Math.min(max, Math.floor(end)));
      const r = { start, end };
      start = end + 1;
      return r;
    });
  }
  function unitHtml(u){ return (u && u.html) || htmlFromText((u && (u.body || u.text)) || ''); }
  function imageHtml(ch){ return ch && ch.imageData ? `<figure class="chapterImage"><img src="${attr(ch.imageData)}" alt="${attr(ch.imageName || ch.title || 'chapter image')}"></figure>` : ''; }
  function fullHtml(ch, includeTitle){
    const note = ch.note ? `<p class="chapterNote">${esc(ch.note).replace(/\n/g,'<br>')}</p>` : '';
    const img = imageHtml(ch);
    return `${ch.imagePos === 'aboveTitle' ? img : ''}${includeTitle ? `<h1>${esc(ch.title || '')}</h1>` : ''}${note}${(!ch.imagePos || ch.imagePos === 'belowTitle') ? img : ''}${ch.bodyHtml || ''}${ch.imagePos === 'bottom' ? img : ''}`;
  }
  function chaptersFromPlan(){
    const { plan, units } = planAndUnits(true);
    const ranges = rangesFor(plan, units);
    return plan.chapters.map((ch, idx) => {
      const r = ranges[idx] || { start:0, end:-1 };
      const slice = r.end >= r.start ? units.slice(r.start, r.end + 1) : [];
      const body = slice.map(u => u.body || u.text || '').join('\n\n').trim();
      const bodyHtml = slice.map(unitHtml).join('\n');
      return Object.assign({}, ch, { title: ch.title || titleFor(idx), body, bodyHtml, startIndex:r.start, endIndex:r.end });
    }).filter((ch, idx) => ch.body || ch.bodyHtml || ch.note || ch.imageData || idx === 0);
  }
  function renderRows(){
    const box = qs('#manualChapterRows');
    if(!box) return;
    const { plan, units } = planAndUnits(true);
    const ranges = rangesFor(plan, units);
    box.innerHTML = plan.chapters.map((ch, idx) => {
      const r = ranges[idx] || { start:0, end:-1 };
      const range = r.end >= r.start ? `${r.start + 1}–${Math.min(r.end + 1, units.length)}` : '끝 지점 미설정';
      return `<div class="manualChapterRow" data-id="${attr(ch.id)}"><b>${idx + 1}</b><span><strong>${esc(ch.title || titleFor(idx))}</strong><small>${range}${ch.note ? ' · 문구 있음' : ''}${ch.imageData ? ' · 이미지 있음' : ''}</small></span><button type="button" class="btn subtle" data-chapter-edit="${attr(ch.id)}">편집</button>${plan.chapters.length > 1 ? `<button type="button" class="btn subtle warn" data-chapter-delete="${attr(ch.id)}">삭제</button>` : ''}</div>`;
    }).join('');
  }
  function ensureManagerUi(){
    const toc = qs('#chapterTocInline');
    const host = qs('#chapterDividerPanel');
    if(!toc || !host) return false;
    if(!qs('#manualChapterRows', toc)){
      toc.innerHTML = `<div class="manualChapterHead"><strong>현재 챕터</strong><span class="manualChapterHeadActions"><button type="button" class="btn subtle warn" data-final-chapter-reset="1">챕터 초기화</button><button type="button" class="btn primary" data-chapter-add="1">챕터 추가</button></span></div><div id="manualChapterRows" class="manualChapterRows"></div>`;
    }else{
      const head = qs('.manualChapterHead', toc);
      if(head && !qs('[data-final-chapter-reset]', head)){
        head.innerHTML = `<strong>현재 챕터</strong><span class="manualChapterHeadActions"><button type="button" class="btn subtle warn" data-final-chapter-reset="1">챕터 초기화</button><button type="button" class="btn primary" data-chapter-add="1">챕터 추가</button></span>`;
      }
    }
    if(!qs('#manualChapterEditHost', host)) host.innerHTML = `<div id="manualChapterEditHost"><div class="emptyState">편집을 누르면 챕터 끝 지점, 문구, 이미지를 설정할 수 있습니다.</div></div>`;
    return true;
  }
  function searchMatches(){
    const units = getUnits();
    const kw = (qs('[data-chapter-end-keyword]') || {}).value || '';
    const order = (qs('[data-chapter-end-order]') || {}).value || '';
    let list = units.map((u, idx) => Object.assign({}, u, { index: idx }));
    const q = String(kw).trim().toLowerCase();
    if(q) list = list.filter(u => String(u.text || '').toLowerCase().includes(q));
    const n = Number(String(order).trim());
    if(Number.isFinite(n) && n > 0) list = q ? list.filter((_u, idx) => idx + 1 === n) : list.filter(u => u.index + 1 === n);
    return list;
  }
  function previewText(item){
    const text = String((item && item.text) || '').replace(/\s+/g, ' ').trim();
    const q = ((qs('[data-chapter-end-keyword]') || {}).value || '').trim().toLowerCase();
    if(!q || text.length <= 520) return text;
    const pos = text.toLowerCase().indexOf(q);
    if(pos < 0) return text.slice(0, 520) + '…';
    const s = Math.max(0, pos - 180), e = Math.min(text.length, pos + q.length + 320);
    return `${s ? '…' : ''}${text.slice(s, e)}${e < text.length ? '…' : ''}`;
  }
  function renderSearch(){
    const target = qs('#manualChapterSearchResults');
    if(!target) return;
    const matches = searchMatches();
    searchPage = Math.max(0, Math.min(searchPage, Math.max(0, matches.length - 1)));
    const cur = matches[searchPage];
    target.innerHTML = `<div class="miniToolHead"><div><strong>챕터 끝 지점</strong><span>검색한 단위를 이 챕터의 마지막 단위로 설정합니다.</span></div><span>${matches.length ? `${searchPage + 1}/${matches.length}` : '0개'}</span></div>` +
      (cur ? `<div class="chapterMatchCard"><div class="dupeSummary withNav"><span><span class="pill">단위 ${cur.index + 1}</span></span><span class="navButtons"><button type="button" class="navIconBtn" data-final-chapter-page="prev" ${searchPage <= 0 ? 'disabled' : ''}>‹</button><button type="button" class="navIconBtn" data-final-chapter-page="next" ${searchPage >= matches.length - 1 ? 'disabled' : ''}>›</button></span></div><div class="previewText fullPreview chapterSearchPreview">${esc(previewText(cur))}</div><div class="chapterInsertRow"><button type="button" class="btn primary" data-final-chapter-set-end="${cur.index}">이 단위를 끝 지점으로 설정</button><button type="button" class="btn subtle" data-final-chapter-clear-end="1">끝 지점 비우기</button></div></div>` : '<div class="emptyState">검색 결과가 없습니다. 키워드나 번호를 바꿔 보세요.</div>');
  }
  function renderEdit(id){
    ensureManagerUi();
    const host = qs('#manualChapterEditHost');
    if(!host) return;
    const { plan } = planAndUnits(false);
    const ch = chapterById(plan, id);
    if(!ch){ host.innerHTML = `<div class="emptyState">해당 챕터를 찾을 수 없습니다. 다시 편집을 눌러 주세요.</div>`; return; }
    setActiveId(ch.id);
    host.innerHTML = `<details class="manualChapterEditor" open data-editing-id="${attr(ch.id)}"><summary>${esc(ch.title || '챕터')} 편집</summary><div class="manualChapterEditorBody">
      <div class="manualChapterForm">
        <label class="control wide chapterTitleControl">챕터명 <input type="text" data-chapter-title data-chapter-id="${attr(ch.id)}" value="${attr(ch.title || '')}" placeholder="챕터 제목"></label>
        <label class="control wide">소제목 아래 문구 <textarea data-chapter-note data-chapter-id="${attr(ch.id)}" rows="2" placeholder="소제목 아래에 넣을 짧은 문구">${esc(ch.note || '')}</textarea></label>
        <label class="fileControl chapterImagePick"><span class="fileButtonText">이미지 선택</span><span class="fileNameText">${esc(ch.imageName || '선택 없음')}</span><input type="file" data-chapter-image data-chapter-id="${attr(ch.id)}" accept=".png,.jpg,.jpeg,.webp,.gif,.svg,image/png,image/jpeg,image/webp,image/gif,image/svg+xml"></label>
        <label class="control">이미지 위치 <select data-chapter-image-pos data-chapter-id="${attr(ch.id)}"><option value="aboveTitle" ${ch.imagePos === 'aboveTitle' ? 'selected' : ''}>소제목 위</option><option value="belowTitle" ${(!ch.imagePos || ch.imagePos === 'belowTitle') ? 'selected' : ''}>소제목 아래</option><option value="bottom" ${ch.imagePos === 'bottom' ? 'selected' : ''}>맨 아래</option></select></label>
        ${ch.imageData ? `<button type="button" class="btn subtle warn" data-final-chapter-image-clear="${attr(ch.id)}">이미지 제거</button>` : ''}
      </div>
      <div class="manualChapterSearch">
        <div class="optionRow compactControls" id="manualChapterSearchFields"><span class="control">검색 <input type="search" data-chapter-end-keyword value="" placeholder="끝나는 지점 키워드" autocomplete="off" autocapitalize="off" spellcheck="false"></span><span class="control">순서 <input type="number" min="1" data-chapter-end-order value="" placeholder="번호" inputmode="numeric"></span></div>
        <div id="manualChapterSearchResults"></div>
      </div>
    </div></details>`;
    searchPage = 0;
    renderSearch();
  }
  function countText(ch){ return String(ch.body || textFromHtml(ch.bodyHtml || '')).replace(/\s+/g, ' ').trim(); }
  function renderToc(chapters, compact){
    if(!chapters || !chapters.length) return '<div class="emptyState">챕터가 아직 없습니다.</div>';
    if(compact){
      return `<div class="chapterTocBox"><div class="tocSummary"><strong>현재 목차</strong><span>${chapters.length}개 챕터</span></div>${chapters.map((ch, idx)=>{ const text = countText(ch); const range = ch.endIndex >= ch.startIndex ? `${ch.startIndex + 1}–${ch.endIndex + 1}` : '빈 챕터'; return `<div class="chapterTocRow"><b>${idx+1}</b><span><strong>${esc(ch.title)}</strong><small>${esc(range)} · ${esc(text.slice(0,70))}</small></span><em>${Number(text.length).toLocaleString('ko-KR')}자</em></div>`; }).join('')}</div>`;
    }
    const opens = openIndexes();
    return `<div class="chapterPreviewList polishedChapterPreview">${chapters.map((ch, idx)=>{ const text = countText(ch); const lead = text.slice(0,140); const range = ch.endIndex >= ch.startIndex ? `${ch.startIndex + 1}–${ch.endIndex + 1}` : '빈 챕터'; return `<details class="unitChapterPreviewItem polishedChapterItem" data-preview-idx="${idx}" ${opens.has(idx) ? 'open' : ''}><summary><b>${idx+1}</b><span><strong>${esc(ch.title)}</strong><small>${esc(range)} · ${Number(text.length).toLocaleString('ko-KR')}자${lead ? ` · ${esc(lead)}` : ''}</small></span><em>${opens.has(idx) ? '접기' : '펼치기'}</em></summary><div class="chapterPreviewBody"><div class="chapterPreviewInner">${fullHtml(ch,false) || '<p class="mutedText">미리보기 없음</p>'}</div></div></details>`; }).join('')}</div>`;
  }
  function updatePreview(){
    const chapters = chaptersFromPlan();
    if(typeof chapterPreviewEl !== 'undefined' && chapterPreviewEl) chapterPreviewEl.innerHTML = renderToc(chapters, false);
    if(typeof epubPreviewEl !== 'undefined' && epubPreviewEl){
      const first = chapters[0];
      epubPreviewEl.innerHTML = `<div class="previewMeta"><b>미리보기</b><span>${chapters.length}개 챕터</span></div><div class="bookPreview">${first ? fullHtml(first,true) : '<p class="mutedText">미리보기 없음</p>'}</div>`;
    }
  }
  function refreshAll(options={}){
    if(!ensureManagerUi()) return;
    renderRows();
    if(options.keepSearch !== true) renderSearch();
    updatePreview();
  }
  function scheduleLightRefresh(){ clearTimeout(refreshTimer); refreshTimer = setTimeout(() => { renderRows(); updatePreview(); }, 180); }
  function refreshAfterState(id){ refreshAll(); if(id) renderEdit(id); }

  function resetCurrentChapters(){
    if(!confirm('챕터 설정을 초기화하시겠습니까?')) return;
    const all = readAllPlans();
    delete all[mode()];
    writeAllPlans(all);
    try{ localStorage.removeItem(OPEN_KEY); localStorage.removeItem(ACTIVE_KEY + ':' + mode()); }catch(_){ }
    searchPage = 0;
    refreshAll();
    const p = getRawPlan().plan;
    renderEdit(p.chapters[0].id);
    show('챕터 설정을 초기화했습니다.');
  }

  function interceptClick(ev){
    const target = ev.target && ev.target.closest ? ev.target : null;
    if(!target) return;
    const add = target.closest('[data-chapter-add]');
    const edit = target.closest('[data-chapter-edit]');
    const del = target.closest('[data-chapter-delete]');
    const reset = target.closest('[data-final-chapter-reset]');
    const pageBtn = target.closest('[data-final-chapter-page], [data-unitfix-chapter-page], [data-stable-chapter-page], [data-patch-chapter-page], [data-manual-chapter-page]');
    const setEnd = target.closest('[data-final-chapter-set-end], [data-unitfix-chapter-set-end], [data-stable-chapter-set-end], [data-patch-chapter-set-end], [data-chapter-set-end]');
    const clearEnd = target.closest('[data-final-chapter-clear-end], [data-unitfix-chapter-clear-end], [data-stable-chapter-clear-end], [data-patch-chapter-clear-end], [data-chapter-clear-end]');
    const clearImg = target.closest('[data-final-chapter-image-clear], [data-chapter-image-clear]');
    const previewSummary = target.closest('#chapterPreview .unitChapterPreviewItem > summary, #chapterPreview .chapterPreviewItem > summary');
    if(!(add || edit || del || reset || pageBtn || setEnd || clearEnd || clearImg || previewSummary)) return;

    ev.preventDefault(); ev.stopPropagation(); ev.stopImmediatePropagation();

    if(reset){ resetCurrentChapters(); return; }
    if(add){
      const { plan, units } = planAndUnits(false);
      normalizePlan(plan, units);
      plan.chapters.push(defaultChapter(plan.chapters.length));
      const newId = plan.chapters[plan.chapters.length - 1].id;
      savePlan(plan); setActiveId(newId);
      refreshAfterState(newId);
      show('챕터를 맨 뒤에 추가했습니다.');
      return;
    }
    if(edit){ const id = edit.dataset.chapterEdit; setActiveId(id); renderRows(); renderEdit(id); updatePreview(); return; }
    if(del){
      const id = del.dataset.chapterDelete;
      if(!confirm('이 챕터를 삭제하시겠습니까?')) return;
      const { plan, units } = planAndUnits(false);
      plan.chapters = plan.chapters.filter(ch => ch.id !== id);
      if(!plan.chapters.length) plan.chapters.push(defaultChapter(0));
      normalizePlan(plan, units); savePlan(plan);
      const next = plan.chapters[Math.max(0, Math.min(plan.chapters.length - 1, 0))];
      setActiveId(next.id); refreshAfterState(next.id); return;
    }
    if(pageBtn){
      const val = pageBtn.dataset.finalChapterPage || pageBtn.dataset.unitfixChapterPage || pageBtn.dataset.stableChapterPage || pageBtn.dataset.patchChapterPage || pageBtn.dataset.manualChapterPage;
      const total = searchMatches().length;
      searchPage += val === 'next' ? 1 : -1;
      searchPage = Math.max(0, Math.min(searchPage, Math.max(0, total - 1)));
      renderSearch(); return;
    }
    if(setEnd){
      const raw = setEnd.dataset.finalChapterSetEnd || setEnd.dataset.unitfixChapterSetEnd || setEnd.dataset.stableChapterSetEnd || setEnd.dataset.patchChapterSetEnd || setEnd.dataset.chapterSetEnd;
      const { plan, units } = planAndUnits(false);
      normalizePlan(plan, units);
      const id = activeId() || (plan.chapters[0] && plan.chapters[0].id);
      const ch = chapterById(plan, id);
      if(ch){
        ch.endPara = Math.max(0, Math.min(Math.max(0, units.length - 1), Number(raw) || 0));
        ensureTrailingChapter(plan, units);
        savePlan(plan); setActiveId(ch.id); refreshAfterState(ch.id); show('챕터 끝 지점을 설정했습니다.');
      }
      return;
    }
    if(clearEnd){
      const { plan, units } = planAndUnits(false);
      normalizePlan(plan, units);
      const id = activeId() || (plan.chapters[0] && plan.chapters[0].id);
      const ch = chapterById(plan, id);
      if(ch){ ch.endPara = null; savePlan(plan); refreshAfterState(ch.id); }
      return;
    }
    if(clearImg){
      const id = clearImg.dataset.finalChapterImageClear || activeId();
      const { plan, units } = planAndUnits(false);
      normalizePlan(plan, units);
      const ch = chapterById(plan, id);
      if(ch){ ch.imageData=''; ch.imageName=''; ch.imageType=''; savePlan(plan); refreshAfterState(ch.id); }
      return;
    }
    if(previewSummary){
      const details = previewSummary.parentElement;
      const idx = Number(details.dataset.previewIdx || '0');
      const opens = openIndexes();
      details.open = !details.open;
      if(details.open) opens.add(idx); else opens.delete(idx);
      saveOpenIndexes(opens);
      updatePreview();
    }
  }

  function interceptInput(ev){
    const t = ev.target;
    if(!t || !t.matches) return;
    if(t.matches('[data-chapter-end-keyword], [data-chapter-end-order]')){
      ev.stopPropagation(); ev.stopImmediatePropagation();
      searchPage = 0; renderSearch(); return;
    }
    if(t.matches('[data-chapter-title], [data-chapter-note], [data-chapter-image-pos]')){
      ev.stopPropagation(); ev.stopImmediatePropagation();
      const { plan, units } = planAndUnits(false);
      normalizePlan(plan, units);
      const id = t.dataset.chapterId || activeId();
      const ch = chapterById(plan, id);
      if(!ch) return;
      if(t.matches('[data-chapter-title]')){
        ch.title = t.value;
        const editor = t.closest('.manualChapterEditor');
        if(editor){ editor.dataset.editingId = ch.id; const sum = editor.querySelector('summary'); if(sum) sum.textContent = (ch.title || '챕터') + ' 편집'; }
        setActiveId(ch.id);
        savePlan(plan);
        renderRows();
        scheduleLightRefresh();
        return;
      }
      if(t.matches('[data-chapter-note]')) ch.note = t.value;
      if(t.matches('[data-chapter-image-pos]')) ch.imagePos = t.value;
      setActiveId(ch.id); savePlan(plan); scheduleLightRefresh();
    }
  }
  function interceptChange(ev){
    const t = ev.target;
    if(!t || !t.matches || !t.matches('[data-chapter-image]')) return;
    ev.stopPropagation(); ev.stopImmediatePropagation();
    const file = t.files && t.files[0];
    if(!file) return;
    const { plan, units } = planAndUnits(false);
    normalizePlan(plan, units);
    const id = t.dataset.chapterId || activeId();
    const ch = chapterById(plan, id);
    if(!ch) return;
    const reader = new FileReader();
    reader.onload = () => { ch.imageData = String(reader.result || ''); ch.imageName = file.name || 'chapter-image'; ch.imageType = file.type || (file.name.toLowerCase().endsWith('.svg') ? 'image/svg+xml' : 'image/png'); savePlan(plan); refreshAfterState(ch.id); };
    reader.readAsDataURL(file);
  }

  window.addEventListener('click', interceptClick, true);
  window.addEventListener('input', interceptInput, true);
  window.addEventListener('change', interceptChange, true);

  window.getExportChapters = function(){ return chaptersFromPlan(); };
  if(typeof getExportChapters !== 'undefined') getExportChapters = window.getExportChapters;
  window.chapterBodyToXhtml = function(ch){ return fullHtml(ch, false); };
  if(typeof chapterBodyToXhtml !== 'undefined') chapterBodyToXhtml = window.chapterBodyToXhtml;
  window.renderChapterTocHtml = function(chapters, compact){ return renderToc(chapters, compact); };
  if(typeof renderChapterTocHtml !== 'undefined') renderChapterTocHtml = window.renderChapterTocHtml;
  window.__rofanFinalChapterRefresh = refreshAll;
  window.__rofanResetChapterSettings = resetCurrentChapters;

  function installStyle(){
    if(qs('#rofanFinalChapterStableManagerStyle')) return;
    const style = document.createElement('style');
    style.id = 'rofanFinalChapterStableManagerStyle';
    style.textContent = `.manualChapterHeadActions{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.manualChapterEditor[data-editing-id] [data-chapter-title]{will-change:contents}.chapterPreviewInner p{margin:0 0 1em}.chapterPreviewInner .rofan-block{margin:0 0 1.15em}`;
    document.head.appendChild(style);
  }
  function boot(){ installStyle(); ensureManagerUi(); renderRows(); updatePreview(); const id = activeId(); if(id && chapterById(planAndUnits(false).plan, id)) renderEdit(id); }
  qsa('.tab').forEach(tab => tab.addEventListener('click', () => setTimeout(boot, 80)));
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();

/* --- include chapter settings in saved-work cache deletion --- */
(function(){
  const chapterKeys = ['rofan-manual-chapters-v2','rofan-chapter-preview-open-v1','rofan-chapter-preview-open-v2'];
  const activePrefix = 'rofan-active-chapter-id-v2:';
  const baseClear = (typeof clearSavedWork === 'function') ? clearSavedWork : null;
  window.clearSavedWork = clearSavedWork = async function(){
    if(!window.confirm('저장된 작업 캐시를 삭제하시겠습니까? 챕터 설정도 함께 지워집니다.')) return;
    try{
      if(typeof idbDelete === 'function' && typeof WORK_STATE_KEY !== 'undefined') await idbDelete(WORK_STATE_KEY);
    }catch(_err){}
    try{ if(typeof WORK_META_KEY !== 'undefined') localStorage.removeItem(WORK_META_KEY); }catch(_){}
    try{ if(typeof WORK_FALLBACK_KEY !== 'undefined') localStorage.removeItem(WORK_FALLBACK_KEY); }catch(_){}
    chapterKeys.forEach(k => { try{ localStorage.removeItem(k); }catch(_){} });
    try{ Object.keys(localStorage).filter(k => k.startsWith(activePrefix)).forEach(k => localStorage.removeItem(k)); }catch(_){}
    try{ if(typeof cachedChatFileName !== 'undefined') cachedChatFileName = ''; }catch(_){}
    try{ if(typeof cachedCoverAsset !== 'undefined') cachedCoverAsset = null; }catch(_){}
    try{ if(typeof updateAutosaveBadge === 'function') updateAutosaveBadge('캐시 삭제됨'); }catch(_){}
    try{ if(typeof showToast === 'function') showToast('저장 캐시와 챕터 설정을 삭제했습니다.'); }catch(_){}
    try{ if(typeof window.__rofanFinalChapterRefresh === 'function') window.__rofanFinalChapterRefresh(); }catch(_){}
  };
})();
