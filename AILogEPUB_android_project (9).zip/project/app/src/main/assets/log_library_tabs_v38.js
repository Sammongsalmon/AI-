(() => {
  "use strict";
  if (window.__aiLogSharedLibraryV38) return;
  window.__aiLogSharedLibraryV38 = true;

  const bridge = () => window.RofanNativeBridge;
  const nativePrompt = command => { try { return window.prompt(command, "") || ""; } catch (_) { return ""; } };
  const te = new TextEncoder();
  const td = new TextDecoder("utf-8");
  const ACCEPTED = /\.(txt|log|md|markdown|json|jsonl|csv|tsv|xml|html?|mht|mhtml)$/i;
  const PREVIEW_HEAD = 4096;
  const PREVIEW_TAIL = 49152;
  const PREVIEW_TURNS = 5;
  const LEGACY_MIGRATION_KEY = "ai-log-shared-import-migrated-v38";
  const AUTO_SEEN_KEY = "ai-log-export-last-seen-v38";
  const ENCODING_KEY = "ai-log-shared-encodings-v38";
  const categories = {
    import: { label: "불러오기", folder: "불러오기", empty: "불러온 로그 파일이 없습니다.", add: true },
    full: { label: "전체 발췌", folder: "전체 범위 발췌", empty: "전체 범위 발췌 파일이 없습니다.", add: false },
    selected: { label: "선택 발췌", folder: "선택 범위 발췌", empty: "선택 범위 발췌 파일이 없습니다.", add: false }
  };
  const state = { category: "import", files: [], previews: new Map(), renaming: "", busy: false, opened: false };
  const $ = (selector, root = document) => root.querySelector(selector);
  const esc = value => String(value == null ? "" : value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  const safeName = value => String(value || "log.txt").replace(/[\\/:*?"<>|\u0000-\u001f]/g, "_").replace(/[ .]+$/g, "").slice(0, 180) || "log.txt";
  const toast = message => { if (typeof showToast === "function") showToast(message); else nativePrompt("__NATIVE_TOAST__\t" + btoa(unescape(encodeURIComponent(String(message))))); };
  const icon = name => ({
    folder:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3.5 6.5h6l1.8 2h9.2v9.5a2 2 0 0 1-2 2h-15z"/><path d="M3.5 6.5v-2h6l1.8 2"/></svg>',
    upload:'<svg viewBox="0 0 24 24"><path d="M12 16V4m0 0-4 4m4-4 4 4M4 15v4h16v-4"/></svg>',
    close:'<svg viewBox="0 0 24 24"><path d="m6 6 12 12M18 6 6 18"/></svg>',
    load:'<svg viewBox="0 0 24 24"><path d="M12 3v12m0 0 4-4m-4 4-4-4M4 18v2h16v-2"/></svg>',
    edit:'<svg viewBox="0 0 24 24"><path d="m4 16-.8 4 4-.8L18 8.4 15.6 6zM14.5 7.1l2.4 2.4"/></svg>',
    trash:'<svg viewBox="0 0 24 24"><path d="M4 7h16M9 7V4h6v3m3 0-1 13H7L6 7m4 4v5m4-5v5"/></svg>'
  }[name] || "");
  const formatBytes = value => { const n = Number(value) || 0; if (n < 1024) return `${n} B`; if (n < 1048576) return `${(n/1024).toFixed(n<10240?1:0)} KB`; return `${(n/1048576).toFixed(n<10485760?1:0)} MB`; };
  const formatDate = value => { try { return new Intl.DateTimeFormat("ko-KR", { month:"2-digit", day:"2-digit", hour:"2-digit", minute:"2-digit" }).format(new Date(Number(value)||0)); } catch (_) { return ""; } };
  const mimeFor = name => /\.html?$/i.test(name) ? "text/html" : /\.m(?:d|arkdown)$/i.test(name) ? "text/markdown" : /\.jsonl?$/i.test(name) ? "application/json" : /\.csv$/i.test(name) ? "text/csv" : /\.png$/i.test(name) ? "image/png" : "text/plain";
  const encPrefs = (() => { try { return JSON.parse(localStorage.getItem(ENCODING_KEY) || "{}") || {}; } catch (_) { return {}; } })();
  const saveEncPrefs = () => { try { localStorage.setItem(ENCODING_KEY, JSON.stringify(encPrefs)); } catch (_) {} };
  const fileKey = file => `${file.category}:${file.id}`;

  function modalMarkup() {
    return `<div class="logLibraryModal" id="logLibraryModal" hidden aria-hidden="true"><section class="logLibraryDialog sharedLibraryDialog" role="dialog" aria-modal="true" aria-labelledby="logLibraryTitle">
      <header class="logLibraryHead"><div class="logLibraryTitleWrap"><div class="logLibraryTitle" id="logLibraryTitle">로그 파일 보관함</div><div class="logLibraryPath" id="logLibraryPath"></div></div><div class="logLibraryHeadActions"><button type="button" class="logLibraryIconBtn" id="logLibraryClose" aria-label="닫기">${icon("close")}</button></div></header>
      <nav class="logLibraryTabs" aria-label="보관함 종류">${Object.entries(categories).map(([key, value]) => `<button type="button" class="logLibraryTab${key === "import" ? " active" : ""}" data-library-tab="${key}">${value.label}</button>`).join("")}</nav>
      <div class="logLibraryToolbar"><button type="button" class="logLibraryImportBtn" id="logLibraryImport">${icon("upload")}<span>파일 추가</span></button><input id="logLibraryFileInput" type="file" multiple hidden accept=".txt,.log,.md,.markdown,.json,.jsonl,.csv,.tsv,.xml,.html,.htm,.mht,.mhtml,text/*,application/json,application/octet-stream"><div class="logLibraryStatus" id="logLibraryStatus"></div></div>
      <div class="logLibraryList" id="logLibraryList"></div>
      <footer class="logLibraryFoot" id="logLibraryFoot"></footer>
    </section></div>`;
  }

  function installUi() {
    const oldButton = $("#logLibraryButton");
    if (oldButton) {
      const clone = oldButton.cloneNode(true);
      oldButton.replaceWith(clone);
    } else {
      const theme = $("#themeToggleButton");
      if (theme) {
        const button = document.createElement("button"); button.type = "button"; button.className = "themeIconButton"; button.id = "logLibraryButton"; button.title = "로그 파일 보관함"; button.setAttribute("aria-label", button.title); button.innerHTML = icon("folder"); theme.before(button);
      }
    }
    $("#logLibraryModal")?.remove();
    document.body.insertAdjacentHTML("beforeend", modalMarkup());
    $("#logLibraryButton")?.addEventListener("click", openLibrary);
    $("#logLibraryClose")?.addEventListener("click", closeLibrary);
    $("#logLibraryModal")?.addEventListener("click", event => { if (event.target.id === "logLibraryModal") closeLibrary(); });
    $("#logLibraryImport")?.addEventListener("click", openPicker);
    $("#logLibraryFileInput")?.addEventListener("change", async event => {
      const input = event.currentTarget;
      const files = Array.from(input?.files || []);
      try { if (files.length) await importFiles(files); }
      finally { if (input) input.value = ""; }
    });
    $(".logLibraryTabs")?.addEventListener("click", event => {
      const button = event.target.closest("[data-library-tab]");
      if (!button || state.busy) return;
      switchTab(button.dataset.libraryTab);
    });
    $("#logLibraryList")?.addEventListener("click", onListClick);
    document.addEventListener("keydown", event => { if (event.key === "Escape" && !$("#logLibraryModal")?.hidden) closeLibrary(); });
    updateChrome();
  }

  function setStatus(value) { const el = $("#logLibraryStatus"); if (el) el.textContent = String(value || ""); }
  function setBusy(value) { state.busy = !!value; $(".sharedLibraryDialog")?.classList.toggle("logLibraryBusy", state.busy); const add = $("#logLibraryImport"); if (add) add.disabled = state.busy; }
  function updateChrome() {
    const cfg = categories[state.category];
    document.querySelectorAll("[data-library-tab]").forEach(node => node.classList.toggle("active", node.dataset.libraryTab === state.category));
    const path = `Download/로그 발췌기/${cfg.folder}`;
    const pathEl = $("#logLibraryPath"); if (pathEl) { pathEl.textContent = path; pathEl.title = path; }
    const add = $("#logLibraryImport"); if (add) add.hidden = !cfg.add;
    const foot = $("#logLibraryFoot"); if (foot) foot.innerHTML = state.category === "import"
      ? `선택한 파일의 앱 관리본은 <b>${esc(path)}</b> 폴더에 저장됩니다. 원래 위치의 파일은 유지됩니다.`
      : `<b>${esc(path)}</b> 폴더의 실제 파일을 표시합니다. 이름 수정과 삭제도 해당 파일에 바로 반영됩니다.`;
  }

  async function openLibrary() {
    const modal = $("#logLibraryModal"); if (!modal) return;
    modal.hidden = false; modal.setAttribute("aria-hidden", "false"); document.body.style.overflow = "hidden"; state.opened = true;
    updateChrome();
    if (state.category === "import") await migrateLegacyOnce();
    await refreshFiles();
  }
  function closeLibrary() { if (state.busy) return; const modal = $("#logLibraryModal"); if (modal) { modal.hidden = true; modal.setAttribute("aria-hidden", "true"); } document.body.style.overflow = ""; state.renaming = ""; state.opened = false; }
  async function switchTab(category) { if (!categories[category] || category === state.category) return; state.category = category; state.previews.clear(); state.renaming = ""; updateChrome(); await refreshFiles(); }

  async function refreshFiles() {
    try {
      setStatus("폴더를 확인하는 중…");
      state.files = (await bridge().listShared(state.category)).sort((a,b) => (b.modified-a.modified) || Number(b.id)-Number(a.id));
      renderFiles();
      setStatus(state.files.length ? `${state.files.length}개 파일 · 최근 수정 순` : categories[state.category].empty);
    } catch (error) { console.error(error); state.files = []; renderFiles(); setStatus(error.message || "폴더를 읽지 못했습니다."); }
  }

  function renderFiles() {
    const list = $("#logLibraryList"); if (!list) return;
    if (!state.files.length) { list.innerHTML = `<div class="logLibraryEmpty">${esc(categories[state.category].empty)}${categories[state.category].add ? "<br>파일 추가 버튼으로 여러 개를 한 번에 넣을 수 있습니다." : ""}</div>`; return; }
    list.innerHTML = state.files.map(file => {
      const key = fileKey(file), preview = state.previews.get(key), renaming = state.renaming === key;
      return `<article class="logFileItem" data-file-id="${esc(file.id)}" data-file-category="${esc(file.category)}">
        <div class="logFileMain"><div class="logFileInfo"><div class="logFileName" title="${esc(file.name)}">${esc(file.name)}</div><div class="logFileMetaRow"><div class="logFileMeta">${formatBytes(file.size)}${file.modified ? ` · ${esc(formatDate(file.modified))}` : ""} · ${esc(categories[file.category].label)}</div></div></div>
        <div class="logFileActions"><button type="button" class="logFileAction" data-action="preview" title="마지막 약 5턴 미리보기">${preview ? "−" : "+"}</button><button type="button" class="logFileAction" data-action="load" title="발췌기에 불러오기">${icon("load")}</button><button type="button" class="logFileAction" data-action="rename" title="이름 수정">${icon("edit")}</button><button type="button" class="logFileAction danger" data-action="delete" title="삭제">${icon("trash")}</button></div></div>
        ${renaming ? `<div class="logRenameRow"><input class="logRenameInput" value="${esc(file.name)}"><button class="logRenameButton primary" data-action="rename-save">저장</button><button class="logRenameButton" data-action="rename-cancel">취소</button></div>` : ""}
        ${preview ? `<div class="logFilePreview"><div class="logFilePreviewMeta">${esc(preview.meta)}</div><pre class="logFilePreviewText">${esc(preview.text)}</pre></div>` : ""}
      </article>`;
    }).join("");
    if (state.renaming) {
      const row = Array.from(list.querySelectorAll(".logFileItem")).find(node => `${node.dataset.fileCategory}:${node.dataset.fileId}` === state.renaming);
      const input = row?.querySelector(".logRenameInput"); if (input) { input.focus(); const dot = input.value.lastIndexOf("."); input.setSelectionRange(0, dot > 0 ? dot : input.value.length); }
    }
  }

  function currentFileFromButton(button) {
    const item = button.closest(".logFileItem");
    if (!item) return null;
    return state.files.find(file => file.id === item.dataset.fileId && file.category === item.dataset.fileCategory) || null;
  }
  async function onListClick(event) {
    const button = event.target.closest("[data-action]"); if (!button || state.busy) return;
    const file = currentFileFromButton(button); if (!file) return;
    const action = button.dataset.action, key = fileKey(file);
    if (action === "preview") return togglePreview(file);
    if (action === "load") return loadSharedFile(file, { closeLibrary: true, source: "manual" });
    if (action === "rename") { state.renaming = key; renderFiles(); return; }
    if (action === "rename-cancel") { state.renaming = ""; renderFiles(); return; }
    if (action === "rename-save") return renameFile(file, button.closest(".logFileItem")?.querySelector(".logRenameInput")?.value || "");
    if (action === "delete") return deleteFile(file);
  }

  function openPicker() {
    const input = $("#logLibraryFileInput"); if (!input || state.busy || state.category !== "import") return;
    input.multiple = true; input.setAttribute("multiple", ""); input.value = "";
    try { if (typeof input.showPicker === "function") input.showPicker(); else input.click(); }
    catch (_) { input.click(); }
  }
  async function readFileBytes(file) {
    try { if (typeof readFileAsArrayBuffer === "function") return new Uint8Array(await readFileAsArrayBuffer(file)); } catch (_) {}
    return new Uint8Array(await file.arrayBuffer());
  }
  async function importFiles(files) {
    const supported = files.filter(file => ACCEPTED.test(file.name || "") || String(file.type || "").startsWith("text/") || !file.type || file.type === "application/json");
    if (!supported.length) { toast("읽을 수 있는 로그 파일을 선택해 주세요."); return; }
    setBusy(true); let done = 0, failed = 0;
    try {
      for (let i = 0; i < supported.length; i++) {
        const file = supported[i];
        try {
          setStatus(`${file.name} 읽는 중 · ${i+1}/${supported.length}`);
          const bytes = await readFileBytes(file);
          setStatus(`${file.name} 저장 중 · ${i+1}/${supported.length}`);
          await bridge().saveShared("import", bytes, safeName(file.name), file.type || mimeFor(file.name)); done++;
        } catch (error) { console.error(error); failed++; }
      }
      toast(failed ? `${done}개 추가, ${failed}개 실패했습니다.` : `${done}개 파일을 불러오기 폴더에 추가했습니다.`);
      await refreshFiles();
    } finally { setBusy(false); }
  }

  function hasBom(bytes) { if (bytes.length>=3&&bytes[0]===0xef&&bytes[1]===0xbb&&bytes[2]===0xbf) return "utf-8"; if(bytes.length>=2&&bytes[0]===0xff&&bytes[1]===0xfe)return "utf-16le"; if(bytes.length>=2&&bytes[0]===0xfe&&bytes[1]===0xff)return "utf-16be"; return ""; }
  function detectEncoding(head, tail) {
    const bom = hasBom(head); if (bom) return bom;
    const ascii = String.fromCharCode(...head.subarray(0, Math.min(head.length, 8192)));
    const match = ascii.match(/(?:charset|encoding)\s*=\s*["']?\s*([a-z0-9._-]+)/i);
    if (match && /(?:euc-?kr|cp-?949|windows-?949|ksc5601)/i.test(match[1])) return "euc-kr";
    if (match && /utf-?16le/i.test(match[1])) return "utf-16le";
    if (match && /utf-?16be/i.test(match[1])) return "utf-16be";
    try { new TextDecoder("utf-8", {fatal:true}).decode(head); new TextDecoder("utf-8", {fatal:true}).decode(tail); return "utf-8"; } catch (_) {}
    try { new TextDecoder("euc-kr").decode(new Uint8Array()); return "euc-kr"; } catch (_) { return "utf-8"; }
  }
  function decodeBytes(bytes, encoding, offset = 0) {
    let source = bytes;
    if (encoding === "utf-8" && offset > 0) {
      for (let skip=0; skip<=Math.min(4,source.length); skip++) { try { return new TextDecoder("utf-8",{fatal:true}).decode(source.subarray(skip)); } catch (_) {} }
    }
    if (encoding === "euc-kr" && offset > 0 && source.length>1) {
      const a = new TextDecoder("euc-kr").decode(source), b = new TextDecoder("euc-kr").decode(source.subarray(1));
      return (a.match(/�/g)||[]).length <= (b.match(/�/g)||[]).length ? a : b;
    }
    try { return new TextDecoder(encoding || "utf-8").decode(source).replace(/^\uFEFF/,""); }
    catch (_) { return td.decode(source).replace(/^\uFEFF/,""); }
  }
  function normalizePreviewDetailsTags(value) { return String(value||"").replace(/&lt;\s*(\/?)\s*(details\b[^&<>]*?)&gt;/gi,(_m,s,b)=>`<${s||""}${String(b||"").trim()}>`).replace(/&lt;\s*(\/?)\s*(summary\b[^&<>]*?)&gt;/gi,(_m,s,b)=>`<${s||""}${String(b||"").trim()}>`); }
  function stripFolded(value) { let text=normalizePreviewDetailsTags(value).replace(/<!--\s*rofan:[\s\S]*?-->/gi,"\n").replace(/<summary\b[^>]*>[\s\S]*?<\/summary\s*>/gi,"\n"); for(let i=0;i<12;i++){const next=text.replace(/<details\b[^>]*>[\s\S]*?<\/details\s*>/gi,"\n");if(next===text)break;text=next;} return text.replace(/<details\b[^>]*>[\s\S]*$/gi,"\n").replace(/<\/?(?:details|summary)\b[^>]*>/gi,"\n"); }
  function stripBraces(value) { const s=String(value||"");let out="",depth=0;for(let i=0;i<s.length;){if(s.startsWith("{{",i)){depth++;i+=2;continue}if(depth&&s.startsWith("}}",i)){depth--;i+=2;if(!depth)out+="\n";continue}if(!depth)out+=s[i];i++}return out; }
  function outputPreview(value) { let text=stripBraces(stripFolded(value)).replace(/<script\b[^>]*>[\s\S]*?<\/script\s*>/gi,"\n").replace(/<style\b[^>]*>[\s\S]*?<\/style\s*>/gi,"\n").replace(/<!--[\s\S]*?-->/g,"\n").replace(/<br\s*\/?\s*>/gi,"\n").replace(/<\/(?:p|div|li|tr|h[1-6]|blockquote|section|article)\s*>/gi,"\n").replace(/<li\b[^>]*>/gi,"• ").replace(/<[^>]+>/g,"").replace(/<[^>\n]*$/g,""); const box=document.createElement("textarea");box.innerHTML=text;text=box.value.replace(/\*\*(.*?)\*\*/g,"$1").replace(/__(.*?)__/g,"$1").replace(/\u00a0/g," ").replace(/[ \t]+\n/g,"\n").replace(/\n[ \t]+/g,"\n").replace(/\n{3,}/g,"\n\n").trim();const lines=text.split(/\r?\n/);return lines.length>140?lines.slice(-140).join("\n"):text; }
  function turnKey(block){const id=String(block.getAttribute?.("data-block-id")||"");const m=id.match(/^(.*?)-(?:user|bot|character)(?:-|$)/i);return m?m[1]:"";}
  function extractPreview(raw){ if(/<(?:div|article|main|section)\b/i.test(raw)){const holder=document.createElement("div");holder.innerHTML=raw;const blocks=[...holder.querySelectorAll(".rofan-block[data-owner],[data-owner][data-kind]")];if(blocks.length){const groups=[];let current=null;for(const block of blocks){const owner=(block.getAttribute("data-owner")||"").toLowerCase(),key=turnKey(block),text=outputPreview(block.innerHTML||block.textContent||"");if(!text)continue;const next=!current||(key&&current.key&&key!==current.key)||(!key&&owner==="user"&&current.parts.length&&current.seen);if(next){current={key,parts:[],seen:false};groups.push(current)}current.parts.push(text);if(["user","character","bot"].includes(owner))current.seen=true}return groups.map(g=>g.parts.join("\n\n").trim()).filter(Boolean).slice(-PREVIEW_TURNS).join("\n\n");}} const cleaned=outputPreview(raw),parts=cleaned.split(/\n{2,}/).map(v=>v.trim()).filter(Boolean);return parts.length>PREVIEW_TURNS*2?parts.slice(-PREVIEW_TURNS*2).join("\n\n"):cleaned; }

  async function readSharedRange(file, offset, length) {
    const total = Math.max(0, Math.min(Number(length) || 0, Math.max(0, (Number(file.size) || 0) - (Number(offset) || 0))));
    const parts = [];
    let done = 0;
    const CHUNK = 12288;
    while (done < total) {
      const bytes = await bridge().readShared(file.category, file.id, Number(offset) + done, Math.min(CHUNK, total - done));
      if (!bytes.length) break;
      parts.push(bytes);
      done += bytes.length;
      if (parts.length % 4 === 0) await new Promise(resolve => setTimeout(resolve, 0));
    }
    const out = new Uint8Array(done);
    let at = 0;
    for (const part of parts) { out.set(part, at); at += part.length; }
    return out;
  }

  async function togglePreview(file) {
    const key=fileKey(file); if(state.previews.has(key)){state.previews.delete(key);renderFiles();return;}
    state.previews.set(key,{meta:"정리 결과 미리보기 · 준비 중",text:"마지막 약 5턴을 가볍게 읽는 중입니다…"});renderFiles();
    try {
      const head=await readSharedRange(file,0,Math.min(PREVIEW_HEAD,file.size));
      const tailOffset=Math.max(0,file.size-PREVIEW_TAIL),tail=await readSharedRange(file,tailOffset,Math.min(PREVIEW_TAIL,file.size));
      const pref=encPrefs[key]||"auto",encoding=pref==="auto"?detectEncoding(head,tail):pref;
      const raw=decodeBytes(tail,encoding,tailOffset),text=extractPreview(raw);
      state.previews.set(key,{meta:`마지막 약 ${PREVIEW_TURNS}턴 · ${encoding.toUpperCase()} · ${formatBytes(tail.length)}만 읽음 · details/HTML/{{…}} 제거`,text:text||"(정리 후 표시할 내용 없음)"});renderFiles();
    } catch(error){console.error(error);state.previews.set(key,{meta:"미리보기 오류",text:error.message||"파일을 읽지 못했습니다."});renderFiles();}
  }

  function fileFromBytes(bytes,file){try{return new File([bytes],file.name,{type:file.mime||mimeFor(file.name),lastModified:file.modified||Date.now()});}catch(_){const blob=new Blob([bytes],{type:file.mime||mimeFor(file.name)});Object.defineProperty(blob,"name",{value:file.name});return blob;}}
  async function loadSharedFile(file, options={}) {
    setBusy(true);
    try {
      setStatus(`${file.name} 불러오는 중…`);
      const bytes=await bridge().readSharedWhole(file,(done,total)=>setStatus(`${file.name} · ${Math.min(100,Math.round(done/Math.max(1,total)*100))}%`));
      if(typeof window.loadClassicFileObject!=="function")throw new Error("원본 파일 불러오기 기능을 찾지 못했습니다.");
      const loaded=await window.loadClassicFileObject(fileFromBytes(bytes,file),{activate:true,silentSuccess:true});
      if(!loaded)throw new Error("파일 불러오기가 완료되지 않았습니다.");
      if(options.closeLibrary)closeLibrary();
      toast(`${file.name} 파일을 발췌기에 불러왔습니다.`);return true;
    }catch(error){console.error(error);toast(error.message||"파일을 불러오지 못했습니다.");return false;}
    finally{setBusy(false);if(state.opened)setStatus(`${state.files.length}개 파일 · 최근 수정 순`);}
  }
  async function renameFile(file,requested){const next=safeName(requested);if(!next||next===file.name){state.renaming="";renderFiles();return;}try{await bridge().renameShared(file.category,file.id,next);state.renaming="";state.previews.delete(fileKey(file));toast("파일 이름을 수정했습니다.");await refreshFiles();}catch(error){toast(error.message||"이름을 수정하지 못했습니다.");}}
  async function deleteFile(file){if(!confirm(`“${file.name}” 파일을 삭제하시겠습니까?\n\nDownload/로그 발췌기/${categories[file.category].folder} 폴더의 실제 파일이 삭제됩니다.`))return;try{await bridge().deleteShared(file.category,file.id);state.previews.delete(fileKey(file));toast("파일을 삭제했습니다.");await refreshFiles();}catch(error){toast(error.message||"삭제하지 못했습니다.");}}

  function b64ToBytes(value){const raw=atob(String(value||"")),out=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)out[i]=raw.charCodeAt(i);return out;}
  function b64ToText(value){return td.decode(b64ToBytes(value));}
  async function readLegacyWhole(name,size){const out=new Uint8Array(size);let offset=0;while(offset<size){const reply=nativePrompt(`__LOG_READ__\t${bridge().textArg(name)}\t${offset}\t${Math.min(3072,size-offset)}`);const tab=reply.indexOf("\t");if(tab<0)throw new Error("이전 보관함 파일 읽기 실패");const bytes=b64ToBytes(reply.slice(tab+1));if(!bytes.length)break;out.set(bytes,offset);offset+=bytes.length;await new Promise(r=>setTimeout(r,0));}return out.slice(0,offset);}
  async function migrateLegacyOnce(){if(localStorage.getItem(LEGACY_MIGRATION_KEY)==="1")return;const raw=nativePrompt("__LOG_LIST__");const legacy=String(raw||"").split("\n").filter(Boolean).map(line=>{const[n,s,m]=line.split("\t");try{return{name:b64ToText(n),size:Number(s)||0,modified:Number(m)||0}}catch(_){return null}}).filter(Boolean);if(!legacy.length){localStorage.setItem(LEGACY_MIGRATION_KEY,"1");return;}try{const existing=new Set((await bridge().listShared("import")).map(file=>file.name));let copied=0;for(const file of legacy){if(existing.has(file.name))continue;setStatus(`이전 보관함 이동 중 · ${file.name}`);const bytes=await readLegacyWhole(file.name,file.size);await bridge().saveShared("import",bytes,file.name,mimeFor(file.name));copied++;}localStorage.setItem(LEGACY_MIGRATION_KEY,"1");if(copied)toast(`이전 보관함 파일 ${copied}개를 불러오기 폴더에 복사했습니다.`);}catch(error){console.error(error);setStatus("이전 보관함 이동을 다음에 다시 시도합니다.");}}

  function hasWorkingFile(){const input=$("#inputText"),chat=$("#chatPaste");if((input?.value||"").trim())return true;if((chat?.textContent||"").trim())return true;try{if(typeof classicLoadedFileText!=="undefined"&&String(classicLoadedFileText||"").trim())return true;}catch(_){}return false;}
  async function findFileByPending(pending){const [category,id,modified]=String(pending||"").split("|");if(!["full","selected"].includes(category)||!id)return null;const files=await bridge().listShared(category);return files.find(file=>file.id===id)||files.find(file=>String(file.modified)===String(modified))||files[0]||null;}
  async function checkNewExports(){
    if(document.visibilityState==="hidden")return;
    try{
      let pending=await bridge().getConfig("pending_export","");
      let file=pending?await findFileByPending(pending):null;
      if(!file){
        const [full,selected]=await Promise.all([bridge().listShared("full"),bridge().listShared("selected")]);
        const latest=[full[0],selected[0]].filter(Boolean).sort((a,b)=>b.modified-a.modified)[0];
        const seen=localStorage.getItem(AUTO_SEEN_KEY)||"";
        if(latest&&seen&&seen!==`${latest.category}:${latest.id}:${latest.modified}`)file=latest;
        if(!seen&&latest)localStorage.setItem(AUTO_SEEN_KEY,`${latest.category}:${latest.id}:${latest.modified}`);
      }
      if(!file)return;
      const marker=`${file.category}:${file.id}:${file.modified}`;
      const accept=!hasWorkingFile()||confirm(`새로운 ${categories[file.category].label} 파일이 확인되었습니다.\n\n${file.name}\n\n기존 작업을 초기화하고 발췌 내용을 불러오시겠습니까?`);
      localStorage.setItem(AUTO_SEEN_KEY,marker);await bridge().setConfig("pending_export","");
      if(accept)await loadSharedFile(file,{closeLibrary:false,source:"auto"});
    }catch(error){console.error("new export check",error);}
  }
  window.__checkNewRofanExports=checkNewExports;
  addEventListener("focus",()=>setTimeout(checkNewExports,180));
  document.addEventListener("visibilitychange",()=>{if(document.visibilityState==="visible")setTimeout(checkNewExports,180)});

  function boot(){ if(!bridge())return; installUi(); }
  if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",boot,{once:true});else boot();
})();
