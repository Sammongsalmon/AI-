(() => {
  "use strict";
  if (window.__AILogRofanNavigationV67) return;
  window.__AILogRofanNavigationV67 = true;
  const OPEN_ROFAN = "__AI_LOG_OPEN_ROFAN_ACTIVITY__";
  let openedAt = 0, wasHiddenAfterOpen = false, checkTimer = 0;
  function openRofan(){openedAt=Date.now();try{console.log(OPEN_ROFAN)}catch(_){}}
  function scheduleNewExportCheck(delay=320){clearTimeout(checkTimer);checkTimer=setTimeout(()=>{try{window.__checkNewRofanExports?.()}catch(_){}},delay)}
  function boot(){setTimeout(openRofan,420)}
  document.addEventListener("visibilitychange",()=>{if(document.visibilityState==="hidden"){if(openedAt)wasHiddenAfterOpen=true;return}if(wasHiddenAfterOpen){wasHiddenAfterOpen=false;scheduleNewExportCheck()}});
  addEventListener("focus",()=>{if(openedAt&&Date.now()-openedAt>700)scheduleNewExportCheck(380)});
  if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",boot,{once:true});else boot();
})();
