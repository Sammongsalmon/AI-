(()=>{"use strict";
const V=79,te=new TextEncoder(),td=new TextDecoder("utf-8"),yieldUi=()=>new Promise(r=>setTimeout(r,0));
if(window.RofanNativeBridge?.__promptStableV79)return;
const b64=input=>{const b=input instanceof Uint8Array?input:new Uint8Array(input||0);let s="";for(let i=0;i<b.length;i+=12288)s+=String.fromCharCode.apply(null,b.subarray(i,Math.min(i+12288,b.length)));return btoa(s)};
const un64=value=>{const x=atob(String(value||"")),b=new Uint8Array(x.length);for(let i=0;i<x.length;i++)b[i]=x.charCodeAt(i);return b};
const t64=value=>b64(te.encode(String(value??""))),ut=value=>td.decode(un64(value));
function nativeRaw(op,args=[]){const command=[op,...args.map(v=>String(v??""))].join("\t"),raw=(window.AILogNative&&window.AILogNative.call?window.AILogNative.call(command):window.prompt("__AI_STABLE__\t"+command,""));if(raw==null)throw new Error("Android 저장 연결이 응답하지 않았습니다.");const text=String(raw),p=text.indexOf("\t"),ok=(p<0?text:text.slice(0,p))==="1",payload=p<0?"":text.slice(p+1);let bytes;try{bytes=un64(payload)}catch(_){bytes=new Uint8Array()}if(!ok)throw new Error(td.decode(bytes)||`Android ${op} 작업 실패`);return bytes}
async function call(op,args=[]){return nativeRaw(op,args)}
async function text(op,args=[]){return td.decode(nativeRaw(op,args))}
const parseShared=(s,category)=>{const a=String(s||"").split("\t");if(!a[0])return null;try{return{id:a[0],category,name:ut(a[1]||""),size:Number(a[2])||0,modified:Number(a[3])||0,mime:ut(a[4]||"")||"application/octet-stream"}}catch(_){return null}};
const parseSharedList=(s,c)=>String(s||"").split("\n").filter(Boolean).map(x=>parseShared(x,c)).filter(Boolean);
const parseFont=s=>{const a=String(s||"").split("\t");if(!a[0])return null;try{return{name:ut(a[0]),size:Number(a[1])||0,modified:Number(a[2])||0}}catch(_){return null}};
async function transfer(beginOp,writeOp,finishOp,cancelOp,beginArgs,bytes,chunkSize,progress){let id="",finished=false;try{id=await text(beginOp,beginArgs);if(!id)throw new Error("저장 세션을 만들지 못했습니다.");let offset=0,index=0;while(offset<bytes.length){const end=Math.min(bytes.length,offset+chunkSize),chunk=bytes.subarray(offset,end);await text(writeOp,[id,b64(chunk)]);offset=end;progress?.(offset,bytes.length);if((++index&7)===0)await yieldUi()}const result=await text(finishOp,[id]);finished=true;return result}catch(error){if(id&&!finished)try{await text(cancelOp,[id])}catch(_){}throw error}}
async function adaptiveTransfer(kind,beginOp,writeOp,finishOp,cancelOp,beginArgs,bytes,progress){let last;for(const size of [24576,8192,3072]){try{return await transfer(beginOp,writeOp,finishOp,cancelOp,beginArgs,bytes,size,progress)}catch(error){last=error;console.warn(kind,"transfer retry",size,error)}}throw last||new Error(`${kind} 저장 실패`)}
async function saveShared(category,input,name,mime){const bytes=input instanceof Uint8Array?input:new Uint8Array(input||0);/* 직접 브리지가 있으면 한 번에 보낸다. 조각 전송이 스크린샷 저장을 크게 느리게 만든다. */if(window.AILogNative&&window.AILogNative.call&&bytes.length<=24*1024*1024){try{const rec=text("shared_save_once",[category,t64(String(name||"")),t64(String(mime||"application/octet-stream")),bytesToBase64(bytes)]);if(rec){const r=parseShared(category,rec);if(r){r.size=bytes.length;return r}}}catch(e){console.warn("한번에 저장 실패, 조각 전송으로 전환",e)}};if(!bytes.length)throw new Error("저장할 파일이 비어 있습니다.");const raw=await adaptiveTransfer("shared","shared_begin","shared_write","shared_finish","shared_cancel",[category,t64(name),t64(mime||"application/octet-stream"),String(bytes.length)],bytes);const rec=parseShared(raw,category)||{id:"",category,name:String(name||""),size:bytes.length,modified:Date.now(),mime:mime||"application/octet-stream"};rec.size=bytes.length;return rec}
async function listShared(category){return parseSharedList(await text("shared_list",[category]),category)}
async function readShared(category,id,offset,length){return length?call("shared_read",[category,id,String(Math.max(0,+offset||0)),String(Math.min(262144,+length||0))]):new Uint8Array()}
async function readWhole(file,reader,progress){const total=Math.max(0,+file?.size||0),parts=[];let offset=0;while(offset<total){const part=await reader(offset,Math.min(262144,total-offset));if(!part.length)break;parts.push(part);offset+=part.length;progress?.(Math.min(offset,total),total);if((parts.length&3)===0)await yieldUi()}const out=new Uint8Array(offset);let p=0;for(const part of parts){out.set(part,p);p+=part.length}return out}
async function renameShared(c,id,n){await text("shared_rename",[c,id,t64(n)]);return true}
async function deleteShared(c,id){await text("shared_delete",[c,id]);return true}
async function getConfig(k,d=""){const v=await text("config_get",[t64(k)]);return v===""?d:v}
async function setConfig(k,v){await text("config_set",[t64(k),t64(v)]);return true}
async function listFonts(){return String(await text("font_list")||"").split("\n").filter(Boolean).map(parseFont).filter(Boolean).sort((a,b)=>a.name.localeCompare(b.name,"ko"))}
function repairSfnt(input){let bytes=input instanceof Uint8Array?input:new Uint8Array(input||0);if(bytes.length<32)return bytes;const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),scaler=view.getUint32(0,false);if(![0x00010000,0x4f54544f,0x74727565,0x74797031].includes(scaler))return bytes;const count=view.getUint16(4,false);if(!count||12+count*16>bytes.length)return bytes;let vhea=null,head=null;for(let i=0;i<count;i++){const p=12+i*16,tag=String.fromCharCode(bytes[p],bytes[p+1],bytes[p+2],bytes[p+3]),off=view.getUint32(p+8,false),len=view.getUint32(p+12,false);if(off+len>bytes.length)continue;if(tag==="vhea")vhea={dir:p,off,len};else if(tag==="head")head={dir:p,off,len}}if(!(vhea&&vhea.len>=4&&view.getUint32(vhea.off,false)===0x00010001))return bytes;const copy=new Uint8Array(bytes),v=new DataView(copy.buffer);v.setUint32(vhea.off,0x00010000,false);const checksum=(off,len)=>{let sum=0;for(let i=0;i<Math.ceil(len/4);i++){const p=off+i*4;let word=0;for(let j=0;j<4;j++)word=(word<<8)|(p+j<copy.length?copy[p+j]:0);sum=(sum+word)>>>0}return sum};v.setUint32(vhea.dir+4,checksum(vhea.off,vhea.len),false);if(head&&head.len>=12){v.setUint32(head.off+8,0,false);v.setUint32(head.off+8,(0xB1B0AFBA-checksum(0,copy.length))>>>0,false)}return copy}
async function saveFont(name,input,progress){const bytes=repairSfnt(input instanceof Uint8Array?input:new Uint8Array(input||0));if(!bytes.length)throw new Error("글꼴 파일이 비어 있습니다.");const raw=await adaptiveTransfer("font","font_begin","font_write","font_finish","font_cancel",[t64(name),String(bytes.length)],bytes,progress);const rec=parseFont(raw)||{name:String(name||""),size:bytes.length,modified:Date.now()};rec.size=bytes.length;return rec}
async function readFont(name,offset,length){return length?call("font_read",[t64(name),String(Math.max(0,+offset||0)),String(Math.min(262144,+length||0))]):new Uint8Array()}
async function deleteFont(name){await text("font_delete",[t64(name)]);return true}
const api={__promptStableV79:true,__stableV78:true,__stableDirectV71:true,__stableDirectV70:true,version:V,bytesToB64:b64,b64ToBytes:un64,textArg:t64,decodeText:ut,repairFontBytes:repairSfnt,call,callText:text,saveShared,listShared,readShared,readSharedWhole:(f,p)=>readWhole(f,(o,l)=>readShared(f.category,f.id,o,l),p),renameShared,deleteShared,getConfig,setConfig,listFonts,saveFont,readFont,readFontWhole:(f,p)=>readWhole(f,(o,l)=>readFont(f.name,o,l),p),deleteFont,diagnose:async()=>td.decode(nativeRaw("ping")),transport:()=>"prompt-stable"};
window.__RF_NATIVE_BRIDGE_VERSION=V;window.RofanNativeBridge=api;try{dispatchEvent(new CustomEvent("ai-log-native-bridge-ready",{detail:{version:V}}))}catch(_){ }
})();;(() => {"use strict";if (!/(^|\.)rofan\.ai$/i.test(location.hostname)) return;const AI_LOG_TOOL_VERSION = 79;if(window.__AI_LOG_TOOL_VERSION===AI_LOG_TOOL_VERSION&&window.__AI_LOG_NATIVE_TOOLS__){try{window.__aiLogRofanRefreshV38?.()}catch(_){}return}window.__AI_LOG_TOOL_VERSION=AI_LOG_TOOL_VERSION;window.__aiLogRofanToolsV38=1;const CMD_MAIN = "__AI_LOG_OPEN_EXTRACTOR__";const CMD_SETTINGS = "__AI_LOG_OPEN_SETTINGS__";const N = String.fromCharCode;const clean = value => String(value == null ? "" : value).split(N(13)).join("").split(N(160)).join(" ").trim();const escapeHtml = value => clean(value).replace(/[&<>"]/g, char => (char === "&" ? "&amp;" : char === "<" ? "&lt;" : char === ">" ? "&gt;" : "&quot;"));const safeId = value => clean(value).split("-->").join("--＞").replace(/[;"<>]/g, "_").split(N(10)).join("_").split(N(13)).join("_");const safeName = value => String(value || "download").replace(/[\\/:*?"<>|\u0000-\u001f]/g, "_").replace(/\s+/g, "_").slice(0, 160) || "download";window.__AILOG_SET_TONE__=function(tone){
  if(tone!=="dark"&&tone!=="light")return;
  if(window.__AILOG_TONE__===tone)return;
  window.__AILOG_TONE__=tone;
  ["__ailog_rangebar","__ailog_menu_back","__ailog_help_back","__ailog_masklayer"].forEach(id=>{
    const el=document.getElementById(id); if(el)el.dataset.tone=tone;
  });
};
function pageTone(){if(window.__AILOG_TONE__==="dark"||window.__AILOG_TONE__==="light")return window.__AILOG_TONE__;try{const h=document.documentElement,b=document.body;const tokens=[h?.getAttribute("data-theme"),b?.getAttribute("data-theme"),h?.className,b?.className].join(" ").toLowerCase();if(/(^|\s|[-_])dark(\s|$|[-_])/.test(tokens))return"dark";if(/(^|\s|[-_])light(\s|$|[-_])/.test(tokens))return"light"}catch(_){}return"light";}function encodeUtf8Base64(value) {const bytes = new TextEncoder().encode(String(value == null ? "" : value));let binary = "";for (let index = 0; index < bytes.length; index += 32768) {binary += String.fromCharCode(...bytes.subarray(index, index + 32768));}return btoa(binary);}function bytesToBase64(bytes) {let binary = "";for (let index = 0; index < bytes.length; index += 32768) {binary += String.fromCharCode(...bytes.subarray(index, index + 32768));}return btoa(binary);}function decodeUtf8Base64(value) {try {const binary = atob(String(value || ""));const bytes = new Uint8Array(binary.length);for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);return new TextDecoder().decode(bytes);} catch (_) { return ""; }}const nativeBridge = () => window.RofanNativeBridge;const RF_DEFAULTS = { helpEnabled: true, helpSeen: false, fontMode: "page", fontName: "" },RF_LOCAL_KEY="ai-log-rofan-web-settings-v69";function rfLocal(){try{return JSON.parse(localStorage.getItem(RF_LOCAL_KEY)||"{}")||{}}catch(_){return{}}}function saveRfLocal(){try{localStorage.setItem(RF_LOCAL_KEY,JSON.stringify(rfSettings))}catch(_){}}let rfSettings = { ...RF_DEFAULTS, ...rfLocal() };let rfFontUrl="",rfFontFace=null;let rfAppliedFontId = "";async function readRfSettings() {rfSettings={...RF_DEFAULTS,...rfSettings,...rfLocal()};const b=nativeBridge();if(!b)return rfSettings;try{const r=await Promise.allSettled([b.getConfig("font_mode",rfSettings.fontMode||"page"),b.getConfig("font_name",rfSettings.fontName||""),b.getConfig("show_help",rfSettings.helpEnabled?"1":"0"),b.getConfig("help_seen_v38",rfSettings.helpSeen?"1":"0")]);const v=(i,d)=>r[i].status==="fulfilled"?r[i].value:d;rfSettings={...rfSettings,fontMode:["page","custom"].includes(v(0,"page"))?v(0,"page"):"page",fontName:String(v(1,"")||""),helpEnabled:v(2,rfSettings.helpEnabled?"1":"0")!=="0",helpSeen:v(3,rfSettings.helpSeen?"1":"0")==="1"};saveRfLocal()}catch(e){console.warn("settings read",e)}return rfSettings;}async function writeRfSettings(next) {rfSettings={...rfSettings,...(next||{})};saveRfLocal();const b=nativeBridge();if(!b)return rfSettings;const j=[];if("helpEnabled" in(next||{}))j.push(b.setConfig("show_help",rfSettings.helpEnabled?"1":"0"));if("helpSeen" in(next||{}))j.push(b.setConfig("help_seen_v38",rfSettings.helpSeen?"1":"0"));if("fontMode" in(next||{}))j.push(b.setConfig("font_mode",rfSettings.fontMode||"page"));if("fontName" in(next||{}))j.push(b.setConfig("font_name",rfSettings.fontName||""));await Promise.allSettled(j);return rfSettings;}function fontMime(name) {const lower = String(name || "").toLowerCase();if (lower.endsWith(".woff2")) return "font/woff2";if (lower.endsWith(".otf")) return "font/otf";return "font/ttf";}function clearAppliedWebFont(){if(rfFontUrl)try{URL.revokeObjectURL(rfFontUrl)}catch(_){}if(rfFontFace)try{document.fonts.delete(rfFontFace)}catch(_){}rfFontUrl="";rfFontFace=null}let rfLastFontSerial="";async function applyWebViewFont(force=false){const b=nativeBridge();if(!b)return false;await readRfSettings();let serial="0";try{serial=await b.getConfig("font_apply_serial","0")}catch(_){}let s=document.getElementById("__ailog_webfont_style_v79");if(!s){s=document.createElement("style");s.id="__ailog_webfont_style_v79";(document.head||document.documentElement).appendChild(s)}const selector=':root,html,body,#root,#__next,body *:not(svg):not(path):not(use):not(symbol),input,textarea,button,select,option,[contenteditable="true"],*::before,*::after';if(rfSettings.fontMode==="page"){s.textContent="";clearAppliedWebFont();rfAppliedFontId="page";rfLastFontSerial=serial;return true}const name=String(rfSettings.fontName||"");if(!name)return false;const files=await b.listFonts(),file=files.find(x=>x.name===name);if(!file)throw new Error("등록한 글꼴을 찾지 못했습니다.");const id="custom:"+file.name+":"+file.size+":"+serial;if(!force&&rfAppliedFontId===id&&rfFontFace){s.textContent=selector+'{font-family:"AI_Log_Web_Custom_v79",sans-serif!important}';return true}clearAppliedWebFont();let bytes=await b.readFontWhole(file);if(b.repairFontBytes)bytes=b.repairFontBytes(bytes);const buffer=bytes.byteOffset===0&&bytes.byteLength===bytes.buffer.byteLength?bytes.buffer:bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength);let face;try{face=new FontFace("AI_Log_Web_Custom_v79",buffer);await face.load()}catch(first){const blob=new Blob([bytes],{type:fontMime(name)});rfFontUrl=URL.createObjectURL(blob);face=new FontFace("AI_Log_Web_Custom_v79",`url(${rfFontUrl})`);await face.load()}document.fonts.add(face);rfFontFace=face;s.textContent=selector+'{font-family:"AI_Log_Web_Custom_v79",sans-serif!important}svg,svg *,[class*="icon" i],[class*="icon" i]::before,[class*="icon" i]::after{font-family:inherit!important}';rfAppliedFontId=id;rfLastFontSerial=serial;return true}async function showFirstHelp(force) {let disabled=false,seen=false;try{disabled=localStorage.getItem("ai-log-help-disabled-v70")==="1";seen=localStorage.getItem("ai-log-help-seen-v70")==="1"}catch(_){}try{await readRfSettings()}catch(_){}if (document.getElementById("__ailog_help_back")) return;
if (!force && (disabled || seen || !rfSettings.helpEnabled || rfSettings.helpSeen)) return;if(!force){try{localStorage.setItem("ai-log-help-seen-v70","1")}catch(_){}await writeRfSettings({ helpSeen: true });}const back = document.createElement("div");back.id = "__ailog_help_back";back.dataset.tone=pageTone();back.innerHTML = `<section id="__ailog_help"><button type="button" id="__ailog_help_x" aria-label="닫기">✕</button><h2>상단바와 발췌 도구</h2><div class="__ailog_help_row"><b>상단바 ☰</b><span>전체 발췌·선택 발췌·스크린샷·선택 삭제 메뉴를 엽니다.</span></div><div class="__ailog_help_row"><b>상단바 ↻</b><span>현재 WebView가 보여 주는 로판AI 웹페이지 자체를 새로고침합니다.</span></div><div class="__ailog_help_row"><b>상단바 ›</b><span>로그 발췌기 화면으로 이동합니다.</span></div><div class="__ailog_help_row"><b>발췌기 상단바</b><span>WebView 복귀·테마·보관함·설정 버튼을 제공합니다.</span></div><h2>범위 지정</h2><div class="__ailog_help_row"><b>시작점·종료점</b><span>본문에서 원하는 문구를 드래그한 뒤 하단바의 시작점 설정을 누릅니다. 종료점도 같은 방법으로 지정합니다. 버튼을 다시 눌러 수정할 수 있고, 다시 눌러도 이미 잡힌 지점이 지워지지는 않습니다.</span></div><div class="__ailog_help_row"><b>발췌·삭제</b><span>범위를 정한 뒤 발췌 또는 삭제 시작을 누릅니다. 삭제는 실행 전에 대상 문단을 미리 보여 주고 한 번 더 확인합니다.</span></div><h2>스크린샷</h2><div class="__ailog_help_row"><b>가리기</b><span>감추고 싶은 부분을 드래그한 뒤 가리기를 누르면 그 자리가 표시되고, 저장된 이미지에서는 빈 곳으로 나옵니다.</span></div><div class="__ailog_help_row"><b>가리기 해제</b><span>표시된 영역을 한 번 누르면 모서리에 ✕ 가 나타납니다. 그 ✕ 를 누르면 해제됩니다.</span></div><div class="__ailog_help_row"><b>배경 %</b><span>본문 뒤에 덮이는 흰 배경의 농도입니다. 버튼을 누를 때마다 0 → 25 → 40 → 55 → 70 → 85 → 100% 로 바뀝니다.</span></div><p>이 도움말은 위젯의 사용법 도움말에서 언제든 다시 열 수 있습니다.</p><button type="button" id="__ailog_help_ok">확인</button></section>`;document.documentElement.appendChild(back);back.addEventListener("click",event=>{if(event.target===back)back.remove()});back.querySelector("#__ailog_help_ok").onclick = () => back.remove();
back.querySelector("#__ailog_help_x").onclick = () => back.remove();}function toast(message) {let element = document.getElementById("__ailog_toast");if (!element) {element = document.createElement("div");element.id = "__ailog_toast";element.style.cssText = "position:fixed;left:50%;bottom:88px;transform:translateX(-50%);z-index:2147483647;max-width:85vw;padding:10px 14px;border-radius:999px;background:rgba(20,25,32,.92);color:#fff;font:13px system-ui,sans-serif;box-shadow:0 8px 24px rgba(0,0,0,.18);pointer-events:none;transition:opacity .2s";document.documentElement.appendChild(element);}element.textContent = String(message || "");element.style.opacity = "1";clearTimeout(element.__hideTimer);element.__hideTimer = setTimeout(() => { element.style.opacity = "0"; }, 2200);}async function saveBytes(bytes, name, mime, category) {const bridge=nativeBridge();if(!bridge)throw new Error("저장 브리지가 준비되지 않았습니다.");const fileName=safeName(name);const saved=await bridge.saveShared(category,bytes,fileName,mime);return saved||{id:"",name:fileName,category,modified:Date.now(),size:bytes.length,mime};}async function saveText(text, name, category, mime = "text/html;charset=utf-8") {return saveBytes(new TextEncoder().encode(String(text)), name, mime, category);}function searchText(value) {return clean(value).replace(/[\u200b-\u200d\ufeff]/g, "").replace(/\s+/g, " ").trim();}function searchLoose(value) {return searchText(value).replace(/[*_~`>#\[\]{}]/g, "").replace(/\s+/g, " ").trim();}function splitScenes(text) {text = clean(text);const parts = [];let plainStart = 0;let cursor = 0;while (cursor < text.length) {if (text[cursor] !== "*") { cursor += 1; continue; }const mark = text.startsWith("**", cursor) ? "**" : "*";const close = text.indexOf(mark, cursor + mark.length);if (cursor > plainStart) parts.push(["normal", text.slice(plainStart, cursor)]);if (close < 0) {parts.push(["scene", text.slice(cursor + mark.length)]);plainStart = text.length;break;}parts.push(["scene", text.slice(cursor + mark.length, close)]);plainStart = close + mark.length;cursor = plainStart;}if (plainStart < text.length) parts.push(["normal", text.slice(plainStart)]);return parts.filter(part => clean(part[1]));}async function getAllData(stopAtSelection = null) {if (!location.pathname.includes("/chat/")) throw new Error("채팅방에서 실행해 주세요.");const props = window.__NEXT_DATA__?.props?.pageProps || {};const botName = object => object && (object.name || object.bot_name || object.character_name);const userName = object => object && (object.name || object.nickname || object.character_name);const id = props.chatId || props.oriChatData?.chat_id || props.chatData?.chat_id || location.pathname.split("/").filter(Boolean).pop();if (!id) throw new Error("chatId를 찾지 못했어요.");let title = clean(props.oriChatData?.chat_title || props.chatData?.chat_title || document.title || "rofan-chat").replace(/ *[|] *로판 *AI *$/i, "");const titleParts = title.split(/ +x +/i);const character = clean(props.oriChatData?.char || props.chatData?.char || botName(props.botDetail) || botName(props.oriBotDetail) ||botName(props.botData) || botName(props.oriBotData) || titleParts[0] || "캐릭터");const user = clean(props.oriChatData?.user || props.chatData?.user || userName(props.userCharacter) || userName(props.oriUserCharacter) ||userName(props.chatUser) || userName(props.userDetail) || userName(props.user) || userName(props.me) || titleParts[1] || "유저");const firstMessage = clean(props.oriBotDetail?.first_message || props.botDetail?.first_message || props.oriBotData?.first_message || props.botData?.first_message || "").split("{{char}}").join(character).split("{{user}}").join(user);const logs = [];const seen = new Set();for (let offset = 0; ; offset += 50) {toast((stopAtSelection ? "선택 범위 확인 중 · " : "로그 불러오는 중 · ") + logs.length);const response = await fetch("/api/chat/GetChatLogs", {method: "POST",credentials: "include",headers: { "Content-Type": "application/json" },body: JSON.stringify({ chatId: id, offset, limit: 50 })});if (!response.ok) throw new Error("HTTP " + response.status);const page = await response.json();if (!Array.isArray(page)) throw new Error("응답 형식 오류");for (const item of page) {const key = item.log_id || item.pk;if (key && !seen.has(key)) { seen.add(key); logs.push(item); }}if (stopAtSelection?.length === 2) {const probe = logs.slice().sort((left, right) => Number(left.pk || 0) - Number(right.pk || 0));if (findTurn(probe, stopAtSelection[0], true) >= 0 && findTurn(probe, stopAtSelection[1], false) >= 0) break;}if (page.length < 50) break;await new Promise(resolve => setTimeout(resolve, 100));}if (!logs.length && Array.isArray(props.initialChatLogs)) logs.push(...props.initialChatLogs);logs.sort((left, right) => Number(left.pk || 0) - Number(right.pk || 0));return { id, title: title || "rofan-chat", character, user, firstMessage, logs };}function createExportHtml(data, logRange) {const blocks = [];const addBlock = (blockId, owner, kind, text, emphasis) => {text = clean(text);if (!text) return;const paragraphs = text.split(N(10)).map(clean).filter(Boolean).map(line => ("<p>" + (emphasis ? "<em>" + escapeHtml(line) + "</em>" : escapeHtml(line)) + "</p>")).join("");if (paragraphs) {blocks.push('<div class="rofan-block" data-block-id="' + escapeHtml(blockId) + '" data-owner="' + owner + '" data-kind="' + kind + '">' + paragraphs + "</div>");}};const addText = (text, owner, baseId) => {let partIndex = 0;for (const [kind, part] of splitScenes(text)) {addBlock(baseId + "-" + partIndex++, owner, kind, part, kind === "scene");}};if (data.firstMessage && clean(data.firstMessage) !== clean(data.logs[0]?.bot_chat)) {addText(data.firstMessage, "character", "first-message");}let logs = data.logs;if (logRange) logs = logs.slice(logRange[0], logRange[1] + 1);logs.forEach((log, index) => {const base = safeId(log.log_id || log.pk || index);addText(log.user_chat, "user", base + "-user");addText(log.bot_chat, "character", base + "-bot");});return '<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' +escapeHtml(data.title) + '</title><style>body{max-width:760px;margin:auto;padding:24px;font:16px/1.75 system-ui,sans-serif;background:#fff;color:#17191d}.rofan-block{margin:0 0 1em}.rofan-block[data-kind="scene"]{opacity:.82;font-style:italic}h1{font-size:1.35em}</style></head><body><main data-rofan-export="GetChatLogs" data-chat-id="' +escapeHtml(data.id) + '"><h1>' + escapeHtml(data.title) + "</h1>" + blocks.join("") + "</main></body></html>";}function timestamp() {const date = new Date();const pad = number => String(number).padStart(2, "0");return date.getFullYear() + "-" + pad(date.getMonth() + 1) + "-" + pad(date.getDate()) + "_" + pad(date.getHours()) + "-" + pad(date.getMinutes()) + "-" + pad(date.getSeconds());}async function shouldAutoOpenExtractor(){const b=nativeBridge();if(!b)return true;try{return(await b.getConfig("auto_open_extractor","1"))!=="0"}catch(_){return true}}async function markPendingExtraction(file) {const bridge = nativeBridge();if (!bridge || !file) return;const category = file.category === "range" ? "selected" : file.category;await bridge.setConfig("pending_export", `${category}|${file.id || ""}|${file.modified || Date.now()}`);}async function exportAll(){try{closeMenu();toast("전체 로그를 불러오는 중…");const data=await getAllData();const saved=await saveText(createExportHtml(data),safeName(data.title)+"_"+timestamp()+".rofan.html","full");const auto=await shouldAutoOpenExtractor();if(auto)await markPendingExtraction(saved);toast("전체 범위 발췌를 저장했습니다.");if(auto)setTimeout(()=>console.log(CMD_MAIN),360)}catch(error){console.error(error);toast(error.message||String(error))}}const points = {startText: "",endText: "",startBoundary: null,endBoundary: null};function currentSelectionRange() {const selection = getSelection();if (!selection || !selection.rangeCount || !clean(selection.toString())) return null;return selection.getRangeAt(0).cloneRange();}function rememberPoint(which) {const range = currentSelectionRange();if (!range) { toast("먼저 원하는 문구를 드래그해 주세요."); return; }if (which === "start") {points.startText = searchText(range.toString()).slice(0, 160);points.startBoundary = { node: range.startContainer, offset: range.startOffset };toast("시작점을 저장했어요.");} else {points.endText = searchText(range.toString()).slice(-160);points.endBoundary = { node: range.endContainer, offset: range.endOffset };toast("종료점을 저장했어요.");}updateRangeStatus();}function compareBoundaries(left, right) {const range = document.createRange();range.setStart(left.node, left.offset);range.collapse(true);const other = document.createRange();other.setStart(right.node, right.offset);other.collapse(true);return range.compareBoundaryPoints(Range.START_TO_START, other);}function rangeFromPoints() {if (!points.startBoundary || !points.endBoundary) return currentSelectionRange();try {const range = document.createRange();const forward = compareBoundaries(points.startBoundary, points.endBoundary) <= 0;const start = forward ? points.startBoundary : points.endBoundary;const end = forward ? points.endBoundary : points.startBoundary;range.setStart(start.node, start.offset);range.setEnd(end.node, end.offset);return clean(range.toString()) ? range : null;} catch (_) {return currentSelectionRange();}}function findTurn(logs, query, fromStart) {const exact = searchText(query).slice(0, 96);const loose = searchLoose(query).slice(0, 96);if (!exact && !loose) return -1;const matches = log => [log?.user_chat, log?.bot_chat].some(value => {const text = searchText(value);if (exact && text.includes(exact)) return true;return !!loose && searchLoose(value).includes(loose);});if (fromStart) {for (let index = 0; index < logs.length; index += 1) if (matches(logs[index])) return index;} else {for (let index = logs.length - 1; index >= 0; index -= 1) if (matches(logs[index])) return index;}return -1;}function pageMetaWithoutLogs() {const props = window.__NEXT_DATA__?.props?.pageProps || {};const botName = object => object && (object.name || object.bot_name || object.character_name);const userName = object => object && (object.name || object.nickname || object.character_name);const id = props.chatId || props.oriChatData?.chat_id || props.chatData?.chat_id || location.pathname.split("/").filter(Boolean).pop() || "rofan-chat";let title = clean(props.oriChatData?.chat_title || props.chatData?.chat_title || document.title || "rofan-chat").replace(/ *[|] *로판 *AI *$/i, "");const titleParts = title.split(/ +x +/i);return {id,title: title || "rofan-chat",character: clean(props.oriChatData?.char || props.chatData?.char || botName(props.botDetail) || botName(props.oriBotDetail) || botName(props.botData) || botName(props.oriBotData) || titleParts[0] || "캐릭터"),user: clean(props.oriChatData?.user || props.chatData?.user || userName(props.userCharacter) || userName(props.oriUserCharacter) || userName(props.chatUser) || userName(props.userDetail) || userName(props.user) || userName(props.me) || titleParts[1] || "유저")};}function contentRootForTurn(node) {if (!(node instanceof Element)) return null;const direct = Array.from(node.children || []);return direct.find(child => clean(child.textContent) && !child.querySelector("button")) || node;}function domTextSegments(root) {const segments = [];const ignored = "button,svg,input,textarea,select,option,[role=button],[contenteditable=true],script,style,noscript,template";const blockTags = new Set(["P","DIV","LI","SECTION","ARTICLE","BLOCKQUOTE"]);const push = (kind, text) => {text = String(text == null ? "" : text).replace(/\r/g, "").replace(/\u00a0/g, " ");if (!text) return;const last = segments[segments.length - 1];if (last && last.kind === kind) last.text += text;else segments.push({ kind, text });};const walk = (node, scene = false) => {if (!node) return;if (node.nodeType === Node.TEXT_NODE) {if (String(node.nodeValue || "").trim()) push(scene ? "scene" : "normal", node.nodeValue);return;}if (node.nodeType !== Node.ELEMENT_NODE) return;const element = node;if (element.matches?.(ignored)) return;if (element.tagName === "BR") { push(scene ? "scene" : "normal", "\n"); return; }const nextScene = scene || element.matches?.('[data-narration="true"],i,em');for (const child of element.childNodes) walk(child, nextScene);if (blockTags.has(element.tagName)) push(nextScene ? "scene" : "normal", "\n");};walk(root, false);return segments.map(segment => ({kind: segment.kind,text: segment.text.replace(/[ \t]+\n/g, "\n").replace(/\n[ \t]+/g, "\n").replace(/\n{3,}/g, "\n\n").trim()})).filter(segment => clean(segment.text));}function selectedDomEntries(range) {const all = turnRecords();const chosen = rangeTurnRecords(range).map(record => ({ node: record.node, first: false }));if (all.length) {const firstTurn = all[0].node;const parent = firstTurn?.parentElement;if (parent) {for (const child of Array.from(parent.children)) {if (child === firstTurn) break;if (child.querySelector?.("button") || visibleTurnText(child).length < 10) continue;try { if (range.intersectsNode(child)) chosen.unshift({ node: child, first: true }); }catch (_) {}}}}const seen = new Set();return chosen.filter(entry => entry.node && !seen.has(entry.node) && seen.add(entry.node)).sort((left, right) => {if (left.node === right.node) return 0;return left.node.compareDocumentPosition(right.node) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1;});}function createDomRangeHtml(range) {const meta = pageMetaWithoutLogs();const entries = selectedDomEntries(range);if (!entries.length) throw new Error("선택 범위가 포함된 대화 턴을 찾지 못했어요.");const blocks = [];const addOwner = (node, owner, baseId) => {
  /* 원본 HTML 을 그대로 보존한다. 접힘(<details>)·<span> 등이
     텍스트로 납작해지면 발췌기에서 다시 정리할 수 없기 때문. */
  let html = "";
  try {
    const part = document.createRange();
    part.selectNodeContents(node);
    // 선택 범위와의 교집합만 남긴다
    if (part.compareBoundaryPoints(Range.START_TO_START, range) < 0) part.setStart(range.startContainer, range.startOffset);
    if (part.compareBoundaryPoints(Range.END_TO_END, range) > 0) part.setEnd(range.endContainer, range.endOffset);
    const holder = document.createElement("div");
    holder.appendChild(part.cloneContents());
    /* 화면 장치만 걷어낸다. 접힘 여닫이(<summary>)와 그 안쪽은 건드리지 않는다. */
    holder.querySelectorAll("script,style,noscript,template,svg,canvas,iframe,video,audio,input,textarea,select,option")
          .forEach(n => n.remove());
    holder.querySelectorAll("button,[role=button],[contenteditable=true]").forEach(n => {
      if (n.tagName === "SUMMARY" || n.closest("summary")) return;   // 접힘 여닫이는 남긴다
      n.remove();
    });
    /* 접힘 토큰은 펴서 담는다. 접힌 채 넘기면 발췌기가 안쪽 글을 통째로 놓친다. */
    holder.querySelectorAll("details").forEach(d => d.setAttribute("open", ""));
    /* 접힘 안쪽을 숨기던 표시를 모두 벗긴다.
       (hidden 속성 · aria-hidden · display:none · Tailwind 의 hidden/invisible 클래스) */
    holder.querySelectorAll("[hidden]").forEach(d => d.removeAttribute("hidden"));
    holder.querySelectorAll('[aria-hidden="true"]').forEach(d => d.removeAttribute("aria-hidden"));
    holder.querySelectorAll('[style*="display"],[style*="visibility"]').forEach(d => {
      const v = String(d.getAttribute("style") || "")
        .replace(/display\s*:\s*none\s*;?/gi, "")
        .replace(/visibility\s*:\s*hidden\s*;?/gi, "");
      if (v.trim()) d.setAttribute("style", v); else d.removeAttribute("style");
    });
    holder.querySelectorAll('[class]').forEach(d => {
      const kept = String(d.getAttribute("class") || "").split(/\s+/)
        .filter(c => c && !/^(hidden|invisible|sr-only|select-none)$/.test(c));
      if (kept.length) d.setAttribute("class", kept.join(" ")); else d.removeAttribute("class");
    });
    html = holder.innerHTML.trim();
  } catch (_) { html = ""; }

  if (html) {
    blocks.push(`<div class="rofan-block" data-block-id="${escapeHtml(baseId)}" data-owner="${owner}" data-kind="html">${html}</div>`);
    return;
  }
  // HTML 을 얻지 못하면 기존 방식으로 물러난다
  let idx = 0;
  for (const segment of domTextSegments(node)) {
    const paragraphs = segment.text.split(/\n+/).map(clean).filter(Boolean).map(line =>
      `<p>${segment.kind === "scene" ? `<em>${escapeHtml(line)}</em>` : escapeHtml(line)}</p>`).join("");
    if (paragraphs) blocks.push(`<div class="rofan-block" data-block-id="${escapeHtml(baseId + "-" + idx++)}" data-owner="${owner}" data-kind="${segment.kind}">${paragraphs}</div>`);
  }
};entries.forEach((entry, index) => {const base = `selected-${index}`;if (entry.first) { addOwner(entry.node, "character", base + "-first"); return; }const root = contentRootForTurn(entry.node);if (!root) return;const direct = Array.from(root.children || []).filter(child => clean(child.textContent));const userNode = direct.find(child => child.tagName === "P") || null;/* 예전에는 버튼이 하나라도 들어 있으면 캐릭터 말풍선을 통째로 버렸다.
     접힘 여닫이가 버튼인 경우 응답 전체가 사라진다. 이제 글이 가장 많은 것을 고른다. */
  const characterNode = direct.filter(child => child !== userNode)
    .sort((a, b) => clean(b.textContent).length - clean(a.textContent).length)[0] || null;if (userNode) addOwner(userNode, "user", base + "-user");if (characterNode) addOwner(characterNode, "character", base + "-bot");if (!userNode && !characterNode) addOwner(root, "character", base + "-bot");});if (!blocks.length) throw new Error("선택 범위의 대화 내용을 읽지 못했어요.");const html = '<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' +escapeHtml(meta.title) + '</title><style>body{max-width:760px;margin:auto;padding:24px;font:16px/1.75 system-ui,sans-serif;background:#fff;color:#17191d}.rofan-block{margin:0 0 1em}.rofan-block[data-kind="scene"]{opacity:.82;font-style:italic}h1{font-size:1.35em}</style></head><body><main data-rofan-export="selection-dom" data-chat-id="' +escapeHtml(meta.id) + '"><h1>' + escapeHtml(meta.title) + '</h1>' + blocks.join("") + '</main></body></html>';return { html, meta, count: entries.length };}async function exportRange(){try{if(!points.startBoundary||!points.endBoundary)throw new Error("시작점과 종료점을 모두 설정해 주세요.");const range=rangeFromPoints();if(!range)throw new Error("선택 범위를 다시 지정해 주세요.");const built=createDomRangeHtml(range);toast(`선택한 ${built.count}개 턴을 저장하는 중…`);const saved=await saveText(built.html,safeName(built.meta.title)+"_"+timestamp()+".rofan.html","selected");const auto=await shouldAutoOpenExtractor();if(auto)await markPendingExtraction(saved);toast("선택 범위 발췌를 저장했습니다.");document.getElementById("__ailog_rangebar")?.remove();if(auto)setTimeout(()=>console.log(CMD_MAIN),360)}catch(error){console.error(error);toast(error.message||String(error))}}const TRASH_PATH_HEAD = "m14.749-.3469";const TRASH_PATH_TAIL = "l4.7725.79";function compactPath(value) {return String(value || "").toLowerCase().replace(/[\s,]/g, "");}function isTurnTrashButton(button) {if (!(button instanceof Element)) return false;const label = clean(button.getAttribute("aria-label") || button.getAttribute("title") || "");if (/^(삭제|delete)$/i.test(label)) return true;return Array.from(button.querySelectorAll("path")).some(path => {const data = compactPath(path.getAttribute("d"));return data.includes(TRASH_PATH_HEAD) && data.includes(TRASH_PATH_TAIL);});}function visibleTurnText(node) {if (!(node instanceof Element)) return "";const clone = node.cloneNode(true);clone.querySelectorAll("button,svg,input,textarea,select,option,[role=button],[contenteditable=true]").forEach(element => element.remove());return clean(clone.textContent).replace(/\s+/g, " ");}function turnContainerForTrash(button) {let node = button?.parentElement || null;while (node && node !== document.body && node !== document.documentElement) {const trashCount = Array.from(node.querySelectorAll("button")).filter(isTurnTrashButton).length;const text = visibleTurnText(node);if (trashCount === 1 && text.length >= 12) return node;node = node.parentElement;}return button?.closest?.(".mt-5") || null;}function turnRecords() {const seen = new Set();const records = [];for (const button of document.querySelectorAll("button")) {if (!isTurnTrashButton(button)) continue;const node = turnContainerForTrash(button);if (!node || seen.has(node)) continue;const text = visibleTurnText(node);if (!text) continue;seen.add(node);records.push({ node, button, text });}records.sort((left, right) => {if (left.node === right.node) return 0;return left.node.compareDocumentPosition(right.node) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1;});return records;}function rangeTurnRecords(range) {return turnRecords().filter(record => {try { return range.intersectsNode(record.node); }catch (_) {return record.node.contains(range.startContainer) || record.node.contains(range.endContainer);}});}function turnExcerpt(text, fromEnd) {const value = clean(text).replace(/\s+/g, " ");if (value.length <= 170) return value;return fromEnd ? "…" + value.slice(-170) : value.slice(0, 170) + "…";}function turnFingerprint(record) {return clean(record?.text || visibleTurnText(record?.node)).replace(/\s+/g, " ");}function sameTurnText(current, expected) {const left = clean(current).replace(/\s+/g, " ");const right = clean(expected).replace(/\s+/g, " ");if (!left || !right) return false;const head = right.slice(0, Math.min(56, right.length));const tail = right.slice(-Math.min(40, right.length));return left.includes(head) && (right.length < 80 || left.includes(tail));}function confirmRangeDeletion(records) {return new Promise(resolve => {document.getElementById("__ailog_delete_back")?.remove();const back = document.createElement("div");back.id = "__ailog_delete_back";back.innerHTML = `<section id="__ailog_delete_dialog" role="dialog" aria-modal="true" aria-labelledby="__ailog_delete_title"><h2 id="__ailog_delete_title">선택 범위 삭제</h2><p class="warning">선택한 문장이 포함된 지문과 응답 턴을 모두 삭제합니다. 삭제한 내용은 되돌릴 수 없습니다.</p><div class="count">삭제 대상 <b>${records.length}개 턴</b></div><div class="preview"><span>시작</span><p>${escapeHtml(turnExcerpt(records[0]?.text || "", false))}</p></div><div class="preview"><span>종료</span><p>${escapeHtml(turnExcerpt(records[records.length - 1]?.text || "", true))}</p></div><div class="actions"><button type="button" data-delete-choice="cancel">취소</button><button type="button" class="danger" data-delete-choice="confirm">정말 삭제</button></div></section>`;document.documentElement.appendChild(back);const finish = value => { back.remove(); resolve(value); };back.addEventListener("click", event => {if (event.target === back) { finish(false); return; }const choice = event.target?.dataset?.deleteChoice;if (choice === "cancel") finish(false);else if (choice === "confirm") finish(true);});});}function showDeleteProgress(done, total) {let element = document.getElementById("__ailog_delete_progress");if (!element) {element = document.createElement("div");element.id = "__ailog_delete_progress";document.documentElement.appendChild(element);}element.textContent = `선택 범위 삭제 중 · ${done}/${total}`;}function hideDeleteProgress() {document.getElementById("__ailog_delete_progress")?.remove();}function waitForTurnChange(node, beforeCount, startIndex, beforeText, timeout = 12000) {return new Promise((resolve, reject) => {let settled = false;const finish = (ok, error) => {if (settled) return;settled = true;observer.disconnect();clearInterval(timer);clearTimeout(limit);ok ? resolve() : reject(error || new Error("삭제 완료를 확인하지 못했습니다."));};const check = () => {const records = turnRecords();if (!node.isConnected || records.length < beforeCount) { finish(true); return; }const current = records[startIndex];if (current && !sameTurnText(turnFingerprint(current), beforeText)) finish(true);};const observer = new MutationObserver(check);observer.observe(document.body || document.documentElement, { childList: true, subtree: true, characterData: true });const timer = setInterval(check, 180);const limit = setTimeout(() => finish(false, new Error("사이트의 삭제 반영을 기다리다 중단했습니다.")), timeout);check();});}async function deleteRange() {let completed = 0;let total = 0;try {const range = rangeFromPoints();if (!range || !clean(range.toString())) throw new Error("시작점과 종료점을 모두 설정해 주세요.");const selected = rangeTurnRecords(range);if (!selected.length) throw new Error("선택 문장이 포함된 삭제 가능한 응답 턴을 찾지 못했습니다.");total = selected.length;const accepted = await confirmRangeDeletion(selected);if (!accepted) return;const initial = turnRecords();const startIndex = initial.findIndex(record => record.node === selected[0].node);if (startIndex < 0) throw new Error("삭제 시작 턴의 위치를 확인하지 못했습니다.");const expected = selected.map(turnFingerprint);document.getElementById("__ailog_rangebar")?.remove();showDeleteProgress(0, total);for (let index = 0; index < total; index += 1) {const currentList = turnRecords();const current = currentList[startIndex];if (!current) throw new Error("다음 삭제 대상 턴을 찾지 못했습니다.");if (!sameTurnText(turnFingerprint(current), expected[index])) {throw new Error("화면의 대화 순서가 바뀌어 잘못된 턴을 지우지 않도록 작업을 중단했습니다.");}const trash = current.button?.isConnected ? current.button : Array.from(current.node.querySelectorAll("button")).find(isTurnTrashButton);if (!trash) throw new Error("선택한 턴의 삭제 버튼을 찾지 못했습니다.");current.node.scrollIntoView({ block: "center", behavior: "auto" });await new Promise(resolve => setTimeout(resolve, 90));const beforeCount = currentList.length;const beforeNode = current.node;const beforeText = turnFingerprint(current);const originalConfirm = window.confirm;try {window.confirm = () => true;trash.click();await waitForTurnChange(beforeNode, beforeCount, startIndex, beforeText);} finally {window.confirm = originalConfirm;}completed += 1;showDeleteProgress(completed, total);await new Promise(resolve => setTimeout(resolve, 260));}points.startText = points.endText = "";points.startBoundary = points.endBoundary = null;toast(`${completed}개 응답 턴을 삭제했습니다.`);} catch (error) {console.error(error);const prefix = completed ? `${completed}개 삭제 후 중단 · ` : "";toast(prefix + (error.message || String(error)));} finally {hideDeleteProgress();}}function parseColorAlpha(color) {if (!color) return 1;const match = color.match(/rgba?\(([^)]+)\)/i);if (!match) return 1;const parts = match[1].split(",").map(part => Number(part.trim()));return parts.length > 3 && Number.isFinite(parts[3]) ? parts[3] : 1;}function nearestBackgroundColor(node) {let element = node?.nodeType === Node.ELEMENT_NODE ? node : node?.parentElement;while (element) {const color = getComputedStyle(element).backgroundColor;if (color && color !== "transparent" && parseColorAlpha(color) > 0.02) return color;element = element.parentElement;}const bodyColor = getComputedStyle(document.body).backgroundColor;return bodyColor && bodyColor !== "transparent" ? bodyColor : "#1f2327";}function graphemeSegments(text) {if (window.Intl?.Segmenter) {return Array.from(new Intl.Segmenter(undefined, { granularity: "grapheme" }).segment(text), item => ({ segment: item.segment, index: item.index }));}const result = [];let index = 0;for (const segment of Array.from(text)) {result.push({ segment, index });index += segment.length;}return result;}const screenshotControlSelector = ["button", "[role=\"button\"]", "input", "textarea", "select", "option","svg", "canvas", "iframe", "audio", "video", "[contenteditable=\"true\"]","[aria-hidden=\"true\"]", "[aria-label*=\"삭제\"]", "[aria-label*=\"편집\"]","[aria-label*=\"위로\"]", "[aria-label*=\"아래로\"]", "[title*=\"삭제\"]","[title*=\"편집\"]", "[data-testid*=\"button\" i]", "[data-testid*=\"toolbar\" i]","[class*=\"toolbar\" i]", "[class*=\"floating\" i]","[class*=\"scroll-button\" i]", "[class*=\"action-button\" i]"].join(",");function isScreenshotControlText(node) {const parent = node?.parentElement;if (!parent) return false;try {if (parent.closest(screenshotControlSelector)) return true;} catch (_) {}const style = getComputedStyle(parent);return style.display === "none" || style.visibility === "hidden" || Number(style.opacity) <= 0.01;}function selectedGlyphs(range) {const root = range.commonAncestorContainer.nodeType === Node.TEXT_NODE ? range.commonAncestorContainer.parentNode : range.commonAncestorContainer;const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);const glyphs = [];let node;while ((node = walker.nextNode())) {if (!node.data || !range.intersectsNode(node) || isScreenshotControlText(node)) continue;let start = node === range.startContainer ? range.startOffset : 0;let end = node === range.endContainer ? range.endOffset : node.data.length;start = Math.max(0, Math.min(node.data.length, start));end = Math.max(start, Math.min(node.data.length, end));const selected = node.data.slice(start, end);if (!selected) continue;const style = getComputedStyle(node.parentElement || document.body);for (const item of graphemeSegments(selected)) {const from = start + item.index;const to = from + item.segment.length;const characterRange = document.createRange();characterRange.setStart(node, from);characterRange.setEnd(node, to);const rects = Array.from(characterRange.getClientRects()).filter(rect => rect.width > 0 || rect.height > 0);if (!rects.length) continue;const rect = rects[0];glyphs.push({text: item.segment,rect: { left: rect.left, top: rect.top, right: rect.right, bottom: rect.bottom, width: rect.width, height: rect.height },style: {color: style.color,opacity: Number(style.opacity) || 1,fontFamily: style.fontFamily,fontSize: style.fontSize,fontStyle: style.fontStyle,fontVariant: style.fontVariant,fontWeight: style.fontWeight,lineHeight: style.lineHeight,textShadow: style.textShadow}});}}return glyphs;}function findBackgroundImage(bounds) {
  /* 로판AI 배경은 <img class="absolute inset-0 w-full h-full object-cover"> 형태다.
     elementsFromPoint 는 pointer-events:none 레이어를 놓치고,
     "선택 영역을 완전히 감싸야 한다"는 조건도 너무 빡빡해 계속 실패했다.
     이제 모든 img 중 선택 영역과 가장 많이 겹치는 것을 고른다. */
  const needW = Math.max(1, bounds.right - bounds.left);
  const needH = Math.max(1, bounds.bottom - bounds.top);
  const needArea = needW * needH;
  let best = null, bestScore = 0;

  for (const el of document.querySelectorAll("img")) {
    const rect = el.getBoundingClientRect();
    if (rect.width < 160 || rect.height < 160) continue;          // 아바타·썸네일 제외
    if (!el.currentSrc && !el.src) continue;

    const ox = Math.max(0, Math.min(rect.right, bounds.right) - Math.max(rect.left, bounds.left));
    const oy = Math.max(0, Math.min(rect.bottom, bounds.bottom) - Math.max(rect.top, bounds.top));
    /* 선택이 화면보다 길면 겹치는 넓이 비율이 뚝 떨어진다.
       그래서 "선택의 45% 를 덮어야 한다"는 옛 조건이 배경을 계속 놓쳤다.
       이제 가로로 대부분을 덮고 세로로 조금이라도 겹치면 후보로 본다. */
    if (ox < needW * 0.55 || oy <= 2) continue;
    const ratio = (ox * oy) / needArea;
    const cover = (ox * oy) / Math.max(1, rect.width * rect.height);
    if (ratio < 0.06 && cover < 0.2) continue;

    const style = getComputedStyle(el);
    let score = ratio * 100 + cover * 45 + (rect.width * rect.height) / 20000;
    if (style.position === "absolute" || style.position === "fixed") score += 60;
    if ((style.objectFit || "") === "cover") score += 25;
    if (Number(style.opacity || 1) < 0.15) score -= 40;

    if (score > bestScore) { bestScore = score; best = { element: el, rect, style }; }
  }
  if (best) return best;

  // CSS background-image 도 확인 (다른 화면 대비)
  for (const el of document.querySelectorAll("body *")) {
    try {
      const st = getComputedStyle(el);
      const m = /url\((["']?)(.+?)\1\)/.exec(st.backgroundImage || "");
      if (!m) continue;
      const rect = el.getBoundingClientRect();
      if (rect.width < bounds.width * 0.7 || rect.height < 40) continue;
      return { element: el, url: m[2], rect, style: st };
    } catch (_) {}
  }
  return null;
}async function loadImageForCanvas(imageElement) {
  const el = (imageElement && typeof imageElement === "object") ? imageElement : null;
  const source = typeof imageElement === "string" ? imageElement : (el ? (el.currentSrc || el.src) : "");
  if (!source) return null;

  let lastBgError = "";
  const mimeOf = u => /\.webp(\?|$)/i.test(u) ? "image/webp"
                  : /\.png(\?|$)/i.test(u) ? "image/png"
                  : /\.gif(\?|$)/i.test(u) ? "image/gif" : "image/jpeg";

  async function fromBlob(blob) {
    const url = URL.createObjectURL(blob);
    try {
      const image = new Image();
      image.decoding = "async";
      image.src = url;
      await image.decode();
      return image;
    } finally { setTimeout(() => URL.revokeObjectURL(url), 4000); }
  }

  // 1) 앱이 대신 받아 온다. 같은 출처 blob 이라 CORS 도 캔버스 오염도 없다.
  try {
    if (window.AILogNative && window.AILogNative.call) {
      // 브리지 내부 헬퍼(call)는 이 스코프에서 안 보인다. 직접 호출한다.
      const enc = t => { const e = new TextEncoder().encode(String(t)); let x = "";
        for (let i = 0; i < e.length; i++) x += String.fromCharCode(e[i]); return btoa(x); };
      const dec = v => { const x = atob(String(v || "")); const u = new Uint8Array(x.length);
        for (let i = 0; i < x.length; i++) u[i] = x.charCodeAt(i); return u; };
      const raw = window.AILogNative.call("fetch_image\t" + enc(source));
      let bytes = null;
      if (raw != null) {
        const t = String(raw), q = t.indexOf("\t");
        if ((q < 0 ? t : t.slice(0, q)) === "1") bytes = dec(q < 0 ? "" : t.slice(q + 1));
        else console.warn("배경: 앱이 거부", new TextDecoder().decode(dec(q < 0 ? "" : t.slice(q + 1))));
      }
      if (bytes && bytes.length > 64) {
        const img = await fromBlob(new Blob([bytes], { type: mimeOf(source) }));
        if (img) return img;
      }
    }
  } catch (e) { lastBgError = "앱 경유 " + (e && e.message || e); console.warn("배경: 앱 경유 실패", e); }

  // 2) 페이지에서 직접 받아 본다
  try {
    const r = await fetch(source, { mode: "cors", credentials: "include", cache: "force-cache" });
    if (r.ok) {
      const img = await fromBlob(await r.blob());
      if (img) return img;
    }
  } catch (e) { lastBgError = lastBgError || ("fetch " + (e && e.message || e)); console.warn("배경: 페이지 fetch 실패", e); }

  // 요소를 직접 쓰면 캔버스가 오염돼 저장 자체가 실패한다. 배경을 포기하는 편이 낫다.
  toast("배경 없이 저장합니다: " + (lastBgError || "가져오기 실패"));
  return null;
}function objectPositionRatio(value) {const normalized = String(value || "50%").trim().toLowerCase();if (normalized === "left" || normalized === "top") return 0;if (normalized === "right" || normalized === "bottom") return 1;const number = parseFloat(normalized);return normalized.endsWith("%") && Number.isFinite(number) ? number / 100 : 0.5;}function drawCoverImage(context, image, info, cropLeft, cropTop) {const rect = info.rect;const style = info.style;const naturalWidth = image.naturalWidth || image.width;const naturalHeight = image.naturalHeight || image.height;if (!naturalWidth || !naturalHeight) return;const fit = style.objectFit || "fill";const position = String(style.objectPosition || "50% 50%").split(/\s+/);const px = objectPositionRatio(position[0]);const py = objectPositionRatio(position[1] || position[0]);let drawWidth = rect.width;let drawHeight = rect.height;if (fit === "cover" || fit === "contain") {const scale = fit === "cover"? Math.max(rect.width / naturalWidth, rect.height / naturalHeight): Math.min(rect.width / naturalWidth, rect.height / naturalHeight);drawWidth = naturalWidth * scale;drawHeight = naturalHeight * scale;}const x = rect.left - cropLeft + (rect.width - drawWidth) * px;const y = rect.top - cropTop + (rect.height - drawHeight) * py;context.save();context.globalAlpha = Number(style.opacity) || 1;if ("filter" in context && style.filter && style.filter !== "none") context.filter = style.filter;context.drawImage(image, x, y, drawWidth, drawHeight);context.restore();}function setTextShadow(context, textShadow) {context.shadowColor = "transparent";context.shadowBlur = 0;context.shadowOffsetX = 0;context.shadowOffsetY = 0;if (!textShadow || textShadow === "none") return;const match = textShadow.match(/(rgba?\([^)]+\)|#[0-9a-f]{3,8}|[a-z]+)\s+(-?[\d.]+)px\s+(-?[\d.]+)px(?:\s+([\d.]+)px)?/i);if (!match) return;context.shadowColor = match[1];context.shadowOffsetX = Number(match[2]) || 0;context.shadowOffsetY = Number(match[3]) || 0;context.shadowBlur = Number(match[4]) || 0;}function currentRoomTitle(){const p=window.__NEXT_DATA__?.props?.pageProps||{};return clean(p.oriChatData?.chat_title||p.chatData?.chat_title||document.title||"rofan-chat").replace(/ *[|] *로판 *AI *$/i,"")||"rofan-chat"}function pngBytes(c){return new Promise((res,rej)=>{const read=b=>{const r=new FileReader();r.onerror=()=>rej(r.error||new Error("PNG 읽기 실패"));r.onload=()=>res(new Uint8Array(r.result));r.readAsArrayBuffer(b)};if(c.toBlob)c.toBlob(b=>b?read(b):rej(new Error("PNG 생성 실패")),"image/png");else try{const q=atob(c.toDataURL("image/png").split(",")[1]),a=new Uint8Array(q.length);for(let i=0;i<q.length;i++)a[i]=q.charCodeAt(i);res(a)}catch(e){rej(e)}})}const SHOT_OV_KEY="ai-log-shot-overlay-v84";
const SHOT_KW_KEY="ai-log-shot-maskwords-v99";
const DARK_OVERLAY="#353A40";
function overlayColor(){return pageTone()==="dark"?DARK_OVERLAY:"#ffffff"}
/* 저장 형식: [{w:"단어", on:true}]. 예전 ["단어"] 형식도 그대로 읽는다. */
function maskWordEntries(){
  try{
    const raw=JSON.parse(localStorage.getItem(SHOT_KW_KEY)||"[]");
    if(!Array.isArray(raw)) return [];
    return raw.map(x=>typeof x==="string"?{w:x,on:true}:{w:String(x&&x.w||""),on:x?x.on!==false:true})
              .filter(e=>e.w);
  }catch(_){return[]}
}
function setMaskWordEntries(list){
  try{localStorage.setItem(SHOT_KW_KEY,JSON.stringify(
    (list||[]).filter(e=>e&&e.w).slice(0,40).map(e=>({w:String(e.w),on:e.on!==false}))))}catch(_){}
}
/* 실제로 가릴 때 쓰는 목록 — 켜진 것만 */
function maskWords(){return maskWordEntries().filter(e=>e.on).map(e=>e.w)}
function hitsMaskWord(t){const w=maskWords();if(!w.length)return false;const s=String(t||"").toLowerCase();return w.some(k=>k&&s.includes(String(k).toLowerCase()))}
function shotOverlay(){try{const v=parseFloat(localStorage.getItem(SHOT_OV_KEY));return Number.isFinite(v)?Math.min(1,Math.max(0,v)):0.55}catch(_){return 0.55}}
function setShotOverlay(v){try{localStorage.setItem(SHOT_OV_KEY,String(Math.min(1,Math.max(0,v))))}catch(_){}}

/* 가림 구역은 문서(페이지) 좌표로 저장한다. 화면 좌표로 두면 스크롤할 때 어긋난다. */
let maskRects=[];
const sX=()=>window.scrollX||window.pageXOffset||0;
const sY=()=>window.scrollY||window.pageYOffset||0;
function maskLayer(){
  let l=document.getElementById("__ailog_masklayer");
  if(!l){l=document.createElement("div");l.id="__ailog_masklayer";l.dataset.tone=pageTone();document.documentElement.appendChild(l)}
  return l;
}
/* rect 는 화면 좌표. 문서 좌표로 옮겨서 견준다. 여러 구역이 겹쳐도 하나만 맞으면 가려진다. */
function isMasked(rect){
  const cx=(rect.left+rect.right)/2+sX(), cy=(rect.top+rect.bottom)/2+sY();
  return maskRects.some(m=>cx>=m.left&&cx<=m.right&&cy>=m.top&&cy<=m.bottom);
}
function renderMasks(){
  const l=maskLayer(); l.innerHTML="";
  const ox=sX(), oy=sY();
  maskRects.forEach((m,i)=>{
    const d=document.createElement("div");
    d.className="__ailog_mask"+(m.auto?" auto":""); d.dataset.index=String(i);
    if(m.word) d.title="자동 가림: "+m.word;
    d.style.cssText="left:"+(m.left-ox)+"px;top:"+(m.top-oy)+"px;width:"+(m.right-m.left)+"px;height:"+(m.bottom-m.top)+"px";
    d.innerHTML='<button type="button" class="__ailog_mask_x" aria-label="가리기 해제">✕</button>';
    l.appendChild(d);
  });
}
let maskFollow=null;
function followMasks(on){
  if(on){ if(maskFollow) return;
    maskFollow=()=>{ if(maskRects.length) renderMasks() };
    addEventListener("scroll",maskFollow,{passive:true});
    addEventListener("resize",maskFollow,{passive:true});
  }else if(maskFollow){
    removeEventListener("scroll",maskFollow); removeEventListener("resize",maskFollow); maskFollow=null;
  }
}
function pushRect(r,extra){
  if(r.width<=1||r.height<=1) return false;
  maskRects.push(Object.assign({left:r.left+sX(),top:r.top+sY(),right:r.right+sX(),bottom:r.bottom+sY()},extra||{}));
  return true;
}
function addMaskFromSelection(){
  const sel=window.getSelection&&window.getSelection();
  if(!sel||sel.isCollapsed||!sel.rangeCount) return false;
  const rects=Array.from(sel.getRangeAt(0).getClientRects()).filter(r=>r.width>1&&r.height>1);
  if(!rects.length) return false;
  rects.forEach(r=>pushRect(r));
  sel.removeAllRanges(); renderMasks(); followMasks(true); return true;
}
/* 등록된 키워드 중 켜진 것을 문단에서 찾아 가림 구역을 자동으로 만든다.
   이미 만들어진 구역 위에 손으로 그린 구역을 덧입혀도 isMasked 가 OR 로 견주므로 정상 동작한다. */
function autoMaskFromWords(){
  const words=maskWords().map(w=>String(w||"").toLowerCase()).filter(Boolean);
  if(!words.length) return 0;
  maskRects=maskRects.filter(m=>!m.auto);           // 이전 자동 구역은 새로 계산한다
  const seen=new Set(maskRects.map(m=>m.left+"|"+m.top+"|"+m.right+"|"+m.bottom));
  const limitTop=-4000, limitBottom=innerHeight+4000;   // 화면 근처만 훑어 부담을 줄인다
  const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);
  let node, made=0;
  while((node=walker.nextNode())){
    if(made>=600) break;
    const data=node.data; if(!data||!data.trim()) continue;
    const parent=node.parentElement; if(!parent) continue;
    if(parent.closest("#__ailog_rangebar,#__ailog_masklayer,#__ailog_ovpop,#__ailog_menu_back,#__ailog_help_back")) continue;
    try{ if(isScreenshotControlText(node)) continue }catch(_){}
    const box=parent.getBoundingClientRect();
    if(box.bottom<limitTop||box.top>limitBottom) continue;
    const low=data.toLowerCase();
    for(const w of words){
      let from=0,i;
      while((i=low.indexOf(w,from))>=0){
        try{
          const r=document.createRange(); r.setStart(node,i); r.setEnd(node,i+w.length);
          for(const rect of Array.from(r.getClientRects())){
            const key=(rect.left+sX())+"|"+(rect.top+sY())+"|"+(rect.right+sX())+"|"+(rect.bottom+sY());
            if(seen.has(key)) continue;
            if(pushRect(rect,{auto:true,word:w})){seen.add(key);made++}
          }
        }catch(_){}
        from=i+w.length;
        if(made>=600) break;
      }
      if(made>=600) break;
    }
  }
  if(made) {renderMasks(); followMasks(true)}
  return made;
}
function clearMasks(){maskRects=[];followMasks(false);document.getElementById("__ailog_masklayer")?.remove();}
document.addEventListener("click",e=>{
  const x=e.target?.closest?.(".__ailog_mask_x");
  if(x){const box=x.closest(".__ailog_mask");const i=Number(box?.dataset?.index);
    if(Number.isFinite(i)){maskRects.splice(i,1);renderMasks()}
    e.preventDefault();e.stopPropagation();return}
  const box=e.target?.closest?.(".__ailog_mask");
  if(box){box.classList.toggle("show");e.preventDefault();e.stopPropagation()}
},true);

function openOverlaySlider(){
  document.getElementById("__ailog_ovpop")?.remove();
  const pop=document.createElement("div");
  pop.id="__ailog_ovpop"; pop.dataset.tone=pageTone();
  const cur=Math.round(shotOverlay()*100);
  pop.innerHTML='<section><h3>스크린샷 설정</h3>'
    +'<p class="hint">페이지에 이미 깔린 배경 위에 <b>덧씌우는</b> 농도입니다. '
    +'화면이 밝으면 흰색, 어두우면 짙은 회색이 얹힙니다. '
    +'<b>0%</b>는 페이지 배경 그대로 출력합니다.</p>'
    +'<div class="row"><input type="range" id="__ailog_ovrange" min="0" max="100" step="5" value="'+cur+'">'
    +'<b id="__ailog_ovval">'+cur+'%</b></div>'
    +'<h4>자동 가림 키워드</h4>'
    +'<p class="hint">저장할 때 이 단어가 들어간 글자는 자동으로 가려집니다.</p>'
    +'<div class="row"><input type="text" id="__ailog_kwin" placeholder="단어 입력 후 추가">'
    +'<button data-ov="add">추가</button></div>'
    +'<div id="__ailog_kwlist"></div>'
    +'<div class="btns"><button data-ov="cancel">취소</button><button class="primary" data-ov="save">저장</button></div></section>';
  document.documentElement.appendChild(pop);

  /* 칩은 ( ● 키워드 ✕ ) 꼴. 칩 몸통을 누르면 켜짐/꺼짐이 바뀌고, ✕ 는 목록에서 지운다. */
  let words = maskWordEntries();
  const list = pop.querySelector("#__ailog_kwlist");
  const draw = () => {
    list.innerHTML = "";
    words.forEach((e,i) => {
      const chip = document.createElement("span");
      chip.className = "__ailog_chip" + (e.on ? "" : " off");
      chip.dataset.kwToggle = String(i);
      chip.setAttribute("role","button");
      chip.setAttribute("aria-pressed", e.on ? "true" : "false");

      const open = document.createElement("i");  open.className = "paren"; open.textContent = "(";
      const dot  = document.createElement("i");  dot.className  = "dot";   dot.textContent = e.on ? "●" : "○";
      const word = document.createElement("span"); word.className = "w";   word.textContent = e.w;
      const x = document.createElement("button");
      x.type = "button"; x.textContent = "✕"; x.dataset.kw = String(i);
      x.setAttribute("aria-label", e.w + " 지우기");
      const close = document.createElement("i"); close.className = "paren"; close.textContent = ")";

      chip.append(open, dot, word, x, close);
      list.appendChild(chip);
    });
  };
  draw();

  const range=pop.querySelector("#__ailog_ovrange"), val=pop.querySelector("#__ailog_ovval");
  range.addEventListener("input",()=>{val.textContent=range.value+"%"});
  const input=pop.querySelector("#__ailog_kwin");
  const addWord=()=>{const v=(input.value||"").trim();
    if(v&&!words.some(e=>e.w===v)){words.push({w:v,on:true});draw()} input.value=""};
  input.addEventListener("keydown",e=>{if(e.key==="Enter"){e.preventDefault();addWord()}});

  pop.addEventListener("click",e=>{
    const del=e.target?.closest?.("[data-kw]")?.dataset?.kw;
    if(del!==undefined&&del!==""){words.splice(Number(del),1);draw();return}
    const tg=e.target?.closest?.("[data-kw-toggle]")?.dataset?.kwToggle;
    if(tg!==undefined&&tg!==""){const i=Number(tg);
      if(words[i]){words[i].on=!words[i].on;draw()} return}
    if(e.target===pop){pop.remove();return}
    const a=e.target?.closest?.("[data-ov]")?.dataset?.ov;
    if(a==="add"){addWord();return}
    if(a==="cancel"){pop.remove();return}
    if(a==="save"){
      setShotOverlay(Number(range.value)/100);
      setMaskWordEntries(words);
      pop.remove();
      toast("스크린샷 설정을 저장했습니다.");
    }
  });
}
async function captureSelection() {try {const range = rangeFromPoints();if (!range || !clean(range.toString())) throw new Error("시작점과 종료점을 설정하거나 문구를 드래그해 주세요.");const glyphs = selectedGlyphs(range);if (!glyphs.length) throw new Error("선택한 글자의 화면 위치를 찾지 못했어요.");let left = Infinity, top = Infinity, right = -Infinity, bottom = -Infinity;let lineHeight = 0;for (const glyph of glyphs) {left = Math.min(left, glyph.rect.left);top = Math.min(top, glyph.rect.top);right = Math.max(right, glyph.rect.right);bottom = Math.max(bottom, glyph.rect.bottom);const parsed = parseFloat(glyph.style.lineHeight);lineHeight = Math.max(lineHeight, Number.isFinite(parsed) ? parsed : glyph.rect.height);}lineHeight = Math.max(18, lineHeight || 24);const verticalPadding = lineHeight * 1.5;const horizontalPadding = lineHeight * 0.8;const cropLeft = left - horizontalPadding;const cropTop = top - verticalPadding;const cssWidth = Math.max(1, right - left + horizontalPadding * 2);const cssHeight = Math.max(1, bottom - top + verticalPadding * 2);const scale = Math.max(1, Math.min(4, (devicePixelRatio || 1) * 2, 8192 / cssWidth, 16384 / cssHeight));const canvas = document.createElement("canvas");canvas.width = Math.max(1, Math.ceil(cssWidth * scale));canvas.height = Math.max(1, Math.ceil(cssHeight * scale));const context = canvas.getContext("2d", { alpha: false });context.scale(scale, scale);context.fillStyle = nearestBackgroundColor(range.commonAncestorContainer);context.fillRect(0, 0, canvas.width / scale + 1, canvas.height / scale + 1);const imageInfo = findBackgroundImage({ left, top, right, bottom, width: right - left, height: bottom - top });if (imageInfo) {const image = await loadImageForCanvas(imageInfo.url || imageInfo.element);if (image) {
  /* 배경 사진이 캔버스 위아래로 모두 뜨면 양쪽에 번짐을 주게 되고, 두 번짐이 겹쳐 사진이 지워진다.
     그래서 사진을 가까운 쪽(위 또는 아래) 끝에 붙인 뒤 반대쪽 한 곳에만 번짐을 준다. */
  const W = canvas.width / scale, H = canvas.height / scale;
  let iTop = imageInfo.rect.top - cropTop;
  let iBot = imageInfo.rect.bottom - cropTop;
  const topGap = iTop, botGap = H - iBot;
  let shift = 0;
  if (topGap > 0.5 && botGap > 0.5) shift = (topGap <= botGap) ? -topGap : botGap;
  if (shift) { iTop += shift; iBot += shift; }

  context.save();
  if (shift) context.translate(0, shift);
  drawCoverImage(context, image, imageInfo, cropLeft, cropTop);
  context.restore();

  try{
    const edge = overlayColor();
    const rgba = (hex,a) => {const h=String(hex).replace("#","");
      const r=parseInt(h.slice(0,2),16),g=parseInt(h.slice(2,4),16),b=parseInt(h.slice(4,6),16);
      return "rgba("+r+","+g+","+b+","+a+")"};
    const imgH = Math.max(1, iBot - iTop);
    /* 번지는 폭은 사진 안쪽으로 잡는다. 사진 높이의 60% 와 캔버스 45% 를 넘지 않게 눌러 둔다. */
    const band = gap => Math.min(H * 0.45, imgH * 0.6, Math.max(28, gap));
    context.save();
    if (iBot < H - 0.5) {                       // 사진이 끝나는 지점(종료 경계) 아래가 빈다
      const w = band(H - iBot);
      const from = Math.max(0, iBot - w);
      const g1 = context.createLinearGradient(0, from, 0, iBot);
      g1.addColorStop(0, rgba(edge, 0)); g1.addColorStop(1, rgba(edge, 1));
      context.fillStyle = g1; context.fillRect(0, from, W, iBot - from);
      context.fillStyle = edge; context.fillRect(0, iBot - 0.5, W, H - iBot + 1.5);
    } else if (iTop > 0.5) {                    // 사진이 시작되는 지점(시작 경계) 위가 빈다
      const w = band(iTop);
      const to = Math.min(H, iTop + w);
      const g2 = context.createLinearGradient(0, to, 0, iTop);
      g2.addColorStop(0, rgba(edge, 0)); g2.addColorStop(1, rgba(edge, 1));
      context.fillStyle = g2; context.fillRect(0, iTop, W, to - iTop);
      context.fillStyle = edge; context.fillRect(0, -1, W, iTop + 1.5);
    }
    context.restore();
  }catch(e){console.warn("배경 경계 그라데이션", e)}
}}const __ov=shotOverlay();if(__ov>0){context.save();context.globalAlpha=__ov;context.fillStyle=overlayColor();context.fillRect(0,0,canvas.width/scale+1,canvas.height/scale+1);context.restore();}for (const glyph of glyphs) {if(isMasked(glyph.rect)) continue;const style = glyph.style;context.save();context.globalAlpha = style.opacity;context.fillStyle = style.color || "#fff";context.font = [style.fontStyle, style.fontVariant, style.fontWeight, style.fontSize, style.fontFamily].filter(Boolean).join(" ");context.textBaseline = "top";setTextShadow(context, style.textShadow);context.fillText(glyph.text, glyph.rect.left - cropLeft, glyph.rect.top - cropTop);context.restore();}const bytes=await pngBytes(canvas);if(bytes.length<8||bytes[0]!==137||bytes[1]!==80||bytes[2]!==78||bytes[3]!==71)throw new Error("PNG 바이트 검증 실패");toast("스크린샷 저장 중…");await saveBytes(bytes,safeName(currentRoomTitle())+"_"+timestamp()+".png","image/png","screenshot");toast("스크린샷을 PNG로 저장했습니다.");clearMasks();document.getElementById("__ailog_rangebar")?.remove();} catch (error) {console.error(error);toast(error.message || String(error));}}function updateRangeStatus() {const bar = document.getElementById("__ailog_rangebar");const start = bar?.querySelector('[data-point="start"]');const end = bar?.querySelector('[data-point="end"]');if (start) start.textContent = "시작 " + (points.startBoundary ? "✓" : "·");if (end) end.textContent = "종료 " + (points.endBoundary ? "✓" : "·");}function showRangeBar(mode) {closeMenu();points.startText = points.endText = "";points.startBoundary = points.endBoundary = null;document.getElementById("__ailog_rangebar")?.remove();const bar = document.createElement("div");bar.id = "__ailog_rangebar";bar.dataset.mode = mode;bar.dataset.tone = pageTone();const runLabel = mode === "shot" ? "스크린샷" : mode === "delete" ? "삭제 시작" : "발췌";const runClass = mode === "delete" ? "danger" : "primary";const shotExtra = mode === "shot"
  ? '<button data-action="mask">가리기</button><button data-action="ov" title="스크린샷 설정">\u2699</button>'
  : '';
bar.innerHTML = '<div class="__ailog_points"><span data-point="start">시작 ·</span><span data-point="end">종료 ·</span></div><button data-action="start">시작점</button><button data-action="end">종료점</button>' + (mode === "shot" ? '<i class="__ailog_break"></i>' : '') + shotExtra + '<button class="' + runClass + '" data-action="run">' + runLabel + '</button><button class="closeX" data-action="close" aria-label="닫기" title="닫기">✕</button>';document.documentElement.appendChild(bar);const closeButton = bar.querySelector('[data-action="close"]');const closeRangeBar = event => { event?.preventDefault?.(); event?.stopPropagation?.(); clearMasks(); bar.remove(); };closeButton?.addEventListener("pointerdown", closeRangeBar, { passive: false, capture: true });closeButton?.addEventListener("touchstart", closeRangeBar, { passive: false, capture: true });closeButton?.addEventListener("click", closeRangeBar, { passive: false, capture: true });bar.addEventListener("click", async event => {const action=event.target?.closest?.("[data-action]")?.dataset?.action;if (!action) return;if (action === "close") { clearMasks(); bar.remove(); return; }if (action === "start" || action === "end") { rememberPoint(action); return; }
if (action === "mask") {
  if (addMaskFromSelection()) toast("가린 영역을 추가했습니다. 표시된 부분을 눌러 ✕ 로 해제할 수 있어요.");
  else toast("가릴 부분을 먼저 드래그해 주세요.");
  return;
}
if (action === "run") {if (bar.dataset.mode === "shot") await captureSelection();else if (bar.dataset.mode === "delete") await deleteRange();else await exportRange();}});updateRangeStatus();
if (mode === "shot") {
  setTimeout(() => {
    try{
      const made = autoMaskFromWords();
      if (made) toast("등록된 키워드 " + made + "곳을 자동으로 가렸습니다. 구역을 눌러 ✕ 로 뺄 수 있어요.");
    }catch(e){console.warn("자동 가림", e)}
  }, 60);
}
toast(mode === "delete"? "삭제 범위의 시작 문장과 종료 문장을 각각 드래그해 설정하세요.": "본문을 드래그한 뒤 시작점과 종료점을 설정하세요.");}const style = document.createElement("style");style.textContent = `
#__ailog_ovpop .hint{font-size:11.5px;line-height:1.55;opacity:.78;margin:0 0 10px}
#__ailog_ovpop h4{margin:14px 0 6px;font-size:13px}
#__ailog_ovpop input[type=text]{flex:1;min-width:0;padding:7px 9px;border-radius:9px;border:1px solid rgba(120,150,170,.4);background:transparent;color:inherit;font-size:13px}
#__ailog_kwlist{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px}
.__ailog_chip{display:inline-flex;align-items:center;gap:4px;padding:3px 8px;border-radius:999px;
  border:1px solid rgba(120,150,170,.55);font-size:12px;line-height:1;cursor:pointer;user-select:none;
  background:transparent;color:inherit;transition:opacity .12s,border-color .12s,background .12s}
.__ailog_chip .paren{font-style:normal;opacity:.5;font-size:12px}
.__ailog_chip .dot{font-style:normal;font-size:10px;line-height:1;opacity:.9}
.__ailog_chip .w{font-size:12px;line-height:1}
.__ailog_chip:not(.off){border-color:rgba(91,147,171,.9);background:rgba(91,147,171,.12)}
.__ailog_chip.off{opacity:.45}
.__ailog_chip button{width:15px;height:15px;min-width:0;border:0!important;background:transparent!important;
  color:inherit;opacity:.62;font-size:10px;line-height:1;padding:0;margin:0;cursor:pointer;
  display:inline-flex;align-items:center;justify-content:center;box-shadow:none!important}
.__ailog_chip button:active{opacity:1}

#__ailog_ovpop{position:fixed;inset:0;z-index:2147483600;background:rgba(15,22,28,.45);display:flex;align-items:center;justify-content:center}
#__ailog_ovpop section{background:#fff;color:#22303a;border-radius:16px;padding:16px;width:min(300px,86vw);box-shadow:0 18px 50px rgba(0,0,0,.28)}
#__ailog_ovpop[data-tone="dark"] section{background:#1e262c;color:#e6edf2}
#__ailog_ovpop h3{margin:0 0 12px;font-size:14px}
#__ailog_ovpop .row{display:flex;align-items:center;gap:10px}
#__ailog_ovpop input[type=range]{flex:1}
#__ailog_ovpop .btns{display:flex;gap:8px;justify-content:flex-end;margin-top:14px}
#__ailog_ovpop button{padding:7px 14px;border-radius:10px;border:1px solid rgba(120,150,170,.4);background:transparent;color:inherit;font-size:13px}
#__ailog_ovpop button.primary{background:#5b93ab;border-color:#5b93ab;color:#fff}

#__ailog_rangebar{display:flex!important;flex-wrap:wrap!important;justify-content:center!important;
  align-items:center!important;gap:6px!important;padding:8px 10px!important;overflow:visible!important}
#__ailog_rangebar .__ailog_points{flex:0 0 100%!important;text-align:center!important;margin:0 0 2px!important}
#__ailog_rangebar button[data-action="end"]{margin-right:auto!important}
#__ailog_rangebar button[data-action="start"],#__ailog_rangebar button[data-action="end"]{flex:0 0 auto!important}
#__ailog_rangebar .__ailog_break{flex:0 0 100%!important;height:0!important;margin:0!important}
#__ailog_rangebar .closeX{padding:6px 8px!important}
#__ailog_rangebar button{padding:6px 6px!important;font-size:11.5px!important;white-space:nowrap!important;min-width:0!important}
#__ailog_rangebar button[data-action="mask"]{padding:6px 8px!important}
/* --- 한 줄 중앙정렬 (이전 2줄 규칙을 모두 덮는다) --- */
#__ailog_rangebar{display:flex!important;flex-wrap:nowrap!important;justify-content:center!important;
  align-items:center!important;gap:4px!important;padding:6px 8px!important;overflow:visible!important}
#__ailog_rangebar .__ailog_points{flex:0 0 auto!important;text-align:left!important;
  font-size:10.5px!important;line-height:1.2!important;margin:0 3px 0 0!important;width:auto!important}
#__ailog_rangebar .__ailog_break{display:none!important}
#__ailog_rangebar button{flex:0 1 auto!important;padding:6px 8px!important;font-size:11.5px!important;
  white-space:nowrap!important;min-width:0!important}
#__ailog_rangebar button[data-action="start"],
#__ailog_rangebar button[data-action="end"]{flex:0 1 auto!important;margin:0!important}
#__ailog_rangebar .closeX{flex:0 0 auto!important;padding:6px 7px!important;margin-left:2px!important}
#__ailog_rangebar .__ailog_points{font-size:11px!important;line-height:1.35!important;margin-right:2px!important}
#__ailog_menu h2{display:flex;align-items:center;justify-content:space-between;gap:8px}
.__ailog_qmark{width:24px;height:24px;border:0!important;background:transparent!important;color:inherit;font-size:14px;font-weight:700;line-height:1;padding:0;cursor:pointer;flex:0 0 auto}
#__ailog_help{position:relative;max-width:340px!important;max-height:70vh!important;overflow:auto!important;
  padding:16px 16px 14px!important;font-size:13px!important}
#__ailog_help h2{font-size:14.5px!important;margin:10px 0 6px!important}
#__ailog_help .__ailog_help_row{font-size:12.5px!important;margin:5px 0!important}
#__ailog_help_x{position:absolute;right:10px;top:10px;width:24px;height:24px;border:0!important;background:transparent!important;color:inherit;font-size:13px;line-height:1;padding:0;cursor:pointer}

#__ailog_masklayer{position:fixed;inset:0;z-index:2147483000;pointer-events:none}
#__ailog_masklayer .__ailog_mask{position:fixed;pointer-events:auto;border-radius:6px;
  background:rgba(120,140,155,.42);border:1px dashed rgba(90,110,125,.85);box-sizing:border-box}
#__ailog_masklayer[data-tone="dark"] .__ailog_mask{background:rgba(210,220,230,.30);border-color:rgba(225,235,245,.8)}
#__ailog_masklayer .__ailog_mask_x{display:none;position:absolute;right:-9px;top:-9px;width:22px;height:22px;
  border-radius:50%;border:0;background:#5b7684;color:#fff;font-size:12px;line-height:22px;padding:0;cursor:pointer}
#__ailog_masklayer .__ailog_mask.show .__ailog_mask_x{display:block}
#__ailog_masklayer .__ailog_mask.auto{border-style:solid;border-color:rgba(150,110,120,.85)}
#__ailog_masklayer[data-tone="dark"] .__ailog_mask.auto{border-color:rgba(240,200,205,.8)}
#__ailog_menu_back{position:fixed;inset:0;z-index:2147483646;background:rgba(12,16,20,.24);display:grid;place-items:center start;padding:46px 8px;font-family:system-ui,sans-serif;backdrop-filter:blur(2px)}#__ailog_menu{width:min(212px,72vw);border:1px solid #d5d9dd;border-radius:16px;background:rgba(246,247,248,.99);color:#26292c;box-shadow:0 8px 20px rgba(22,28,33,.16);padding:10px;backdrop-filter:blur(12px)}#__ailog_menu h2{font-size:14px;margin:2px 3px 9px}#__ailog_menu .grid{display:grid;grid-template-columns:1fr;gap:6px}#__ailog_menu button{min-height:39px;border:1px solid #d7dade;border-radius:10px;background:#fff;color:#303438;font:700 11.5px system-ui,sans-serif;padding:7px 9px;box-shadow:0 1px 4px rgba(25,31,36,.06);word-break:keep-all;text-align:left}#__ailog_menu button:active{transform:scale(.985)}#__ailog_menu button.danger{background:#f7f9fa;color:#41768a;border-color:#bcd8e2}#__ailog_menu_back[data-tone="dark"]{background:rgba(0,0,0,.34)}#__ailog_menu_back[data-tone="dark"] #__ailog_menu{background:rgba(43,45,48,.98);color:#f2f3f4;border-color:#50545a}#__ailog_menu_back[data-tone="dark"] #__ailog_menu button{background:#373a3e;color:#f3f4f5;border-color:#50545a}#__ailog_menu_back[data-tone="dark"] #__ailog_menu button.danger{color:#9bd0e1;border-color:#527b89}#__ailog_rangebar{position:fixed;left:8px;right:8px;bottom:8px;z-index:2147483646;display:grid;grid-template-columns:auto minmax(88px,1fr) minmax(88px,1fr) minmax(66px,.8fr) 42px;gap:6px;align-items:stretch;padding:8px;border:1px solid #d5d9dd;border-radius:16px;background:rgba(246,247,248,.99);box-shadow:0 8px 22px rgba(22,28,33,.16);font-family:system-ui,sans-serif}#__ailog_rangebar .__ailog_points{display:flex;flex-direction:column;justify-content:center;gap:2px;min-width:48px;padding:0 5px;color:#626b72;font-size:10px;font-weight:750;line-height:1.25;white-space:nowrap}#__ailog_rangebar button{white-space:nowrap;border:1px solid #d5d9dd;border-radius:11px;background:#fff;color:#303438;padding:9px 8px;font:700 11px system-ui,sans-serif;box-shadow:0 2px 6px rgba(22,28,33,.05)}#__ailog_rangebar button.primary{background:#67aec8;color:#fff;border-color:#67aec8}#__ailog_rangebar button.danger{background:#eef6f9;color:#386f83;border-color:#b9d6e1}#__ailog_rangebar button.closeX{min-width:42px;width:42px;padding:0;background:#fff0f2;color:#b64f5a;border-color:#e5b6bd;font-size:19px;font-weight:900;line-height:1}#__ailog_rangebar[data-tone="dark"]{background:rgba(43,45,48,.98);border-color:#50545a}#__ailog_rangebar[data-tone="dark"] .__ailog_points{color:#c3c8cc}#__ailog_rangebar[data-tone="dark"] button{background:#373a3e;color:#f3f4f5;border-color:#50545a}#__ailog_rangebar[data-tone="dark"] button.primary{background:#67aec8;color:#071217;border-color:#67aec8}#__ailog_rangebar[data-tone="dark"] button.danger{background:#34474f;color:#bce0ec;border-color:#527b89}#__ailog_delete_back{position:fixed;inset:0;z-index:2147483647;background:rgba(22,35,42,.38);display:grid;place-items:center;padding:16px;font-family:system-ui,sans-serif;backdrop-filter:blur(4px)}#__ailog_delete_dialog{width:min(430px,94vw);border:1px solid rgba(201,111,118,.38);border-radius:20px;background:rgba(250,253,254,.99);color:#263d48;box-shadow:0 12px 30px rgba(25,54,66,.20);padding:16px}#__ailog_delete_dialog h2{margin:0 0 8px;font-size:17px}#__ailog_delete_dialog .warning{margin:0 0 10px;color:#9d4e56;font-size:11.5px;line-height:1.55}#__ailog_delete_dialog .count{margin:8px 0 10px;font-size:12px;color:#45636e}#__ailog_delete_dialog .preview{display:grid;grid-template-columns:38px 1fr;gap:8px;margin:7px 0;padding:9px 10px;border:1px solid rgba(111,169,193,.24);border-radius:12px;background:#f4f9fa}#__ailog_delete_dialog .preview span{font-size:10.5px;font-weight:750;color:#45636e}#__ailog_delete_dialog .preview p{margin:0;font-size:11px;line-height:1.5;color:#627a84;max-height:5em;overflow:hidden}#__ailog_delete_dialog .actions{display:grid;grid-template-columns:1fr 1fr;gap:7px;margin-top:11px}#__ailog_delete_dialog button{min-height:41px;border:1px solid rgba(111,169,193,.30);border-radius:11px;background:#f1f7f9;color:#2d4a56;font:750 12px system-ui,sans-serif}#__ailog_delete_dialog button.danger{background:#c96f76;color:#fff;border-color:#c96f76}#__ailog_delete_progress{position:fixed;left:50%;bottom:86px;transform:translateX(-50%);z-index:2147483647;max-width:88vw;padding:10px 14px;border:1px solid rgba(201,111,118,.45);border-radius:999px;background:rgba(39,46,51,.96);color:#fff;font:750 12px/1.35 system-ui,sans-serif;box-shadow:0 7px 18px rgba(0,0,0,.18);pointer-events:none}#__ailog_help_back{position:fixed;inset:0;z-index:2147483647;background:rgba(12,16,20,.28);display:grid;place-items:center;padding:16px;font-family:system-ui,sans-serif;backdrop-filter:blur(3px)}#__ailog_help{width:min(420px,94vw);border:1px solid #d5d9dd;border-radius:20px;background:rgba(241,243,244,.98);color:#282c2f;box-shadow:0 12px 30px rgba(25,31,36,.18);padding:16px}#__ailog_help h2{margin:0 0 12px;font-size:17px}.__ailog_help_row{border:1px solid #d7dade;border-radius:12px;padding:9px 10px;margin:7px 0;background:#fff;display:grid;gap:3px}.__ailog_help_row b{font-size:12px}.__ailog_help_row span,#__ailog_help p,#__ailog_help label{font-size:11px;line-height:1.5;color:#667078}#__ailog_help label{display:flex;gap:7px;align-items:center;margin:10px 2px}#__ailog_help button{width:100%;min-height:40px;border:0;border-radius:11px;background:#67aec8;color:#fff;font:750 12px system-ui,sans-serif}#__ailog_help_back[data-tone="dark"]{background:rgba(0,0,0,.38)}#__ailog_help_back[data-tone="dark"] #__ailog_help{background:rgba(43,45,48,.98);color:#f3f4f5;border-color:#50545a}#__ailog_help_back[data-tone="dark"] .__ailog_help_row{background:#373a3e;border-color:#50545a}#__ailog_help_back[data-tone="dark"] .__ailog_help_row span,#__ailog_help_back[data-tone="dark"] #__ailog_help p,#__ailog_help_back[data-tone="dark"] #__ailog_help label{color:#c6cbd0}@media(prefers-color-scheme:dark){#__ailog_delete_dialog{background:rgba(43,45,48,.99);color:#f3f4f5;border-color:#5b4b4f}#__ailog_delete_dialog .preview{background:#373a3e;border-color:#50545a}#__ailog_delete_dialog .count,#__ailog_delete_dialog .preview span{color:#c7d9df}#__ailog_delete_dialog .preview p{color:#b8c2c7}}@media(max-width:430px){#__ailog_rangebar{grid-template-columns:auto 1fr 1fr .8fr 38px;gap:4px}#__ailog_rangebar button{font-size:9.5px;padding:8px 4px}#__ailog_rangebar .__ailog_points{min-width:42px;padding:0 2px;font-size:9px}}`;document.documentElement.appendChild(style);function closeMenu() {document.getElementById("__ailog_menu_back")?.remove();try { console.log("__RFNATIVE__\t__menu\tclosed"); } catch (_) {}}function openMenu() {closeMenu();const backdrop = document.createElement("div");backdrop.id = "__ailog_menu_back";backdrop.dataset.tone=pageTone();backdrop.innerHTML = '<section id="__ailog_menu"><h2>로그 발췌 도구<button type="button" class="__ailog_qmark" data-action="help" aria-label="사용법 도움말" title="사용법 도움말">\u24D8</button></h2><div class="grid"><button data-action="full">전체 로그 발췌</button><button data-action="range">선택 범위 발췌</button><button data-action="shot">스크린샷</button><button class="danger" data-action="delete">선택 범위 삭제</button><button data-action="ov">스크린샷 설정</button><button data-action="settings">설정으로 이동</button></div></section>';document.documentElement.appendChild(backdrop);backdrop.addEventListener("click", event => {if (event.target === backdrop) { closeMenu(); return; }const action = event.target?.closest?.("[data-action]")?.dataset?.action;if (action === "full") exportAll();else if (action === "range") showRangeBar("range");else if (action === "shot") showRangeBar("shot");else if (action === "delete") showRangeBar("delete");else if (action === "help") { closeMenu(); showFirstHelp(true); }
else if (action === "ov") { openOverlaySlider(); return; }
else if (action === "settings") console.log(CMD_SETTINGS);});}window.m=openMenu;const RF_THEME_LOCAL="ai-log-remote-theme-v70";const normColor=value=>{const m=String(value||"").trim().match(/^#?([0-9a-f]{6})$/i);return m?"#"+m[1].toLowerCase():""};const mixHex=(a,b,n)=>{const p=h=>[parseInt(h.slice(1,3),16),parseInt(h.slice(3,5),16),parseInt(h.slice(5,7),16)],x=p(a),y=p(b);return"#"+x.map((v,i)=>Math.round(v+(y[i]-v)*n).toString(16).padStart(2,"0")).join("")};async function applyRemoteTheme(){let saved={};try{saved=JSON.parse(localStorage.getItem(RF_THEME_LOCAL)||"{}")||{}}catch(_){}let accent=normColor(saved.accent)||"#5eacc8",background=normColor(saved.background)||mixHex(accent,"#ffffff",.88),auto=saved.auto!==false;const b=nativeBridge();if(b)try{const r=await Promise.allSettled([b.getConfig("extractor_theme_color",accent),b.getConfig("extractor_background_color",background),b.getConfig("extractor_background_auto",auto?"1":"0")]);if(r[0].status==="fulfilled")accent=normColor(r[0].value)||accent;if(r[2].status==="fulfilled")auto=r[2].value!=="0";if(auto)background=mixHex(accent,"#ffffff",.88);else if(r[1].status==="fulfilled")background=normColor(r[1].value)||background}catch(_){}try{localStorage.setItem(RF_THEME_LOCAL,JSON.stringify({accent,background,auto}))}catch(_){}const soft=mixHex(accent,"#ffffff",.84),muted=mixHex(accent,"#3e474c",.72);document.documentElement.style.setProperty("--ailog-accent",accent);document.documentElement.style.setProperty("--ailog-accent-soft",soft);document.documentElement.style.setProperty("--ailog-muted",muted);document.documentElement.style.setProperty("--ailog-bg",background);let s=document.getElementById("__ailog_remote_theme_v79");if(!s){s=document.createElement("style");s.id="__ailog_remote_theme_v79";(document.head||document.documentElement).appendChild(s)}s.textContent=`#__ailog_menu_back{background:rgba(20,24,27,.22)!important}#__ailog_menu_back #__ailog_menu,#__ailog_rangebar,#__ailog_help_back #__ailog_help{background:rgba(247,248,249,.99)!important;color:#292d30!important;border-color:#d4d9dc!important}#__ailog_menu button,#__ailog_rangebar button,.__ailog_help_row{background:#fff!important;color:#303438!important;border-color:#d7dade!important}#__ailog_menu button[data-action="full"],#__ailog_menu button[data-action="range"],#__ailog_rangebar button.primary,#__ailog_help button{background:${accent}!important;color:#fff!important;border-color:${accent}!important}#__ailog_menu button.danger,#__ailog_rangebar button.danger{background:${soft}!important;color:${muted}!important;border-color:color-mix(in srgb,${accent} 35%,#d7dade)!important}#__ailog_rangebar .__ailog_points,.__ailog_help_row span,#__ailog_help p,#__ailog_help label{color:${muted}!important}#__ailog_rangebar button.closeX{background:#fff0f2!important;color:#b64f5a!important;border-color:#e5b6bd!important}`;return{accent,background,auto}}async function refreshInjectedSettings(){await Promise.allSettled([window.__AI_LOG_APPLY_FONT_NOW?.(true),applyRemoteTheme()])}window.__aiLogRofanRefreshV38=refreshInjectedSettings;setTimeout(refreshInjectedSettings,650);try{document.getElementById("__ailog_edge_l")?.remove();document.getElementById("__ailog_edge_r")?.remove();delete window.__AILogEdgeInstall}catch(_){}window.__AI_LOG_APPLY_FONT_NOW=applyWebViewFont;window.__AI_LOG_FONT_V61=applyWebViewFont;window.__AI_LOG_NATIVE_ACTIONS=window.__AI_LOG_NATIVE_TOOLS__={menu:openMenu,full:()=>{closeMenu();return exportAll()},range:()=>showRangeBar("range"),shot:()=>showRangeBar("shot"),delete:()=>showRangeBar("delete"),remove:()=>showRangeBar("delete"),settings:()=>{closeMenu();try{console.log(CMD_SETTINGS)}catch(_){}},close:closeMenu,refreshFont:refreshInjectedSettings,refreshTheme:applyRemoteTheme};window.__AI_LOG_V62_MENU={open:openMenu,close:closeMenu,isOpen:()=>!!document.getElementById("__ailog_menu_back")};window.__AI_LOG_V64_OPEN_MENU=openMenu;window.__AI_LOG_TOOL_VERSION=AI_LOG_TOOL_VERSION;window.__aiLogRofanToolsV38=3;addEventListener("pageshow",()=>{refreshInjectedSettings()});addEventListener("focus",()=>{refreshInjectedSettings()});document.addEventListener("visibilitychange",()=>{if(document.visibilityState==="visible")refreshInjectedSettings()});})();                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     /*aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa*/