/* v80 — 구형 prompt 브리지를 AILogNative 로 통역한다.
   log_library_v6 / log_library_tabs_v38 / export_integrity_v20 / native_bridge 가
   아직 window.prompt("__LOG_LIST__" ...) 형태를 쓰고 있어서, 이를 가로채지 않으면
   안드로이드 기본 입력 대화상자가 그대로 뜬다. */
(()=>{"use strict";
if(window.__AI_LOG_LEGACY_SHIM_V80) return;
window.__AI_LOG_LEGACY_SHIM_V80 = true;

const realPrompt = window.prompt ? window.prompt.bind(window) : (()=>null);
const te = new TextEncoder(), td = new TextDecoder("utf-8");
const t64 = s => { const b = te.encode(String(s==null?"":s)); let x=""; for(let i=0;i<b.length;i+=0x8000) x += String.fromCharCode.apply(null, b.subarray(i, i+0x8000)); return btoa(x); };
const un64 = v => { const x = atob(String(v||"")); const b = new Uint8Array(x.length); for(let i=0;i<x.length;i++) b[i] = x.charCodeAt(i); return b; };
const ut = v => { try { return td.decode(un64(v)); } catch(_){ return ""; } };

function native(cmd){
  if(!(window.AILogNative && typeof window.AILogNative.call === "function")) return null;
  const raw = window.AILogNative.call(cmd);
  if(raw == null) return null;
  const s = String(raw), p = s.indexOf("\t");
  const ok = (p < 0 ? s : s.slice(0, p)) === "1";
  const payload = p < 0 ? "" : s.slice(p + 1);
  if(!ok) throw new Error(ut(payload) || "native failed");
  return ut(payload);
}

window.prompt = function(message, def){
  const s = String(message == null ? "" : message);
  if(!/^__[A-Z0-9_]+__/.test(s)) return realPrompt(message, def);
  const a = s.split("\t"), cmd = a[0];
  try{
    switch(cmd){
      case "__NATIVE_TOAST__":
        native("toast\t" + (a[1] || ""));
        return "1";
      case "__NATIVE_BEGIN__":
        return native(["shared_begin", "export", a[1] || "", a[2] || "", a[3] || "0"].join("\t"));
      case "__NATIVE_WRITE__":
        native(["shared_write", a[1] || "", a[2] || ""].join("\t"));
        return "1";
      case "__NATIVE_FINISH__":
        native(["shared_finish", a[1] || ""].join("\t"));
        return "1";
      case "__LOG_PATH__":
        return t64("Download/로그 발췌기/불러오기");
      case "__LOG_LIST__": {
        const raw = native("shared_list\timport") || "";
        // 신규: id \t b64name \t size \t modified \t b64mime  ->  구형: b64name \t size \t modified
        return raw.split("\n").filter(Boolean).map(line => {
          const c = line.split("\t");
          return [c[1] || "", c[2] || "0", c[3] || "0"].join("\t");
        }).join("\n");
      }
      default:
        return "";   // 알 수 없는 명령이라도 대화상자는 절대 띄우지 않는다
    }
  }catch(err){
    console.warn("legacy bridge", cmd, err);
    return "";
  }
};
})();
