(() => {
  "use strict";

  // v29: 보관함 미리보기 전용 경량 패치.
  // 기존 보관함/불러오기/내보내기 코드는 건드리지 않고,
  // 미리보기 버튼의 클릭과 끝부분 판독만 캡처한다.
  const PANEL_CLASS = "logPreviewV29";
  const HEAD_BYTES = 4096;
  const TAIL_BYTES = 49152;
  const READ_CHUNK = 3072;
  const TURN_LIMIT = 5;
  const jobs = new Map();

  const sleep = () => new Promise(resolve => setTimeout(resolve, 0));

  function utf8ToB64(value) {
    const bytes = new TextEncoder().encode(String(value == null ? "" : value));
    let binary = "";
    for (let i = 0; i < bytes.length; i += 0x8000) {
      binary += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    }
    return btoa(binary);
  }

  function b64ToBytes(value) {
    const binary = atob(String(value || ""));
    const out = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) out[i] = binary.charCodeAt(i);
    return out;
  }

  function nativePrompt(command) {
    try { return window.prompt(command, "") || ""; }
    catch (_) { return ""; }
  }

  function parseReadReply(reply) {
    const text = String(reply || "");
    const tab = text.indexOf("\t");
    if (tab < 0) throw new Error("파일 읽기 응답이 올바르지 않습니다.");
    return {
      total: Number(text.slice(0, tab)) || 0,
      bytes: b64ToBytes(text.slice(tab + 1))
    };
  }

  function findPanel(item) {
    if (!item || !item.parentNode) return null;
    let node = item.nextElementSibling;
    while (node && node.classList && node.classList.contains(PANEL_CLASS)) {
      if (String(node.dataset.previewFor || "") === String(item.dataset.logName || "")) return node;
      node = node.nextElementSibling;
    }
    return null;
  }

  function setButtonState(button, open) {
    if (!button) return;
    button.textContent = open ? "−" : "+";
    button.setAttribute("aria-expanded", open ? "true" : "false");
  }

  function createPanel(item, button) {
    const existing = findPanel(item);
    if (existing) return existing;

    const panel = document.createElement("div");
    panel.className = `logFilePreview ${PANEL_CLASS}`;
    panel.dataset.previewFor = String(item.dataset.logName || "");
    panel.setAttribute("aria-live", "polite");
    panel.style.setProperty("display", "block", "important");
    panel.style.setProperty("visibility", "visible", "important");
    panel.style.setProperty("opacity", "1", "important");
    panel.style.setProperty("height", "auto", "important");
    panel.style.setProperty("min-height", "76px", "important");
    panel.style.setProperty("max-height", "none", "important");
    panel.style.setProperty("overflow", "visible", "important");
    panel.style.setProperty("position", "relative", "important");
    panel.style.setProperty("grid-column", "1 / -1", "important");
    panel.style.setProperty("border", "1px solid var(--line)", "important");
    panel.style.setProperty("border-radius", "13px", "important");
    panel.style.setProperty("margin", "0", "important");

    const meta = document.createElement("div");
    meta.className = "logFilePreviewMeta";
    const body = document.createElement("pre");
    body.className = "logFilePreviewText";
    panel.appendChild(meta);
    panel.appendChild(body);
    item.parentNode.insertBefore(panel, item.nextSibling);
    setButtonState(button, true);
    return panel;
  }

  function updatePanel(panel, meta, text) {
    if (!panel || !panel.isConnected) return;
    const metaEl = panel.querySelector(".logFilePreviewMeta");
    const textEl = panel.querySelector(".logFilePreviewText");
    if (metaEl) metaEl.textContent = String(meta || "");
    if (textEl) textEl.textContent = String(text || "");
  }

  function closePanel(item, button) {
    const name = String(item?.dataset.logName || "");
    jobs.delete(name);
    const panel = findPanel(item);
    if (panel && panel.parentNode) panel.parentNode.removeChild(panel);
    setButtonState(button, false);
  }

  async function readRange(name, start, length, token, onProgress) {
    const chunks = [];
    let offset = Math.max(0, Number(start) || 0);
    let remaining = Math.max(0, Number(length) || 0);
    let total = 0;
    let read = 0;
    let calls = 0;

    while (remaining > 0) {
      if (jobs.get(name) !== token) throw new Error("미리보기가 취소되었습니다.");
      const requestSize = Math.min(READ_CHUNK, remaining);
      const reply = nativePrompt(`__LOG_READ__\t${utf8ToB64(name)}\t${offset}\t${requestSize}`);
      const parsed = parseReadReply(reply);
      total = parsed.total || total;
      if (!parsed.bytes.length) break;
      chunks.push(parsed.bytes);
      offset += parsed.bytes.length;
      read += parsed.bytes.length;
      remaining -= parsed.bytes.length;
      calls += 1;
      if (typeof onProgress === "function") onProgress(read, length, total);
      if (parsed.bytes.length < requestSize) break;
      if ((calls & 1) === 0) await sleep();
    }

    const merged = new Uint8Array(read);
    let cursor = 0;
    for (const chunk of chunks) {
      merged.set(chunk, cursor);
      cursor += chunk.length;
    }
    return { total, bytes: merged };
  }

  async function readSamples(name, token, onProgress) {
    const head = await readRange(name, 0, HEAD_BYTES, token, null);
    const total = head.total || head.bytes.length;
    const tailStart = Math.max(0, total - TAIL_BYTES);
    const tailLength = Math.max(0, total - tailStart);
    const tail = tailStart === 0 && head.bytes.length >= tailLength
      ? { total, bytes: head.bytes.subarray(0, tailLength) }
      : await readRange(name, tailStart, tailLength, token, onProgress);
    return { total: tail.total || total, head: head.bytes, tail: tail.bytes, tailStart };
  }

  function normalizeEncoding(value) {
    const label = String(value || "").trim().toLowerCase().replace(/_/g, "-");
    if (/^(?:utf-?8|unicode-1-1-utf-8)$/.test(label)) return "utf-8";
    if (/^(?:utf-?16le|unicodefffe)$/.test(label)) return "utf-16le";
    if (/^(?:utf-?16be|unicodefeff)$/.test(label)) return "utf-16be";
    if (/^(?:euc-?kr|cp-?949|ms-?949|windows-?949|x-windows-949|ksc5601|korean)$/.test(label)) return "euc-kr";
    return "";
  }

  function asciiProbe(bytes) {
    const limit = Math.min(bytes?.length || 0, 65536);
    let out = "";
    for (let i = 0; i < limit; i += 0x8000) {
      out += String.fromCharCode.apply(null, bytes.subarray(i, Math.min(limit, i + 0x8000)));
    }
    return out;
  }

  function detectEncoding(head, tail, name) {
    if (head.length >= 3 && head[0] === 0xef && head[1] === 0xbb && head[2] === 0xbf) return "utf-8";
    if (head.length >= 2 && head[0] === 0xff && head[1] === 0xfe) return "utf-16le";
    if (head.length >= 2 && head[0] === 0xfe && head[1] === 0xff) return "utf-16be";

    const probe = asciiProbe(head);
    const declared = /(?:charset|encoding)\s*=\s*["']?\s*([a-z0-9._-]+)/i.exec(probe);
    const normalized = normalizeEncoding(declared && declared[1]);
    if (normalized) return normalized;

    const canUtf8 = bytes => {
      for (let skip = 0; skip <= Math.min(3, bytes.length); skip++) {
        try {
          new TextDecoder("utf-8", { fatal: true }).decode(bytes.subarray(skip));
          return true;
        } catch (_) {}
      }
      return false;
    };
    if (canUtf8(head) && canUtf8(tail)) return "utf-8";
    if (/\.rofan\.html?$/i.test(String(name || ""))) return "utf-8";
    try {
      new TextDecoder("euc-kr").decode(new Uint8Array());
      return "euc-kr";
    } catch (_) {
      return "utf-8";
    }
  }

  function decodeUtf16Be(bytes) {
    const even = bytes.length - (bytes.length % 2);
    const swapped = new Uint8Array(even);
    for (let i = 0; i < even; i += 2) {
      swapped[i] = bytes[i + 1];
      swapped[i + 1] = bytes[i];
    }
    return new TextDecoder("utf-16le").decode(swapped);
  }

  function decodeTail(bytes, encoding, absoluteOffset) {
    let source = bytes || new Uint8Array();
    if ((encoding === "utf-16le" || encoding === "utf-16be") && (absoluteOffset & 1) && source.length) {
      source = source.subarray(1);
    }
    if (encoding === "utf-8" && absoluteOffset > 0) {
      for (let skip = 0; skip <= Math.min(3, source.length); skip++) {
        try {
          return new TextDecoder("utf-8", { fatal: true }).decode(source.subarray(skip)).replace(/^\uFEFF/, "");
        } catch (_) {}
      }
    }
    try {
      return new TextDecoder(encoding).decode(source).replace(/^\uFEFF/, "");
    } catch (_) {
      if (encoding === "utf-16be") return decodeUtf16Be(source).replace(/^\uFEFF/, "");
      return new TextDecoder("utf-8").decode(source).replace(/^\uFEFF/, "");
    }
  }

  function stripDoubleBraces(value) {
    const source = String(value || "");
    let out = "";
    let depth = 0;
    for (let i = 0; i < source.length;) {
      if (source.startsWith("{{", i)) {
        depth += 1;
        i += 2;
      } else if (depth > 0 && source.startsWith("}}", i)) {
        depth -= 1;
        i += 2;
        if (depth === 0) out += "\n";
      } else {
        if (depth === 0) out += source[i];
        i += 1;
      }
    }
    return out;
  }

  function cleanPreview(value) {
    let text = stripDoubleBraces(String(value || ""))
      .replace(/<details\b[^>]*>[\s\S]*?<\/details\s*>/gi, "\n")
      .replace(/<details\b[^>]*>[\s\S]*$/gi, "\n")
      .replace(/<script\b[^>]*>[\s\S]*?<\/script\s*>/gi, "\n")
      .replace(/<style\b[^>]*>[\s\S]*?<\/style\s*>/gi, "\n")
      .replace(/<!--[\s\S]*?-->/g, "\n")
      .replace(/<br\s*\/?\s*>/gi, "\n")
      .replace(/<\/(?:p|div|li|tr|h[1-6]|blockquote|section|article)\s*>/gi, "\n")
      .replace(/<li\b[^>]*>/gi, "• ")
      .replace(/<[^>]+>/g, "")
      .replace(/<[^>\n]*$/g, "");
    const box = document.createElement("textarea");
    box.innerHTML = text;
    text = box.value
      .replace(/\*\*(.*?)\*\*/g, "$1")
      .replace(/__(.*?)__/g, "$1")
      .replace(/\u00a0/g, " ")
      .replace(/[ \t]+\n/g, "\n")
      .replace(/\n[ \t]+/g, "\n")
      .replace(/\n{3,}/g, "\n\n")
      .trim();
    return text;
  }

  function turnKey(block) {
    const id = String(block.getAttribute("data-block-id") || "").trim();
    const match = id.match(/^(.*?)-(?:user|bot|character)(?:-|$)/i);
    return match ? match[1] : "";
  }

  function extractLastTurns(raw) {
    const holder = document.createElement("div");
    try { holder.innerHTML = String(raw || ""); }
    catch (_) { return cleanPreview(raw); }

    const blocks = Array.from(holder.querySelectorAll('.rofan-block[data-owner], [data-owner][data-kind]'));
    if (blocks.length) {
      const groups = [];
      let current = null;
      for (const block of blocks) {
        const owner = String(block.getAttribute("data-owner") || "").toLowerCase();
        const key = turnKey(block);
        const text = cleanPreview(block.innerHTML || block.textContent || "");
        if (!text) continue;
        const startsNew = !current
          || (key && current.key && key !== current.key)
          || (!key && owner === "user" && current.parts.length > 0 && current.seenOwner);
        if (startsNew) {
          current = { key, parts: [], seenOwner: false };
          groups.push(current);
        }
        current.parts.push(text);
        if (owner === "user" || owner === "character" || owner === "bot") current.seenOwner = true;
      }
      const completed = groups.map(group => group.parts.join("\n\n").trim()).filter(Boolean);
      if (completed.length) return completed.slice(-TURN_LIMIT).join("\n\n");
    }

    const cleaned = cleanPreview(raw);
    if (!cleaned) return "";
    const sections = cleaned.split(/\n{2,}/).map(part => part.trim()).filter(Boolean);
    return sections.length > TURN_LIMIT * 2
      ? sections.slice(-(TURN_LIMIT * 2)).join("\n\n")
      : cleaned;
  }

  function encodingLabel(value) {
    return ({
      "utf-8": "UTF-8",
      "utf-16le": "UTF-16 LE",
      "utf-16be": "UTF-16 BE",
      "euc-kr": "CP949/EUC-KR"
    })[value] || value || "자동";
  }

  async function openPreview(item, button) {
    const name = String(item.dataset.logName || "");
    if (!name) return;
    const token = {};
    jobs.set(name, token);
    const panel = createPanel(item, button);
    updatePanel(panel, "정리 결과 미리보기 · 준비 중", "맨 아래 약 5턴만 가볍게 읽는 중입니다…");

    await new Promise(resolve => {
      if (typeof requestAnimationFrame === "function") {
        requestAnimationFrame(() => requestAnimationFrame(resolve));
      } else {
        setTimeout(resolve, 0);
      }
    });
    if (jobs.get(name) !== token || !panel.isConnected) return;

    try {
      const sample = await readSamples(name, token, (read, wanted) => {
        if (jobs.get(name) !== token || !panel.isConnected) return;
        const percent = wanted ? Math.min(100, Math.round(read / wanted * 100)) : 0;
        updatePanel(panel, `정리 결과 미리보기 · 끝부분 읽는 중 ${percent}%`, "맨 아래 약 5턴만 가볍게 읽는 중입니다…");
      });
      if (jobs.get(name) !== token || !panel.isConnected) return;
      if (!sample.tail.length && sample.total > 0) throw new Error("파일 끝부분을 읽지 못했습니다.");

      const encoding = detectEncoding(sample.head, sample.tail, name);
      const raw = decodeTail(sample.tail, encoding, sample.tailStart);
      const text = extractLastTurns(raw);
      updatePanel(
        panel,
        `정리 결과 미리보기 · 마지막 약 ${TURN_LIMIT}턴 · ${encodingLabel(encoding)} · 끝부분 ${(sample.tail.length / 1024).toFixed(0)}KB만 읽음`,
        text || "(details·접힘 토큰·HTML·{{…}} 제거 후 표시할 내용 없음)"
      );
    } catch (error) {
      if (jobs.get(name) !== token || !panel.isConnected) return;
      updatePanel(
        panel,
        `정리 결과 미리보기 · 오류: ${error && error.message ? error.message : "파일 읽기 실패"}`,
        "미리보기를 불러오지 못했습니다. − 버튼으로 닫은 뒤 다시 시도해 주세요."
      );
    } finally {
      if (jobs.get(name) === token) jobs.delete(name);
    }
  }

  function handlePreviewClick(event) {
    const target = event.target && event.target.nodeType === 1 ? event.target : event.target?.parentElement;
    const button = target && target.closest ? target.closest('button[data-action="preview"]') : null;
    if (!button || !button.closest("#logLibraryList")) return;
    const item = button.closest(".logFileItem");
    if (!item) return;

    // 기존 v6 미리보기 핸들러보다 먼저 잡아 중복 실행을 막는다.
    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();

    if (findPanel(item)) closePanel(item, button);
    else void openPreview(item, button);
  }

  document.addEventListener("click", handlePreviewClick, true);
})();
