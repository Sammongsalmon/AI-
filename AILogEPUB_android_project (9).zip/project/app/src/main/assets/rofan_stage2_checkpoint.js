(() => {
  "use strict";
  if (window.__AILogRofanStage2Installed) return;
  window.__AILogRofanStage2Installed = true;

  const STORAGE_KEY = "ai-log-rofan-stage2-ui-v1";
  const DEFAULTS = { showHelp: true, autoOpenExtractor: true, accent: "#5eacc8" };
  const bridge = () => window.RofanNativeBridge || null;
  async function waitForBridge(timeout = 5000) {
    const started = Date.now();
    while (Date.now() - started < timeout) {
      const native = bridge();
      if (native?.getConfig && native?.setConfig && native?.listFonts && native?.saveFont) return native;
      await new Promise(resolve => setTimeout(resolve, 80));
    }
    throw new Error("기기 저장소 연결을 준비하지 못했습니다.");
  }
  const gearIcon = `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9.5 3.8 10 2h4l.5 1.8 1.6.9 1.8-.5 2 3.5-1.3 1.3v1.9l1.3 1.3-2 3.5-1.8-.5-1.6.9-.5 1.8h-4l-.5-1.8-1.6-.9-1.8.5-2-3.5L5.4 11V9.1L4.1 7.8l2-3.5 1.8.5z"/><circle cx="12" cy="10" r="2.6"/></svg>`;
  const closeIcon = `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 6 12 12M18 6 6 18"/></svg>`;
  const webIcon = `<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3.2 3 14.8 0 18M12 3c-3 3.2-3 14.8 0 18"/></svg>`;
  const uploadIcon = `<svg viewBox="0 0 24 24"><path d="M12 16V4m0 0-4 4m4-4 4 4M4 15v4h16v-4"/></svg>`;
  const trashIcon = `<svg viewBox="0 0 24 24"><path d="M4 7h16M9 7V4h6v3m3 0-1 13H7L6 7m4 4v5m4-5v5"/></svg>`;

  function loadState() { try { return { ...DEFAULTS, ...(JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}") || {}) }; } catch (_) { return { ...DEFAULTS }; } }
  let state = loadState();
  const saveState = () => { try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch (_) {} };
  const toast = message => { if (typeof showToast === "function") showToast(message); };
  const formatBytes = n => n < 1024 ? `${n} B` : n < 1048576 ? `${(n/1024).toFixed(1)} KB` : `${(n/1048576).toFixed(1)} MB`;

  const ACCENT_KEY = "ai-log-epub-accent-v67";
  const DEFAULT_ACCENT = "#5eacc8";
  const clamp = (n, a=0, b=1) => Math.max(a, Math.min(b, Number(n)||0));
  function normalizeHex(value){const m=String(value||"").trim().match(/^#?([0-9a-f]{6})$/i);return m?"#"+m[1].toLowerCase():"";}
  function hexRgb(hex){hex=normalizeHex(hex)||DEFAULT_ACCENT;return [parseInt(hex.slice(1,3),16),parseInt(hex.slice(3,5),16),parseInt(hex.slice(5,7),16)];}
  function rgbHex(rgb){return "#"+rgb.map(v=>Math.round(clamp(v,0,255)).toString(16).padStart(2,"0")).join("");}
  function mix(rgb,target,amount){return rgb.map((v,i)=>v+(target[i]-v)*amount);}
  function rgbHsv([r,g,b]){r/=255;g/=255;b/=255;const mx=Math.max(r,g,b),mn=Math.min(r,g,b),d=mx-mn;let h=0;if(d){if(mx===r)h=((g-b)/d)%6;else if(mx===g)h=(b-r)/d+2;else h=(r-g)/d+4;h*=60;if(h<0)h+=360;}return [h,mx?d/mx:0,mx];}
  function hsvRgb(h,s,v){h=((Number(h)||0)%360+360)%360;s=clamp(s);v=clamp(v);const c=v*s,x=c*(1-Math.abs((h/60)%2-1)),m=v-c;let r=0,g=0,b=0;if(h<60){r=c;g=x}else if(h<120){r=x;g=c}else if(h<180){g=c;b=x}else if(h<240){g=x;b=c}else if(h<300){r=x;b=c}else{r=c;b=x}return [(r+m)*255,(g+m)*255,(b+m)*255];}
  let storedAccent="";try{storedAccent=localStorage.getItem(ACCENT_KEY)||""}catch(_){}
  let accentHex = normalizeHex(storedAccent) || DEFAULT_ACCENT;
  let accentHsv = rgbHsv(hexRgb(accentHex));
  function applyAccent(hex, persist=false){hex=normalizeHex(hex)||DEFAULT_ACCENT;accentHex=hex;accentHsv=rgbHsv(hexRgb(hex));const rgb=hexRgb(hex),soft=rgbHex(mix(rgb,[255,255,255],.84)),dark=rgbHex(mix(rgb,[0,0,0],.25)),light=rgbHex(mix(rgb,[255,255,255],.18));let style=document.getElementById("rfAccentThemeV67");if(!style){style=document.createElement("style");style.id="rfAccentThemeV67";(document.head||document.documentElement).appendChild(style);}style.textContent=`:root{--accent:${hex};--accentSoft:${soft};--accent-soft:${soft};--accent-dark:${dark};--focusRing:rgba(${rgb.join(",")},.18)}html[data-theme="dark"]{--accent:${light};--accentSoft:rgba(${rgb.join(",")},.15);--accent-soft:rgba(${rgb.join(",")},.15);--accent-dark:${hex};--focusRing:rgba(${rgb.join(",")},.24)}.flowDot{background:var(--accent)!important}.btn:hover,.toggle:hover,.navIconBtn:hover,.rfS2FontOption:hover{background:var(--accentSoft)!important}`;if(persist)try{localStorage.setItem(ACCENT_KEY,hex)}catch(_){}updateAccentUi();}
  function updateAccentUi(){const sw=document.getElementById("rfAccentSwatch"),hex=document.getElementById("rfAccentHex"),sv=document.getElementById("rfAccentSV"),dot=document.getElementById("rfAccentDot"),hue=document.getElementById("rfAccentHue");if(sw)sw.style.background=accentHex;if(hex&&document.activeElement!==hex)hex.value=accentHex;if(sv)sv.style.setProperty("--rfHue",accentHsv[0]);if(dot){dot.style.left=`${accentHsv[1]*100}%`;dot.style.top=`${(1-accentHsv[2])*100}%`;}if(hue)hue.value=String(Math.round(accentHsv[0]));}
  function setAccentHsv(h,s,v,persist=false){accentHsv=[h,clamp(s),clamp(v)];applyAccent(rgbHex(hsvRgb(...accentHsv)),persist);}
  applyAccent(accentHex,false);

  function installStyle() {
    if (document.getElementById("rfStage2Style")) return;
    const style = document.createElement("style");
    style.id = "rfStage2Style";
    style.textContent = `
      .heroTools{gap:4px!important}.heroTools .themeIconButton{box-shadow:0 2px 6px rgba(25,54,66,.075)!important}.heroTools #themeToggleButton,.heroTools #logLibraryButton,.heroTools #rofanSettingsButton{order:0}
      #rofanSettingsButton svg,#logLibraryButton svg{width:17px;height:17px;fill:none;stroke:currentColor;stroke-width:1.65;stroke-linecap:round;stroke-linejoin:round}
      .rfS2Modal[hidden]{display:none!important}.rfS2Modal{position:fixed;inset:0;z-index:2147483000;background:rgba(31,48,56,.27);backdrop-filter:blur(3px);display:grid;place-items:center;padding:12px}
      .rfS2Dialog{width:min(720px,100%);max-height:min(92vh,900px);overflow:auto;border:1px solid var(--line);border-radius:18px;background:var(--paper);color:var(--ink);box-shadow:0 15px 42px rgba(26,53,65,.18);padding:14px}
      .rfS2Head{display:flex;align-items:center;gap:10px;padding:2px 1px 11px}.rfS2HeadText{flex:1;min-width:0}.rfS2Title{font-size:17px;font-weight:820;letter-spacing:-.025em}.rfS2Sub{font-size:10.5px;color:var(--muted);margin-top:3px;line-height:1.48}
      .rfS2Close{width:34px;height:34px;border:1px solid var(--line);border-radius:10px;background:var(--paper2);color:var(--sub);display:grid;place-items:center;cursor:pointer}.rfS2Close svg{width:17px;height:17px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round}
      .rfS2Notice{border:1px solid color-mix(in srgb,var(--accent) 34%,var(--line));border-radius:12px;background:color-mix(in srgb,var(--accent-soft) 60%,var(--paper));padding:9px 10px;font-size:10.5px;line-height:1.55;color:var(--sub);margin-bottom:9px}
      .rfS2Grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px}.rfS2Section{border:1px solid var(--line);border-radius:14px;background:var(--paper2);padding:11px;min-width:0}.rfS2Section.wide{grid-column:1/-1}.rfS2SectionTitle{font-size:12.5px;font-weight:790;color:var(--ink);margin-bottom:7px}.rfS2Help{font-size:10px;line-height:1.5;color:var(--muted);margin-top:6px}
      .rfS2Row{display:flex;align-items:center;gap:7px;flex-wrap:wrap}.rfS2Row+.rfS2Row{margin-top:7px}.rfS2Grow{flex:1;min-width:140px}.rfS2Input,.rfS2Select{height:34px;border:1px solid var(--line);border-radius:9px;background:var(--inputBg);color:var(--ink);padding:6px 8px;font:inherit;font-size:11px;min-width:0}.rfS2Input{flex:1}.rfS2Select{max-width:100%}.rfS2Button{min-height:34px;border:1px solid var(--line);border-radius:9px;background:var(--paper);color:var(--sub);padding:6px 10px;font:inherit;font-size:10.5px;font-weight:730;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;gap:5px;white-space:nowrap}.rfS2Button.primary{background:var(--accent);border-color:var(--accent);color:#fff}.rfS2Button.danger{color:var(--red)}.rfS2Button svg{width:15px;height:15px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}
      .rfS2Toggle{display:inline-flex;align-items:center;gap:7px;font-size:11px;color:var(--sub);font-weight:690}.rfS2Toggle input{width:16px;height:16px;accent-color:var(--accent)}
      .rfAccentLine{display:flex;align-items:center;gap:7px;flex-wrap:wrap}.rfAccentSwatch{width:42px;height:34px;border:1px solid var(--line);border-radius:10px;box-shadow:inset 0 0 0 3px var(--paper);cursor:pointer}.rfAccentHex{width:98px;flex:0 0 auto}.rfAccentPicker[hidden]{display:none!important}.rfAccentPicker{margin-top:8px;padding:9px;border:1px solid var(--line);border-radius:12px;background:var(--paper)}.rfAccentSV{--rfHue:195;position:relative;width:100%;height:150px;border-radius:10px;overflow:hidden;touch-action:none;background:linear-gradient(to top,#000,transparent),linear-gradient(to right,#fff,hsl(var(--rfHue),100%,50%));box-shadow:inset 0 0 0 1px rgba(0,0,0,.12)}.rfAccentDot{position:absolute;width:15px;height:15px;border:2px solid #fff;border-radius:50%;transform:translate(-50%,-50%);box-shadow:0 0 0 1px rgba(0,0,0,.55),0 1px 4px rgba(0,0,0,.25);pointer-events:none}.rfAccentHue{width:100%;height:18px;margin-top:8px;accent-color:var(--accent);background:linear-gradient(90deg,#f00,#ff0,#0f0,#0ff,#00f,#f0f,#f00);border-radius:999px}
      .rfS2Status{font-size:9.5px;color:var(--muted);min-height:1.4em}.rfS2Footer{display:flex;justify-content:flex-end;gap:7px;padding-top:11px}
      .rfS2FontPicker{position:relative;flex:1;min-width:220px}.rfS2FontChoiceButton{width:100%;height:34px;border:1px solid var(--line);border-radius:9px;background:var(--inputBg);color:var(--ink);padding:6px 9px;font:inherit;font-size:11px;display:flex;align-items:center;justify-content:space-between;gap:8px;text-align:left}.rfS2FontChoiceButton svg{width:14px;height:14px;fill:none;stroke:currentColor;stroke-width:1.8;transition:transform .16s}.rfS2FontChoiceButton[aria-expanded="true"] svg{transform:rotate(180deg)}.rfS2FontMenu[hidden]{display:none!important}.rfS2FontMenu{position:absolute;left:0;right:0;top:calc(100% + 5px);z-index:15;max-height:230px;overflow:auto;padding:5px;border:1px solid var(--line);border-radius:11px;background:var(--paper);box-shadow:0 10px 24px rgba(25,54,66,.16)}.rfS2FontOption{width:100%;min-height:34px;border:0;border-radius:8px;background:transparent;color:var(--ink);padding:7px 8px;font:inherit;font-size:10.8px;text-align:left;display:flex;align-items:center;justify-content:space-between;gap:8px}.rfS2FontOption small{color:var(--muted);font-size:9px}.rfS2FontOption:hover,.rfS2FontOption:focus-visible{background:var(--accent-soft)}.rfS2FontOption[aria-selected="true"]{background:color-mix(in srgb,var(--accent-soft) 78%,var(--paper));color:var(--accent);font-weight:760}.rfS2FontGroup{padding:6px 8px 3px;color:var(--muted);font-size:9px;font-weight:760}.rfS2Button.save{background:var(--accent);border-color:var(--accent);color:#fff}
      @media(max-width:620px){.rfS2Grid{grid-template-columns:1fr}.rfS2Section.wide{grid-column:auto}.rfS2Dialog{padding:11px}.saveBadge{display:none!important}}
    `;
    document.head.appendChild(style);
  }

  function markup() {
    return `<div class="rfS2Modal" id="rfStage2Modal" hidden aria-hidden="true"><section class="rfS2Dialog" role="dialog" aria-modal="true" aria-labelledby="rfStage2Title">
      <header class="rfS2Head"><div class="rfS2HeadText"><div class="rfS2Title" id="rfStage2Title">로판AI 전용 뷰 · 설정</div><div class="rfS2Sub">전용 WebView, 발췌 도구, 도움말과 글꼴을 설정합니다.</div></div><button type="button" class="rfS2Close" id="rfStage2Close" aria-label="닫기">${closeIcon}</button></header>
      <div class="rfS2Notice">전용 WebView는 로그인 상태와 현재 채팅방을 유지합니다. 상단바의 ☰는 발췌 도구, ↻는 현재 웹페이지 새로고침, ›는 발췌기 이동입니다.</div>
      <div class="rfS2Grid">
        <section class="rfS2Section wide"><div class="rfS2SectionTitle">전용 WebView 실행</div><div class="rfS2Row"><input class="rfS2Input rfS2Grow" value="https://rofan.ai/" readonly><button class="rfS2Button primary" id="rfStage2Open" type="button">${webIcon}전용 WebView 열기</button></div></section>
        <section class="rfS2Section"><div class="rfS2SectionTitle">첫 화면 도움말</div><div class="rfS2Help">WebView 상단바와 발췌기 오른쪽 상단의 테마·보관함·설정 버튼을 안내합니다.</div></section>
        <section class="rfS2Section"><div class="rfS2SectionTitle">발췌 완료 후 이동</div><div class="rfS2Row"><label class="rfS2Toggle"><input id="rfStage2AutoOpenExtractor" type="checkbox">HTML 발췌 후 자동으로 발췌기 열기</label></div><div class="rfS2Help">끄면 전체·선택 범위 HTML 파일만 저장하고 현재 채팅방에 그대로 머뭅니다.</div></section>
        <section class="rfS2Section"><div class="rfS2SectionTitle">발췌기 테마 색상</div><div class="rfAccentLine"><button type="button" class="rfAccentSwatch" id="rfAccentSwatch" aria-label="테마 색상 선택"></button><input class="rfS2Input rfAccentHex" id="rfAccentHex" value="#5eacc8" inputmode="text" maxlength="7"><button class="rfS2Button" id="rfAccentReset" type="button">기본색</button><button class="rfS2Button primary" id="rfAccentSave" type="button">색상 저장</button></div><div class="rfAccentPicker" id="rfAccentPicker" hidden><div class="rfAccentSV" id="rfAccentSV"><i class="rfAccentDot" id="rfAccentDot"></i></div><input class="rfAccentHue" id="rfAccentHue" type="range" min="0" max="359" step="1" value="195"></div><div class="rfS2Status" id="rfAccentStatus"></div><div class="rfS2Help">색상 칩을 누르면 사각형 HSV 피커가 열립니다. 미리 본 뒤 “색상 저장”을 누르면 앱 전체 강조색과 연한 배경색에 적용됩니다.</div></section>
        <section class="rfS2Section wide"><div class="rfS2SectionTitle">WebView 글꼴</div>
          <div class="rfS2Row"><div class="rfS2FontPicker" id="rfStage2FontPicker"><button class="rfS2FontChoiceButton" id="rfStage2FontChoiceButton" type="button" aria-haspopup="listbox" aria-expanded="false"><span id="rfStage2FontChoiceLabel">페이지 기본 글꼴</span><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m7 9 5 5 5-5"/></svg></button><div class="rfS2FontMenu" id="rfStage2FontMenu" role="listbox" hidden></div></div><button class="rfS2Button" id="rfStage2FontAdd" type="button">${uploadIcon}글꼴 등록</button><button class="rfS2Button danger" id="rfStage2FontDelete" type="button">${trashIcon}삭제</button><button class="rfS2Button save" id="rfStage2FontSave" type="button">저장</button><input id="rfStage2FontInput" type="file" multiple hidden accept=".ttf,.otf,.woff2,.zip,font/ttf,font/otf,font/woff2,application/zip"></div>
          <div class="rfS2Status" id="rfStage2FontStatus">글꼴을 선택한 뒤 저장을 누르면 로판AI WebView 전체에 바로 적용됩니다.</div><div class="rfS2Help">페이지 기본 글꼴과 등록한 글꼴 중 하나를 선택할 수 있습니다. TTF·OTF·WOFF2 또는 해당 파일이 든 ZIP을 등록할 수 있습니다.</div>
        </section>
      </div>
      <footer class="rfS2Footer"><button class="rfS2Button" id="rfStage2Done" type="button">닫기</button></footer>
    </section></div>`;
  }

  function installHeader() {
    const tools = document.querySelector(".heroTools"), theme = document.getElementById("themeToggleButton"), folder = document.getElementById("logLibraryButton");
    if (!tools || !theme) return;
    let gear = document.getElementById("rofanSettingsButton");
    if (!gear) { gear = document.createElement("button"); gear.type="button"; gear.className="themeIconButton"; gear.id="rofanSettingsButton"; gear.title="로판AI 전용 뷰 설정"; gear.setAttribute("aria-label",gear.title); gear.innerHTML=gearIcon; }
    tools.append(theme); if (folder) tools.append(folder); tools.append(gear);
  }


  const FONT_VALUE_PREFIX = "font:";
  const encodeFontValue = name => FONT_VALUE_PREFIX + encodeURIComponent(String(name || ""));
  const decodeFontValue = value => String(value || "").startsWith(FONT_VALUE_PREFIX) ? decodeURIComponent(String(value).slice(FONT_VALUE_PREFIX.length)) : "";
  let selectedFontValue = "page";
  let cachedFonts = [];

  function fontLabel(value) {
    
    return decodeFontValue(value) || "페이지 기본 글꼴";
  }
  function closeFontMenu() {
    const menu = document.getElementById("rfStage2FontMenu");
    if (menu) menu.hidden = true;
    document.getElementById("rfStage2FontChoiceButton")?.setAttribute("aria-expanded", "false");
  }
  function setFontChoice(value) {
    const custom = decodeFontValue(value);
    selectedFontValue = value === "system" || value === "page" || (custom && cachedFonts.some(font => font.name === custom)) ? value : "page";
    const label = document.getElementById("rfStage2FontChoiceLabel");
    if (label) label.textContent = fontLabel(selectedFontValue);
    const deleteButton = document.getElementById("rfStage2FontDelete");
    if (deleteButton) deleteButton.disabled = !decodeFontValue(selectedFontValue);
    document.querySelectorAll("#rfStage2FontMenu [data-font-value]").forEach(option => option.setAttribute("aria-selected", option.dataset.fontValue === selectedFontValue ? "true" : "false"));
  }
  function renderFontMenu(fonts) {
    cachedFonts = Array.isArray(fonts) ? fonts : [];
    const menu = document.getElementById("rfStage2FontMenu");
    if (!menu) return;
    menu.replaceChildren();
    const addOption = (value, label, detail = "") => {
      const option = document.createElement("button");
      option.type = "button";
      option.className = "rfS2FontOption";
      option.dataset.fontValue = value;
      option.setAttribute("role", "option");
      const title = document.createElement("span");
      title.textContent = label;
      option.appendChild(title);
      if (detail) { const small = document.createElement("small"); small.textContent = detail; option.appendChild(small); }
      option.addEventListener("click", () => { setFontChoice(value); closeFontMenu(); });
      menu.appendChild(option);
    };
    addOption("page", "페이지 기본 글꼴");
    if (cachedFonts.length) {
      const heading = document.createElement("div");
      heading.className = "rfS2FontGroup";
      heading.textContent = "등록한 글꼴";
      menu.appendChild(heading);
      for (const font of cachedFonts) addOption(encodeFontValue(font.name), font.name, formatBytes(font.size));
    }
    setFontChoice(selectedFontValue);
  }
  async function refreshFontUi(preferredName = "") {
    const status = document.getElementById("rfStage2FontStatus");
    const help = document.getElementById("rfStage2Help");
    renderFontMenu([]);
    if (status) status.textContent = "저장된 글꼴 목록을 확인하는 중…";
    try {
      const native = await waitForBridge();
      const settled = await Promise.allSettled([
        native.getConfig("font_mode", "page"), native.getConfig("font_name", ""), native.getConfig("show_help", "1"), native.listFonts()
      ]);
      const fontMode = settled[0].status === "fulfilled" ? settled[0].value : "page";
      const fontName = settled[1].status === "fulfilled" ? settled[1].value : "";
      const showHelp = settled[2].status === "fulfilled" ? settled[2].value : (state.showHelp === false ? "0" : "1");
      const fonts = settled[3].status === "fulfilled" && Array.isArray(settled[3].value) ? settled[3].value : [];
      state.showHelp = showHelp !== "0"; saveState();
      if (help) help.checked = state.showHelp;
      renderFontMenu(fonts);
      const selectedName = preferredName || fontName;
      if (selectedName && fonts.some(font => font.name === selectedName)) setFontChoice(encodeFontValue(selectedName));
      else setFontChoice(fontMode === "system" ? "system" : "page");
      if (status) status.textContent = fonts.length ? `${fonts.length}개 글꼴이 앱에 저장되어 있습니다. 선택한 뒤 저장을 누르세요.` : "TTF·OTF·WOFF2 또는 해당 파일이 든 ZIP을 등록할 수 있습니다.";
      if (settled[3].status === "rejected" && status) status.textContent += " · 글꼴 목록 연결을 다시 시도해 주세요.";
    } catch (error) {
      console.error(error);
      renderFontMenu([]);
      setFontChoice("page");
      if (status) status.textContent = error.message || "글꼴 목록을 불러오지 못했습니다.";
    }
  }
  async function saveFontChoice() {
    const status = document.getElementById("rfStage2FontStatus");
    const value = selectedFontValue || "page";
    const name = decodeFontValue(value);
    const mode = name ? "custom" : "page";
    try {
      const native = await waitForBridge();
      if (status) status.textContent = "글꼴 설정을 저장하는 중…";
      const serial = String(Date.now());
      try{localStorage.setItem("ai-log-webview-font-mode-v79",mode);localStorage.setItem("ai-log-webview-font-name-v79",name);localStorage.setItem("ai-log-webview-font-serial-v79",serial)}catch(_){}
      await native.setConfig("font_mode", mode);
      await native.setConfig("font_name", name);
      await native.setConfig("font_apply_serial", serial);
      if (status) status.textContent = "저장했습니다. WebView로 이동해 즉시 적용합니다.";
      toast("WebView 글꼴 설정을 저장했습니다.");
      setTimeout(()=>{ try { console.log("__AI_LOG_OPEN_ROFAN_ACTIVITY__"); } catch (_) {} },120);
    } catch (error) {
      console.error(error);
      if (status) status.textContent = error.message || "글꼴 설정 저장에 실패했습니다.";
      toast(status?.textContent || "글꼴 설정 저장에 실패했습니다.");
    }
  }
  function fontNameSafe(name){return String(name||"font").replace(/[\\/:*?"<>|\u0000-\u001f]/g,"_").slice(0,160);}
  function readFileBytes(file){
    return new Promise((resolve,reject)=>{
      const reader=new FileReader();
      reader.onerror=()=>reject(reader.error||new Error("파일을 읽지 못했습니다."));
      reader.onload=()=>resolve(new Uint8Array(reader.result||new ArrayBuffer(0)));
      reader.readAsArrayBuffer(file);
    });
  }
  const FONT_ARCHIVE_MAX_BYTES = 96 * 1024 * 1024;
  function fontMimeFromName(name){const lower=String(name||"").toLowerCase();if(lower.endsWith(".woff2"))return"font/woff2";if(lower.endsWith(".otf"))return"font/otf";return"font/ttf";}
  async function validateFontBytes(bytes,name,native){
    const repaired = native?.repairFontBytes ? native.repairFontBytes(bytes) : bytes;
    if(!repaired?.byteLength || repaired.byteLength > FONT_ARCHIVE_MAX_BYTES) throw new Error("폰트 파일 크기가 너무 크거나 비어 있습니다.");
    const buffer = repaired.byteOffset===0 && repaired.byteLength===repaired.buffer.byteLength ? repaired.buffer : repaired.buffer.slice(repaired.byteOffset,repaired.byteOffset+repaired.byteLength);
    const family = `AI_Log_Font_Check_${Date.now()}_${Math.random().toString(36).slice(2)}`;
    let face;
    try{
      face = new FontFace(family, buffer);
      await face.load();
      document.fonts.add(face);
    }catch(error){
      throw new Error(`글꼴 파일 정보가 올바르지 않습니다. (${name})`);
    }finally{
      if(face)try{document.fonts.delete(face)}catch(_){}
    }
    return new Uint8Array(buffer);
  }
  async function registerFontFile(file){
    const ext=(file.name.split(".").pop()||"").toLowerCase();
    const native=await waitForBridge();
    const source=await readFileBytes(file);
    if(["ttf","otf","woff2"].includes(ext)){
      const name=fontNameSafe(file.name);
      const bytes=await validateFontBytes(source,name,native);
      await native.saveFont(name,bytes,(done,total)=>{const status=document.getElementById("rfStage2FontStatus");if(status)status.textContent=`${name} 등록 중 · ${Math.round(done/Math.max(1,total)*100)}%`;});
      return[name];
    }
    if(ext==="zip"){
      if(!window.JSZip)throw new Error("ZIP 처리 모듈을 찾지 못했습니다.");
      if(source.byteLength>FONT_ARCHIVE_MAX_BYTES)throw new Error("ZIP 파일이 너무 큽니다.");
      const zip=await JSZip.loadAsync(source,{checkCRC32:true,createFolders:false});
      const entries=Object.values(zip.files).filter(entry=>!entry.dir&&!/(^|\/)__MACOSX\//i.test(entry.name)&&/\.(ttf|otf|woff2)$/i.test(entry.name));
      if(!entries.length)throw new Error("ZIP 안에서 TTF·OTF·WOFF2 글꼴을 찾지 못했습니다.");
      const names=[];
      for(const entry of entries){
        const name=fontNameSafe(entry.name.split("/").pop());
        const raw=await entry.async("uint8array");
        const bytes=await validateFontBytes(raw,name,native);
        await native.saveFont(name,bytes,(done,total)=>{const status=document.getElementById("rfStage2FontStatus");if(status)status.textContent=`${name} 등록 중 · ${Math.round(done/Math.max(1,total)*100)}%`;});
        names.push(name);
      }
      return names;
    }
    throw new Error("TTF·OTF·WOFF2 또는 해당 글꼴이 든 ZIP 파일을 선택해 주세요.");
  }
  async function importFonts(files){
    const status=document.getElementById("rfStage2FontStatus"),names=[];
    try{
      for(const file of files){if(status)status.textContent=`${file.name} 읽는 중…`;names.push(...await registerFontFile(file));}
      if(!names.length){if(status)status.textContent="지원되는 글꼴을 찾지 못했습니다.";toast(status?.textContent||"지원되는 글꼴을 찾지 못했습니다.");return;}
      const selected=names[names.length-1];
      await refreshFontUi(selected);
      if(status)status.textContent=`${names.length}개 글꼴을 등록했습니다. “저장”을 누르면 적용됩니다.`;
      toast(`${names.length}개 글꼴을 등록했습니다.`);
    }catch(error){console.error(error);if(status)status.textContent=error.message||"글꼴 등록에 실패했습니다.";toast(status?.textContent||"글꼴 등록에 실패했습니다.");}
  }

  async function openModal(){const modal=document.getElementById("rfStage2Modal");if(!modal)return;modal.hidden=false;modal.setAttribute("aria-hidden","false");document.body.style.overflow="hidden";renderFontMenu(cachedFonts);refreshFontUi().catch(error=>console.error(error));const auto=document.getElementById("rfStage2AutoOpenExtractor");if(auto)auto.checked=state.autoOpenExtractor!==false;try{const native=await waitForBridge();await native.diagnose?.();const saved=await native.getConfig("auto_open_extractor",state.autoOpenExtractor===false?"0":"1");state.autoOpenExtractor=saved!=="0";saveState();if(auto)auto.checked=state.autoOpenExtractor}catch(error){console.error(error)}}
  function closeModal(){const modal=document.getElementById("rfStage2Modal");if(!modal)return;modal.hidden=true;modal.setAttribute("aria-hidden","true");document.body.style.overflow="";}
  function openDedicatedWebView(){console.log("__AI_LOG_OPEN_ROFAN_ACTIVITY__");closeModal();}


  async function restoreAccent(){try{const local=normalizeHex(state.accent)||normalizeHex(localStorage.getItem(ACCENT_KEY))||DEFAULT_ACCENT;applyAccent(local,false);const native=await waitForBridge();const saved=normalizeHex(await native.getConfig("extractor_accent",local));if(saved){state.accent=saved;saveState();applyAccent(saved,true)}}catch(error){console.error(error)}}
  function boot(){
    installStyle();installHeader();if(!document.getElementById("rfStage2Modal"))document.body.insertAdjacentHTML("beforeend",markup());restoreAccent();
    document.getElementById("rofanSettingsButton")?.addEventListener("click",openModal);document.getElementById("rfStage2Close")?.addEventListener("click",closeModal);document.getElementById("rfStage2Done")?.addEventListener("click",closeModal);document.getElementById("rfStage2Modal")?.addEventListener("click",e=>{if(e.target.id==="rfStage2Modal")closeModal()});document.getElementById("rfStage2Open")?.addEventListener("click",openDedicatedWebView);
    const helpToggle=document.getElementById("rfStage2Help");if(helpToggle)helpToggle.checked=state.showHelp!==false;
    helpToggle?.addEventListener("change",async e=>{state.showHelp=!!e.target.checked;saveState();try{const native=await waitForBridge();await native.setConfig("show_help",state.showHelp?"1":"0");if(state.showHelp)await native.setConfig("help_seen_v38","0")}catch(error){console.error(error)}toast(state.showHelp?"첫 화면 도움말을 켰습니다.":"첫 화면 도움말을 껐습니다.")});
    document.getElementById("rfStage2HelpAgain")?.addEventListener("click",async()=>{state.showHelp=true;saveState();try{const native=await waitForBridge();await native.setConfig("show_help","1");await native.setConfig("help_seen_v38","0")}catch(error){console.error(error)}toast("다음 WebView 표시 때 도움말이 다시 열립니다.");});
    const autoOpenToggle=document.getElementById("rfStage2AutoOpenExtractor");if(autoOpenToggle)autoOpenToggle.checked=state.autoOpenExtractor!==false;autoOpenToggle?.addEventListener("change",async e=>{state.autoOpenExtractor=!!e.target.checked;saveState();try{const native=await waitForBridge();await native.setConfig("auto_open_extractor",state.autoOpenExtractor?"1":"0")}catch(error){console.error(error)}toast(state.autoOpenExtractor?"발췌 후 발췌기를 자동으로 엽니다.":"발췌 파일만 저장하고 채팅방에 머뭅니다.")});
    waitForBridge().then(async native=>{try{await native.setConfig("navigation_mode","topbar");await native.callText("nav_mode",["topbar"]);await native.callText("apply_nav");}catch(error){console.error(error)}}).catch(()=>{});
    const accentPicker=document.getElementById("rfAccentPicker"),accentSV=document.getElementById("rfAccentSV"),accentHue=document.getElementById("rfAccentHue"),accentHexInput=document.getElementById("rfAccentHex");
    document.getElementById("rfAccentSwatch")?.addEventListener("click",()=>{if(accentPicker){accentPicker.hidden=!accentPicker.hidden;updateAccentUi();}});
    const pickSV=event=>{const r=accentSV.getBoundingClientRect();setAccentHsv(accentHsv[0],clamp((event.clientX-r.left)/r.width),clamp(1-(event.clientY-r.top)/r.height),false);};
    accentSV?.addEventListener("pointerdown",event=>{accentSV.setPointerCapture?.(event.pointerId);pickSV(event);});accentSV?.addEventListener("pointermove",event=>{if(event.buttons||event.pressure>0)pickSV(event);});
    accentHue?.addEventListener("input",event=>setAccentHsv(Number(event.target.value),accentHsv[1],accentHsv[2],false));
    accentHexInput?.addEventListener("change",event=>{const hex=normalizeHex(event.target.value);if(hex)applyAccent(hex,false);else updateAccentUi();});
    document.getElementById("rfAccentReset")?.addEventListener("click",()=>applyAccent(DEFAULT_ACCENT,false));
    document.getElementById("rfAccentSave")?.addEventListener("click",async()=>{const status=document.getElementById("rfAccentStatus");try{applyAccent(accentHex,true);state.accent=accentHex;saveState();window.AILogThemeV67?.set?.(accentHex);const native=await waitForBridge();await native.setConfig("extractor_accent",accentHex);if(status)status.textContent=`${accentHex} 색상으로 저장했습니다.`;toast("발췌기 테마 색상을 저장했습니다.")}catch(error){console.error(error);if(status)status.textContent=error.message||"색상 저장에 실패했습니다.";toast(status?.textContent||"색상 저장에 실패했습니다.")}});
    document.getElementById("rfStage2FontChoiceButton")?.addEventListener("click",()=>{const menu=document.getElementById("rfStage2FontMenu"),button=document.getElementById("rfStage2FontChoiceButton");if(!menu)return;menu.hidden=!menu.hidden;button?.setAttribute("aria-expanded",menu.hidden?"false":"true");});document.addEventListener("click",event=>{if(!event.target?.closest?.("#rfStage2FontPicker"))closeFontMenu()});document.getElementById("rfStage2FontSave")?.addEventListener("click",saveFontChoice);document.getElementById("rfStage2FontAdd")?.addEventListener("click",()=>document.getElementById("rfStage2FontInput")?.click());document.getElementById("rfStage2FontInput")?.addEventListener("change",async e=>{const files=Array.from(e.target.files||[]);e.target.value="";if(files.length)await importFonts(files)});document.getElementById("rfStage2FontDelete")?.addEventListener("click",async()=>{const name=decodeFontValue(selectedFontValue);if(!name||!confirm(`“${name}” 글꼴을 삭제하시겠습니까?`))return;const native=await waitForBridge();await native.deleteFont(name);if((await native.getConfig("font_name",""))===name){await native.setConfig("font_name","");await native.setConfig("font_mode","page");await native.setConfig("font_apply_serial",String(Date.now()));await native.callText("apply_font");}await refreshFontUi();toast("글꼴을 삭제했습니다.");});
  }
  if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",boot,{once:true});else boot();
})();
