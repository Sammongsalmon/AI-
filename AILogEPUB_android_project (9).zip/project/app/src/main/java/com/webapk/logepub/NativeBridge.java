package com.webapk.logepub;

import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

/**
 * JS 에서 AILogNative.call("op\targ1\targ2...") 로 호출한다.
 *
 * 반환 형식 (rf_native_bridge_v38.js 의 nativeRaw 규약)
 *   성공 : "1\t" + base64(payload bytes)
 *   실패 : "0\t" + base64(utf8 오류메시지)
 *
 * 이전 구조가 window.prompt + JsPromptResult 였고, DEX 에 JsPromptResult 참조가
 * 없어 응답이 영원히 돌아오지 않았다. @JavascriptInterface 는 메서드 반환값이
 * 그대로 JS 반환값이 되므로 그 실패 지점 자체가 사라진다.
 */
public final class NativeBridge {

    private static final String PREFS = "ai_log_config";
    private static final String ROOT = "로그 발췌기";

    private final Context app;
    private final SharedPreferences prefs;
    private final Map<String, Session> sessions = new HashMap<>();
    private final AtomicLong seq = new AtomicLong(1);

    public NativeBridge(Context context) {
        this.app = context.getApplicationContext();
        this.prefs = this.app.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    // ---------------------------------------------------------------- 진입점

    @JavascriptInterface
    public String call(String command) {
        try {
            String[] a = splitTab(command == null ? "" : command);
            String op = a.length > 0 ? a[0] : "";
            switch (op) {
                case "ping":            return ok("ok");
                case "toast":           showToast(ut(arg(a, 1))); return ok("1");
                case "fetch_image":     return okBytes(fetchImage(ut(arg(a, 1))));


                case "config_get":      return ok(prefs.getString(ut(arg(a, 1)), ""));
                case "config_set":      prefs.edit().putString(ut(arg(a, 1)), ut(arg(a, 2))).apply();
                                        return ok("1");

                case "font_list":       return ok(fontList());
                case "font_begin":      return ok(fontBegin(ut(arg(a, 1))));
                case "font_write":      return ok(write(arg(a, 1), arg(a, 2)));
                case "font_finish":     return ok(fontFinish(arg(a, 1)));
                case "font_cancel":     return ok(cancel(arg(a, 1)));
                case "font_read":       return okBytes(fontRead(ut(arg(a, 1)), num(arg(a, 2)), num(arg(a, 3))));
                case "font_delete":     return ok(fontDelete(ut(arg(a, 1))));

                case "shared_begin":    return ok(sharedBegin(arg(a, 1), ut(arg(a, 2)), ut(arg(a, 3))));
                case "shared_save_once": return ok(sharedSaveOnce(arg(a, 1), ut(arg(a, 2)), ut(arg(a, 3)), arg(a, 4)));
                case "shared_write":    return ok(write(arg(a, 1), arg(a, 2)));
                case "shared_finish":   return ok(sharedFinish(arg(a, 1)));
                case "shared_cancel":   return ok(cancel(arg(a, 1)));
                case "shared_list":     return ok(sharedList(arg(a, 1)));
                case "shared_read":     return okBytes(sharedRead(arg(a, 1), arg(a, 2), num(arg(a, 3)), num(arg(a, 4))));
                case "shared_rename":   return ok(sharedRename(arg(a, 1), arg(a, 2), ut(arg(a, 3))));
                case "shared_delete":   return ok(sharedDelete(arg(a, 1), arg(a, 2)));

                default:                return fail("알 수 없는 작업: " + op);
            }
        } catch (Throwable t) {
            String m = t.getMessage();
            return fail(m == null || m.isEmpty() ? t.getClass().getSimpleName() : m);
        }
    }

    /** 페이지 이미지를 앱이 대신 받아 온다. WebView fetch 는 CORS 로 막히기 때문. */
    private byte[] fetchImage(String url) throws Exception {
        if (url == null || !(url.startsWith("https://") || url.startsWith("http://")))
            throw new RuntimeException("이미지 주소가 올바르지 않습니다.");
        java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(12000);
        c.setInstanceFollowRedirects(true);
        String cookie = android.webkit.CookieManager.getInstance().getCookie(url);
        if (cookie != null && !cookie.isEmpty()) c.setRequestProperty("Cookie", cookie);
        c.setRequestProperty("Accept", "image/*,*/*");
        try (InputStream in = c.getInputStream()) {
            java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n, total = 0;
            while ((n = in.read(buf)) > 0) {
                total += n;
                if (total > 12 * 1024 * 1024) break;      // 12MB 상한
                out.write(buf, 0, n);
            }
            return out.toByteArray();
        } finally {
            c.disconnect();
        }
    }

    private void showToast(final String message) {
        if (message == null || message.isEmpty()) return;
        new android.os.Handler(android.os.Looper.getMainLooper()).post(
                () -> android.widget.Toast.makeText(app, message, android.widget.Toast.LENGTH_SHORT).show());
    }

    // ---------------------------------------------------------------- 글꼴 (앱 내부 저장소)

    private File fontDir() {
        File d = new File(app.getFilesDir(), "fonts");
        if (!d.exists() && !d.mkdirs()) throw new RuntimeException("글꼴 폴더를 만들지 못했습니다.");
        return d;
    }

    private File fontFile(String name) {
        String safe = safeName(name);
        if (safe.isEmpty()) throw new RuntimeException("글꼴 이름이 비어 있습니다.");
        return new File(fontDir(), safe);
    }

    private String fontList() {
        File[] files = fontDir().listFiles();
        if (files == null) return "";
        List<String> rows = new ArrayList<>();
        for (File f : files) {
            if (f.isFile()) rows.add(t64(f.getName()) + "\t" + f.length() + "\t" + f.lastModified());
        }
        Collections.sort(rows);
        return join(rows);
    }

    private String fontBegin(String name) throws Exception {
        File target = fontFile(name);
        File tmp = new File(target.getAbsolutePath() + ".part");
        Session s = new Session();
        s.out = new FileOutputStream(tmp);
        s.file = target;
        s.temp = tmp;
        return register(s);
    }

    private String fontFinish(String id) throws Exception {
        Session s = take(id);
        s.out.flush();
        s.out.close();
        s.out = null;
        if (s.file.exists() && !s.file.delete()) throw new RuntimeException("기존 글꼴을 교체하지 못했습니다.");
        if (!s.temp.renameTo(s.file)) throw new RuntimeException("글꼴 저장을 마치지 못했습니다.");
        return t64(s.file.getName()) + "\t" + s.written + "\t" + s.file.lastModified();
    }

    private byte[] fontRead(String name, long offset, int length) throws Exception {
        File f = fontFile(name);
        if (!f.exists()) throw new RuntimeException("글꼴을 찾지 못했습니다.");
        try (InputStream in = new FileInputStream(f)) {
            return readSlice(in, offset, length);
        }
    }

    private String fontDelete(String name) {
        File f = fontFile(name);
        if (f.exists() && !f.delete()) throw new RuntimeException("글꼴을 지우지 못했습니다.");
        return "1";
    }

    // ---------------------------------------------------------------- 발췌 결과물 (MediaStore/Download)

    /** 카테고리 -> Download 하위 폴더 */
    private static String folderOf(String category) {
        switch (category == null ? "" : category) {
            case "full":       return "전체 범위 발췌";
            case "selected":
            case "range":      return "선택 범위 발췌";
            case "screenshot":
            case "shot":       return "스크린샷";
            case "import":     return "불러오기";
            case "export":     return "내보내기";
            default:           return "기타";
        }
    }

    private static String relativePath(String category) {
        return Environment.DIRECTORY_DOWNLOADS + "/" + ROOT + "/" + folderOf(category) + "/";
    }

    private static Uri collection() {
        return MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
    }

    private String sharedBegin(String category, String name, String mime) throws Exception {
        ContentValues v = new ContentValues();
        v.put(MediaStore.Downloads.DISPLAY_NAME, safeName(name));
        v.put(MediaStore.Downloads.MIME_TYPE, mime == null || mime.isEmpty() ? "application/octet-stream" : mime);
        v.put(MediaStore.Downloads.RELATIVE_PATH, relativePath(category));
        v.put(MediaStore.Downloads.IS_PENDING, 1);

        Uri uri = app.getContentResolver().insert(collection(), v);
        if (uri == null) throw new RuntimeException("저장 위치를 만들지 못했습니다.");

        OutputStream out = app.getContentResolver().openOutputStream(uri, "w");
        if (out == null) {
            app.getContentResolver().delete(uri, null, null);
            throw new RuntimeException("저장 스트림을 열지 못했습니다.");
        }
        Session s = new Session();
        s.out = out;
        s.uri = uri;
        s.category = category;
        return register(s);
    }

    /** 조각 전송 없이 한 번에 저장한다. 스크린샷처럼 큰 파일에서 훨씬 빠르다. */
    private String sharedSaveOnce(String category, String name, String mime, String b64) throws Exception {
        byte[] data = Base64.decode(b64 == null ? "" : b64, Base64.DEFAULT);
        if (data.length == 0) throw new RuntimeException("저장할 내용이 비어 있습니다.");
        String id = sharedBegin(category, name, mime);
        Session s = get(id);
        try {
            s.out.write(data);
            s.written = data.length;
        } catch (Exception e) {
            cancel(id);
            throw e;
        }
        return sharedFinish(id);
    }

    private String sharedFinish(String id) throws Exception {
        Session s = take(id);
        s.out.flush();
        s.out.close();
        s.out = null;

        ContentValues v = new ContentValues();
        v.put(MediaStore.Downloads.IS_PENDING, 0);
        app.getContentResolver().update(s.uri, v, null, null);

        String row = queryOne(s.uri);
        if (row != null) return row;
        return ContentUris.parseId(s.uri) + "\t" + t64("") + "\t" + s.written + "\t" + System.currentTimeMillis() + "\t" + t64("application/octet-stream");
    }

    private static final String[] COLS = {
            MediaStore.Downloads._ID,
            MediaStore.Downloads.DISPLAY_NAME,
            MediaStore.Downloads.SIZE,
            MediaStore.Downloads.DATE_MODIFIED,
            MediaStore.Downloads.MIME_TYPE
    };

    private String rowOf(Cursor c) {
        long id = c.getLong(0);
        String name = c.isNull(1) ? "" : c.getString(1);
        long size = c.isNull(2) ? 0 : c.getLong(2);
        long modified = (c.isNull(3) ? 0 : c.getLong(3)) * 1000L;   // MediaStore 는 초 단위
        String mime = c.isNull(4) ? "application/octet-stream" : c.getString(4);
        return id + "\t" + t64(name) + "\t" + size + "\t" + modified + "\t" + t64(mime);
    }

    private String queryOne(Uri uri) {
        try (Cursor c = app.getContentResolver().query(uri, COLS, null, null, null)) {
            if (c != null && c.moveToFirst()) return rowOf(c);
        }
        return null;
    }

    private String sharedList(String category) {
        String sel = MediaStore.Downloads.RELATIVE_PATH + "=? AND " + MediaStore.Downloads.IS_PENDING + "=0";
        String[] args = { relativePath(category) };
        String order = MediaStore.Downloads.DATE_MODIFIED + " DESC";
        List<String> rows = new ArrayList<>();
        try (Cursor c = app.getContentResolver().query(collection(), COLS, sel, args, order)) {
            if (c != null) while (c.moveToNext()) rows.add(rowOf(c));
        }
        return join(rows);
    }

    private byte[] sharedRead(String category, String id, long offset, int length) throws Exception {
        Uri uri = ContentUris.withAppendedId(collection(), Long.parseLong(id));
        try (InputStream in = app.getContentResolver().openInputStream(uri)) {
            if (in == null) throw new RuntimeException("파일을 열지 못했습니다.");
            return readSlice(in, offset, length);
        }
    }

    private String sharedRename(String category, String id, String name) {
        Uri uri = ContentUris.withAppendedId(collection(), Long.parseLong(id));
        ContentValues v = new ContentValues();
        v.put(MediaStore.Downloads.DISPLAY_NAME, safeName(name));
        int n = app.getContentResolver().update(uri, v, null, null);
        if (n <= 0) throw new RuntimeException("이름을 바꾸지 못했습니다.");
        return "1";
    }

    private String sharedDelete(String category, String id) {
        Uri uri = ContentUris.withAppendedId(collection(), Long.parseLong(id));
        int n = app.getContentResolver().delete(uri, null, null);
        if (n <= 0) throw new RuntimeException("파일을 지우지 못했습니다.");
        return "1";
    }

    // ---------------------------------------------------------------- 전송 세션 공통

    private static final class Session {
        OutputStream out;
        Uri uri;
        File file;
        File temp;
        String category;
        long written;
    }

    private String register(Session s) {
        String id = "s" + seq.getAndIncrement();
        synchronized (sessions) { sessions.put(id, s); }
        return id;
    }

    private Session get(String id) {
        Session s;
        synchronized (sessions) { s = sessions.get(id); }
        if (s == null) throw new RuntimeException("저장 세션이 유효하지 않습니다.");
        return s;
    }

    private Session take(String id) {
        Session s;
        synchronized (sessions) { s = sessions.remove(id); }
        if (s == null) throw new RuntimeException("저장 세션이 유효하지 않습니다.");
        return s;
    }

    private String write(String id, String b64) throws Exception {
        Session s = get(id);
        byte[] chunk = Base64.decode(b64 == null ? "" : b64, Base64.DEFAULT);
        s.out.write(chunk);
        s.written += chunk.length;
        return String.valueOf(s.written);
    }

    private String cancel(String id) {
        Session s;
        synchronized (sessions) { s = sessions.remove(id); }
        if (s == null) return "1";
        try { if (s.out != null) s.out.close(); } catch (Exception ignored) { }
        try { if (s.temp != null && s.temp.exists()) s.temp.delete(); } catch (Exception ignored) { }
        try { if (s.uri != null) app.getContentResolver().delete(s.uri, null, null); } catch (Exception ignored) { }
        return "1";
    }

    private static byte[] readSlice(InputStream in, long offset, int length) throws Exception {
        long skipped = 0;
        while (skipped < offset) {
            long n = in.skip(offset - skipped);
            if (n <= 0) { if (in.read() < 0) return new byte[0]; n = 1; }
            skipped += n;
        }
        byte[] buf = new byte[Math.max(0, length)];
        int filled = 0;
        while (filled < buf.length) {
            int n = in.read(buf, filled, buf.length - filled);
            if (n < 0) break;
            filled += n;
        }
        if (filled == buf.length) return buf;
        byte[] out = new byte[filled];
        System.arraycopy(buf, 0, out, 0, filled);
        return out;
    }

    // ---------------------------------------------------------------- 문자열 유틸

    private static String[] splitTab(String s) { return s.split("\t", -1); }

    private static String arg(String[] a, int i) { return i < a.length ? a[i] : ""; }

    private static int num(String s) {
        try { return (int) Math.max(0, Long.parseLong(s.trim())); } catch (Exception e) { return 0; }
    }

    private static String join(List<String> rows) {
        StringBuilder sb = new StringBuilder();
        for (String r : rows) { if (sb.length() > 0) sb.append('\n'); sb.append(r); }
        return sb.toString();
    }

    /** base64(utf8) 인자를 문자열로 */
    private static String ut(String b64) {
        if (b64 == null || b64.isEmpty()) return "";
        try { return new String(Base64.decode(b64, Base64.DEFAULT), StandardCharsets.UTF_8); }
        catch (Exception e) { return ""; }
    }

    private static String t64(String text) {
        return Base64.encodeToString((text == null ? "" : text).getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
    }

    private static String safeName(String name) {
        String s = (name == null ? "" : name).replaceAll("[\\\\/:*?\"<>|\\x00-\\x1f]", "_").trim();
        if (s.length() > 160) s = s.substring(0, 160);
        return s.isEmpty() ? "download" : s;
    }

    private static String ok(String text) {
        return "1\t" + Base64.encodeToString((text == null ? "" : text).getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
    }

    private static String okBytes(byte[] bytes) {
        return "1\t" + Base64.encodeToString(bytes == null ? new byte[0] : bytes, Base64.NO_WRAP);
    }

    private static String fail(String message) {
        return "0\t" + Base64.encodeToString((message == null ? "실패" : message).getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
    }
}
