package com.webapk.logepub;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;

/** 로판AI WebView 화면. 발췌 도구 JS 를 주입한다. */
public class RofanActivity extends WebActivityBase {

    private String cachedScript;

    // 상단바 아래 화면의 평균 밝기로 라이트/다크를 정한다 (앱 테마와 무관)
    private final Handler toneHandler = new Handler(Looper.getMainLooper());
    private String currentTone = "";
    private final Runnable toneTick = new Runnable() {
        @Override public void run() { sampleTone(); }
    };

    /** 화면이 바뀐 직후 한 번만 재검사한다. 연속 호출은 마지막 것만 남는다. */
    private void scheduleToneCheck(long delay) {
        toneHandler.removeCallbacks(toneTick);
        toneHandler.postDelayed(toneTick, delay);
    }

    @Override
    protected String startUrl() {
        return "https://rofan.ai/";
    }

    @Override
    protected void buildTopbar() {
        addButton("\u2630", this::openWidget);                          // ☰ 발췌 도구 위젯
        addTitle("로판AI");
        addButton("\u21bb", () -> web.reload());                        // ↻ 새로고침
        addButton("\u203a", () -> open(MainActivity.class, null));      // › 발췌기로
    }

    @Override
    protected String injectionScript() {
        if (cachedScript == null) {
            cachedScript = readAsset("rofan_inject.js");
            if (cachedScript.isEmpty()) toast("발췌 도구 스크립트를 읽지 못했습니다.");
        }
        return cachedScript;
    }

    @Override
    protected void onResume() {
        super.onResume();
        scheduleToneCheck(700);
    }

    @Override
    protected void onPageReady(String url) {
        // 페이지가 새로 그려졌을 때
        scheduleToneCheck(500);
        if (web != null) {
            web.setOnScrollChangeListener((v, x, y, ox, oy) -> {
                // 스크롤이 멎은 뒤 한 번만
                if (Math.abs(y - oy) > 8) scheduleToneCheck(450);
            });
        }
    }

    @Override
    protected void onPause() {
        toneHandler.removeCallbacks(toneTick);
        super.onPause();
    }

    /** WebView 를 1/12 크기로 그려 평균 휘도를 잰다. 전체 화면을 캡처하지 않아 부담이 적다. */
    private void sampleTone() {
        if (web == null || web.getWidth() <= 0 || web.getHeight() <= 0) return;
        // 글자를 선택하는 중에는 다시 그리지 않는다 (선택 커서가 흔들린다)
        if (web.isPressed()) return;   // 글자를 누르고 있는 중이면 건너뛴다
        try {
            int w = Math.max(8, web.getWidth() / 12);
            int h = Math.max(8, web.getHeight() / 12);
            Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.RGB_565);
            Canvas c = new Canvas(bmp);
            c.scale(w / (float) web.getWidth(), h / (float) web.getHeight());
            web.draw(c);

            long sum = 0;
            int n = 0;
            for (int y = 0; y < h; y += 2) {
                for (int x = 0; x < w; x += 2) {
                    int p = bmp.getPixel(x, y);
                    sum += (Color.red(p) * 299 + Color.green(p) * 587 + Color.blue(p) * 114) / 1000;
                    n++;
                }
            }
            bmp.recycle();
            if (n == 0) return;

            String tone = (sum / n) < 128 ? "dark" : "light";
            if (tone.equals(currentTone)) return;
            currentTone = tone;
            applyTone(tone);
        } catch (Throwable ignored) { }
    }

    private void applyTone(String tone) {
        boolean dark = "dark".equals(tone);
        int bar  = dark ? Color.parseColor("#1B2126") : Color.WHITE;
        int fg   = dark ? Color.parseColor("#E8EEF2") : Color.parseColor("#26343B");
        int sub  = dark ? Color.parseColor("#9AA8B1") : Color.parseColor("#5A6169");
        int line = dark ? Color.parseColor("#2C353B") : Color.parseColor("#E6EAED");

        if (topbar != null) {
            topbar.setBackgroundColor(bar);
            for (int i = 0; i < topbar.getChildCount(); i++) {
                android.view.View v = topbar.getChildAt(i);
                if (v instanceof android.widget.Button) ((android.widget.Button) v).setTextColor(fg);
                else if (v instanceof android.widget.TextView) ((android.widget.TextView) v).setTextColor(sub);
            }
        }
        if (topbarDivider != null) topbarDivider.setBackgroundColor(line);

        if (web != null) {
            web.evaluateJavascript(
                    "try{window.__AILOG_SET_TONE__&&window.__AILOG_SET_TONE__('" + tone + "')}catch(e){}", null);
        }
    }

    private void openWidget() {
        web.evaluateJavascript(
                "try{(window.__AI_LOG_NATIVE_TOOLS__||window.__AI_LOG_NATIVE_ACTIONS||{}).menu?.()}catch(e){}",
                null);
    }
}
