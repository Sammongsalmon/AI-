package com.webapk.logepub;

import android.content.Intent;

/** 발췌기 화면. assets/index.html 을 연다. */
public class MainActivity extends WebActivityBase {

    @Override
    protected String startUrl() {
        return "file:///android_asset/index.html";
    }

    @Override
    protected void buildTopbar() {
        // 발췌기 페이지는 자체 상단바(local_topbar_v70.js)를 갖고 있어 네이티브 상단바를 쓰지 않는다
        hideTopbar();
    }

    @Override
    protected void onPageReady(String url) {
        consumeOpenExtra();
    }

    @Override
    protected void onIntentChanged(Intent intent) {
        consumeOpenExtra();
    }

    private void consumeOpenExtra() {
        if (web == null) return;
        if (!"settings".equals(getIntent().getStringExtra("open"))) return;
        getIntent().removeExtra("open");
        web.evaluateJavascript(
                "try{" +
                "  dispatchEvent(new CustomEvent('ai-log-open-settings'));" +
                "  if(typeof window.openSettings==='function') window.openSettings();" +
                "}catch(e){}", null);
    }
}
