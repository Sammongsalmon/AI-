package com.webapk.logepub;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ConsoleMessage;
import android.webkit.CookieManager;
import android.webkit.JsPromptResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/**
 * 상단바와 WebView 를 세로 LinearLayout 으로 쌓는다.
 * 겹치지 않으므로 터치 좌표가 어긋나던 문제가 구조적으로 사라진다.
 */
public abstract class WebActivityBase extends Activity {

    protected WebView web;
    protected LinearLayout topbar;
    protected View topbarDivider;

    private ValueCallback<Uri[]> filePicker;
    private static final int REQ_FILE = 4101;

    protected abstract String startUrl();

    /** 상단바 버튼 구성. 하위 클래스에서 addButton(...) 으로 채운다. */
    protected abstract void buildTopbar();

    /** 페이지 로드가 끝난 뒤 주입할 JS (없으면 null) */
    protected String injectionScript() { return null; }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setFitsSystemWindows(true);
        root.setBackgroundColor(Color.WHITE);

        topbar = new LinearLayout(this);
        topbar.setOrientation(LinearLayout.HORIZONTAL);
        topbar.setGravity(Gravity.CENTER_VERTICAL);
        topbar.setPadding(dp(4), 0, dp(4), 0);   // 발췌기 상단바 padding:0 4px 와 같은 값
        topbar.setBackgroundColor(Color.WHITE);
        topbar.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(46)));
        root.addView(topbar);

        View line = topbarDivider = new View(this);
        line.setBackgroundColor(Color.parseColor("#E6EAED"));
        line.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Math.max(1, dp(1) / 2)));
        root.addView(line);

        web = new WebView(this);
        LinearLayout.LayoutParams wp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        web.setLayoutParams(wp);
        root.addView(web);

        setContentView(root);

        configureWebView();
        buildTopbar();
        web.loadUrl(startUrl());
    }

    private void configureWebView() {
        // chrome://inspect 로 원격 디버깅할 수 있게 한다
        try { WebView.setWebContentsDebuggingEnabled(true); } catch (Throwable ignored) { }

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setJavaScriptCanOpenWindowsAutomatically(true);

        // 로컬 자산 페이지에서만 file:// 교차 접근을 허용한다.
        // (발췌기가 assets/fonts 아래 woff2 를 fetch 로 읽는다)
        if (startUrl().startsWith("file:")) {
            s.setAllowFileAccessFromFileURLs(true);
            s.setAllowUniversalAccessFromFileURLs(true);
        }

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, true);

        web.addJavascriptInterface(new NativeBridge(this), "AILogNative");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return false;   // 앱 안에서 계속 연다
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                String js = injectionScript();
                if (js != null && !js.isEmpty()) v.evaluateJavascript(js, null);
                onPageReady(url);
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage m) {
                handleCommand(m.message());
                return true;
            }

            @Override
            public boolean onJsPrompt(WebView v, String url, String message,
                                      String defaultValue, JsPromptResult result) {
                // 구형 브리지가 남긴 prompt 가 기본 입력 대화상자로 새어 나오지 않게 막는다
                if (message != null && message.startsWith("__")) {
                    result.confirm("");
                    return true;
                }
                return super.onJsPrompt(v, url, message, defaultValue, result);
            }

            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb,
                                             FileChooserParams params) {
                if (filePicker != null) filePicker.onReceiveValue(null);
                filePicker = cb;
                try {
                    Intent i = params.createIntent();
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    startActivityForResult(Intent.createChooser(i, "파일 선택"), REQ_FILE);
                    return true;
                } catch (Exception e) {
                    filePicker = null;
                    toast("파일 선택기를 열지 못했습니다.");
                    return false;
                }
            }
        });

        web.setDownloadListener((url, agent, disposition, mime, size) ->
                toast("저장은 앱 내부 발췌 기능을 사용해 주세요."));
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        onIntentChanged(intent);
    }

    /** 이미 살아 있는 화면으로 다시 들어왔을 때 */
    protected void onIntentChanged(Intent intent) { }

    @Override
    protected void onActivityResult(int req, int result, Intent data) {
        if (req == REQ_FILE) {
            if (filePicker != null) {
                filePicker.onReceiveValue(
                        WebChromeClient.FileChooserParams.parseResult(result, data));
                filePicker = null;
            }
            return;
        }
        super.onActivityResult(req, result, data);
    }

    /** JS 가 console.log 로 보내는 화면 전환 명령 */
    protected void handleCommand(String message) {
        if (message == null) return;
        if (message.contains("__AI_LOG_OPEN_EXTRACTOR__")) {
            open(MainActivity.class, null);
        } else if (message.contains("__AI_LOG_OPEN_SETTINGS__")) {
            open(MainActivity.class, "settings");
        } else if (message.contains("__AI_LOG_OPEN_ROFAN_ACTIVITY__")) {
            open(RofanActivity.class, null);
        }
    }

    protected void open(Class<?> target, String extra) {
        if (getClass().equals(target)) return;
        Intent i = new Intent(this, target);
        i.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        if (extra != null) i.putExtra("open", extra);
        startActivity(i);
    }

    protected void onPageReady(String url) { }

    // ---------------------------------------------------------------- 상단바 도우미

    /** 페이지가 자체 상단바를 가진 경우 네이티브 상단바를 숨긴다 */
    protected void hideTopbar() {
        if (topbar != null) topbar.setVisibility(View.GONE);
        if (topbarDivider != null) topbarDivider.setVisibility(View.GONE);
    }

    /**
     * 발췌기 상단바(local_topbar_v70.js)와 같은 치수로 맞춘다.
     *   버튼 38x38, 사이 여백 2px, 글자 21px/800, 좌우 안쪽 여백 4px.
     * sp 가 아니라 dip 을 쓴다. 기기 글자 크기 설정에 따라 웹 쪽과 어긋나기 때문.
     */
    protected Button addButton(String label, Runnable action) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 21f);
        b.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        b.setIncludeFontPadding(false);
        b.setTextColor(Color.parseColor("#26343B"));
        b.setBackgroundColor(Color.TRANSPARENT);
        b.setPadding(0, 0, 0, 0);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(38), dp(38));
        lp.setMargins(dp(1), 0, dp(1), 0);
        lp.gravity = Gravity.CENTER_VERTICAL;
        b.setLayoutParams(lp);
        b.setOnClickListener(v -> action.run());
        topbar.addView(b);
        return b;
    }

    protected void addTitle(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 13f);
        t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        t.setIncludeFontPadding(false);
        t.setTextColor(Color.parseColor("#5A6169"));
        t.setGravity(Gravity.CENTER);
        t.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        topbar.addView(t);
    }

    protected int dp(int value) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value,
                getResources().getDisplayMetrics());
    }

    protected void toast(String message) {
        runOnUiThread(() -> Toast.makeText(this, message, Toast.LENGTH_SHORT).show());
    }

    protected String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString(StandardCharsets.UTF_8.name());
        } catch (Exception e) {
            return "";
        }
    }

    // ---------------------------------------------------------------- 생명주기

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onPause() {
        super.onPause();
        CookieManager.getInstance().flush();
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            ViewGroup parent = (ViewGroup) web.getParent();
            if (parent != null) parent.removeView(web);
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}
