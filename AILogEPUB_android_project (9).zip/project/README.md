# AI Log EPUB — 정식 빌드 프로젝트

기존 v79 APK를 정식 Android 프로젝트로 다시 만든 것입니다.
발췌기 웹 자산은 그대로 쓰고, **한 번도 동작한 적 없던 저장 브리지만 구조를 바꿨습니다.**

---

## 무엇이 바뀌었나

### 1. 저장 브리지 — 이게 핵심입니다

기존 구조는 이랬습니다.

```
JS: window.prompt("__AI_STABLE__\t" + 명령)
      ↓
AppChromeClient.onJsPrompt()
      ↓
result.confirm(응답)      ← 이 호출이 존재하지 않았음
```

세 DEX 파일의 `method_ids` 테이블(총 66개)에 `android/webkit/JsPromptResult` 참조가 **0건**이었습니다.
DEX에서 메서드를 호출하려면 그 메서드가 테이블에 있어야 하므로, `result.confirm()`을 부르는 바이트코드가 물리적으로 존재할 수 없었습니다. `.so` 네 개에도 참조가 없어 JNI 우회도 없었고, `RofanNative.handle`은 시그니처가 `(Activity, String) → boolean`이라 응답 문자열을 돌려줄 수도 없었습니다.

**브리지가 단방향이었습니다.** 그래서 `font_begin`·`config_set`·`shared_begin`·`shared_load`가 예외 없이, 100% 실패했습니다.

새 구조는 `@JavascriptInterface`입니다.

```java
@JavascriptInterface
public String call(String command) { ... }   // 반환값이 곧 JS 반환값
```

메서드 반환값이 그대로 JS로 돌아오므로 실패 지점 자체가 사라집니다.
JS 쪽은 `nativeRaw()` 한 줄만 바꿨고 그 위 로직은 전부 그대로입니다.

`NativeBridge.java`가 처리하는 작업 17개 — `config_get/set`, `font_begin/write/finish/cancel/read/list/delete`, `shared_begin/write/finish/cancel/read/list/rename/delete` — 는 JS 호출 규약과 인자 인덱스까지 대조 검증했습니다.

### 2. 상단바가 화면을 덮지 않습니다

세로 `LinearLayout`으로 상단바와 WebView를 **쌓았습니다**. 겹치는 구조가 아니므로 터치 좌표가 어긋날 수 없습니다.

* 로판AI 화면 — `☰` 발췌 도구 위젯 / `↻` 새로고침 / `›` 발췌기로
* 발췌기 화면 — `‹` 채팅으로 / `↻` 새로고침

### 3. 저장 위치

권한 요청이 필요 없습니다. 앱이 만든 파일만 다루므로 MediaStore 기본 접근으로 충분합니다.

```
Download/로그 발췌기/전체 범위 발췌/     (full)
Download/로그 발췌기/선택 범위 발췌/     (selected)
Download/로그 발췌기/스크린샷/           (screenshot)
Download/로그 발췌기/불러오기/           (import)
```

글꼴은 앱 내부 저장소(`files/fonts/`)에 둡니다. 권한도, MediaStore도 거치지 않습니다.

### 4. 발췌기를 웹 원본 동작으로 복원

GitHub 원본(`AI--main`)과 대조해 두 곳을 되돌렸습니다.

* **`stripFoldedDetailsForImport()` 제거** — 파싱 이전에 HTML 엔티티를 디코드하고 `<details>` 내부를 통째로 지우고 있었습니다. "수정 전" 창에 원본이 남을 수 없던 원인입니다.
* **중복 스크립트 제거** — `speaker_color_picker_v79.js`와 `theme_v79_overrides.js`가 각각 **4번** 로드되고 있었습니다(4889·4921·6039·8431행). 앞 세 쌍은 `script.js`보다 먼저 실행돼 핸들러가 4중 바인딩됐습니다.

요청하셨던 `{{ }}` 응답 위험 문구 감지는 의도한 기능이라 유지했습니다.

---

## 가장 빠른 길 — Codespaces (권장)

GitHub Actions 를 거치지 않고 브라우저 안에서 바로 APK 를 만듭니다.
Codespace 를 열고 이 ZIP 을 끌어다 놓은 뒤 세 줄이면 끝납니다.

```bash
unzip -o AILogEPUB_android_project.zip
cd project
bash run.sh
```

자세한 내용은 `CODESPACES.md` 를 보세요.
아래 "폰만으로 APK 받는 방법" 은 Actions 를 쓰는 경우의 안내입니다.
(Codespaces 에서 `bash publish.sh` 를 실행하면 그 단계들도 자동으로 처리됩니다.)

---

## 폰만으로 APK 받는 방법 (Actions 사용 시)

PC 없이 됩니다. GitHub 앱이나 모바일 브라우저면 충분합니다.

### 1단계 — 저장소 만들기

GitHub에서 새 저장소를 만듭니다. 이름은 아무거나, **Private 권장**입니다.

### 2단계 — 파일 올리기

이 ZIP의 압축을 풀어 **폴더 구조 그대로** 올립니다.
모바일 브라우저에서 `github.com` → 저장소 → `Add file` → `Upload files`로 폴더째 끌어 넣으면 됩니다.

`.github/workflows/build.yml`이 반드시 포함돼야 합니다. 점(`.`)으로 시작하는 폴더라 파일 앱에서 숨겨질 수 있으니 확인하세요.

### 3단계 — 빌드 실행

저장소 → `Actions` 탭 → `APK 빌드` → `Run workflow`.
파일을 올린 시점에 자동으로 한 번 돌기도 합니다. 5~10분 걸립니다.

### 4단계 — 내려받기

빌드가 끝나면 그 실행 화면 아래 `Artifacts`에 두 개가 생깁니다.

| 이름 | 내용 |
|---|---|
| `AI_Log_EPUB_apk` | **APK 파일** |
| `KEYSTORE_반드시_보관` | 서명 키 (최초 1회만 생성됨) |

폰에서 바로 내려받아 설치하면 됩니다.

### 5단계 — 키스토어를 반드시 등록하세요 ★

이 단계를 건너뛰면 **다음 빌드마다 인증서가 달라져 지금 문제가 반복됩니다.**

`KEYSTORE_반드시_보관` 안의 `release.jks.base64.txt`를 열어 내용을 전부 복사한 뒤,
저장소 → `Settings` → `Secrets and variables` → `Actions` → `New repository secret`으로 등록합니다.

```
KEYSTORE_BASE64    = release.jks.base64.txt 내용 전체
KEYSTORE_PASSWORD  = ailog-release
KEY_ALIAS          = ailog
```

등록한 뒤로는 몇 번을 다시 빌드해도 같은 인증서로 서명되므로, 앱을 지우지 않고 덮어쓰기 업데이트가 됩니다.
`release.jks` 파일 자체도 따로 보관해 두세요. 이걸 잃으면 다시는 덮어쓰기가 안 됩니다.

---

## 미리 알아 두실 것

**기존 v79 앱은 한 번 지우고 설치해야 합니다.** v79의 개인키가 소실돼 같은 인증서로 서명할 방법이 없습니다. 로판AI 로그인이 풀리므로 다시 로그인하셔야 합니다. 이번 한 번뿐이고, 5단계를 마치면 이후로는 계속 덮어쓰기됩니다.

**Android 10 이상**이 필요합니다(`minSdk 29`). MediaStore 저장 경로를 하나로 통일하려고 잡은 값입니다.

**조선일보명조 22MB TTF는 뺐습니다.** 저장소 업로드 부담 때문입니다. 발췌기 UI 글꼴로 쓰이는 `ChosunIlboMyeongjo_UI.woff2`(602KB)는 들어 있어서 화면은 그대로 나옵니다. TTF 원본이 필요하면 `app/src/main/assets/assets/fonts/ChosunIlboMyeongjo.ttf`에 넣고 다시 빌드하세요.

**웹뷰 글꼴 등록**은 이제 사용자가 고른 글꼴 파일을 앱 내부 저장소에 저장하고 `FontFace`로 적용하는 경로를 씁니다. vhea 보정 로직(`repairSfnt`)도 그대로 살아 있습니다.

---

## 폴더 구조

```
.github/workflows/build.yml          빌드·서명 자동화
settings.gradle, build.gradle        Gradle 설정
app/build.gradle                     앱 설정 (서명은 환경변수로만)
app/src/main/AndroidManifest.xml
app/src/main/java/com/webapk/logepub/
    NativeBridge.java                ★ 저장 브리지 (17개 작업)
    WebActivityBase.java             상단바 + WebView 공통 골격
    MainActivity.java                발췌기 화면
    RofanActivity.java               로판AI 화면
app/src/main/assets/                 발췌기 웹 자산 + rofan_inject.js
```

첫 빌드가 실패하면 `Actions` 실행 화면의 로그 전문을 그대로 보내 주세요. 어느 단계에서 멈췄는지 보고 고치겠습니다.
