#!/usr/bin/env bash
# =============================================================
#  AI Log EPUB — Codespaces 전자동 빌드
#
#  사용법:  bash run.sh
#
#  하는 일: JDK 확인 → Android SDK 설치 → Gradle 설치
#           → 키스토어 준비 → APK 빌드 → 서명 검증 → out/ 에 배치
#  여러 번 다시 실행해도 안전합니다(이미 된 단계는 건너뜁니다).
# =============================================================
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$HERE"

TOOLS="$HOME/.ailog-tools"
SDK="$TOOLS/android-sdk"
GRADLE_VER="8.7"
GRADLE_HOME="$TOOLS/gradle-$GRADLE_VER"
KS_DIR="$HERE/keystore"
KS="$KS_DIR/release.jks"
OUT="$HERE/out"

STORE_PASS="${KEYSTORE_PASSWORD:-ailog-release}"
ALIAS="${KEY_ALIAS:-ailog}"

SCRIPT_VERSION="v81"

step() { printf '\n\033[1;36m▶ %s\033[0m\n' "$*"; }
info() { printf '  %s\n' "$*"; }
warn() { printf '\033[1;33m  ! %s\033[0m\n' "$*"; }
die()  { printf '\n\033[1;31m✗ %s\033[0m\n' "$*" >&2; exit 1; }

printf '\n\033[1;32m=== AI Log 빌드 스크립트 %s ===\033[0m\n' "$SCRIPT_VERSION"

# -------------------------------------------------- 0. 위치 확인
[ -f "settings.gradle" ] && [ -d "app/src/main" ] \
  || die "프로젝트 최상위에서 실행해 주세요. (settings.gradle 이 있는 폴더)"

# -------------------------------------------------- 1. 필수 명령
step "1/7  기본 도구 확인"
for c in curl unzip git; do
  command -v "$c" >/dev/null 2>&1 || die "'$c' 명령이 없습니다. sudo apt-get install -y $c"
done

# Gradle 8.7 + AGP 8.5 가 지원하는 JDK 는 17 또는 21 이다.
# Codespaces 기본 JDK 가 25 인 경우가 있어(class file major 69) 반드시 골라 써야 한다.
jdk_major() {
  local home="$1" out v
  [ -x "$home/bin/java" ] || { printf '0'; return; }
  out="$("$home/bin/java" -version 2>&1 || true)"
  v="$(printf '%s\n' "$out" | sed -n '1s/.*version "\([0-9][0-9]*\).*/\1/p')"
  [ "$v" = "1" ] && v="$(printf '%s\n' "$out" | sed -n '1s/.*version "1\.\([0-9][0-9]*\).*/\1/p')"
  printf '%s' "${v:-0}"
}

# javac 가 있는 진짜 JDK 만 후보로 삼는다
find_jdk() {
  local want="$1" b v
  for b in /usr/lib/jvm/*/ /opt/java/*/ /usr/local/sdkman/candidates/java/*/ \
           "$HOME/.sdkman/candidates/java"/*/ ; do
    b="${b%/}"
    [ -x "$b/bin/javac" ] || continue
    v="$(jdk_major "$b")"
    [ "$v" = "$want" ] && { printf '%s' "$b"; return 0; }
  done
  return 1
}

pick_jdk() {
  local cand
  # 사용자가 미리 지정한 JAVA_HOME 이 17/21 이면 존중
  if [ -n "${JAVA_HOME:-}" ] && [ -x "${JAVA_HOME}/bin/javac" ]; then
    case "$(jdk_major "$JAVA_HOME")" in 17|21) printf '%s' "$JAVA_HOME"; return 0;; esac
  fi
  for w in 17 21; do
    if cand="$(find_jdk "$w")"; then printf '%s' "$cand"; return 0; fi
  done
  return 1
}

DEFAULT_JAVA_HOME="$(dirname "$(dirname "$(readlink -f "$(command -v java 2>/dev/null || echo /bin/false)")")")"
info "현재 기본 java  : major $(jdk_major "$DEFAULT_JAVA_HOME")"
info "설치된 JDK 목록 :"
for b in /usr/lib/jvm/*/ /opt/java/*/ /usr/local/sdkman/candidates/java/*/ "$HOME/.sdkman/candidates/java"/*/ ; do
  b="${b%/}"; [ -d "$b" ] || continue
  [ -x "$b/bin/javac" ] && info "   $(jdk_major "$b")  $b  (JDK)" || true
done

JDK=""
# 1순위: 이미 있는 JDK 17/21
if JDK="$(pick_jdk)"; then
  info "기존 JDK 사용"
else
  # 2순위: apt 로 JDK 17 설치
  warn "JDK 17/21 이 없습니다. apt 로 JDK 17 설치를 시도합니다."
  SUDO=""
  if [ "$(id -u)" -ne 0 ]; then command -v sudo >/dev/null 2>&1 && SUDO="sudo"; fi
  if [ -n "$SUDO" ] || [ "$(id -u)" -eq 0 ]; then
    $SUDO apt-get update -qq >/dev/null 2>&1 || true
    $SUDO apt-get install -y -qq openjdk-17-jdk >/dev/null 2>&1 || warn "apt 설치 실패"
  else
    warn "sudo 를 쓸 수 없어 apt 설치를 건너뜁니다."
  fi
  JDK="$(pick_jdk || true)"
fi

if [ -z "$JDK" ]; then
  # 3순위: Adoptium 에서 직접 내려받기 (이미지에 따라 apt 로 안 되는 경우 대비)
  warn "Adoptium JDK 17 을 직접 내려받습니다."
  ARCH="$(uname -m)"; case "$ARCH" in x86_64) A=x64;; aarch64|arm64) A=aarch64;; *) A=x64;; esac
  mkdir -p "$TOOLS"
  curl -fsSL -o "$TOOLS/jdk17.tar.gz" \
    "https://api.adoptium.net/v3/binary/latest/17/ga/linux/$A/jdk/hotspot/normal/eclipse" \
    || die "JDK 17 을 확보하지 못했습니다. 수동으로: sudo apt-get install -y openjdk-17-jdk"
  rm -rf "$TOOLS/jdk17" && mkdir -p "$TOOLS/jdk17"
  tar -xzf "$TOOLS/jdk17.tar.gz" -C "$TOOLS/jdk17" --strip-components=1
  rm -f "$TOOLS/jdk17.tar.gz"
  [ -x "$TOOLS/jdk17/bin/javac" ] || die "내려받은 JDK 가 올바르지 않습니다."
  JDK="$TOOLS/jdk17"
fi

export JAVA_HOME="$JDK"
export PATH="$JAVA_HOME/bin:$PATH"
JDK_MAJOR="$(jdk_major "$JAVA_HOME")"
info "빌드에 사용할 JDK: $JAVA_HOME (major $JDK_MAJOR)"

# 여기서 막지 않으면 Gradle 이 'Unsupported class file major version' 으로 죽는다
case "$JDK_MAJOR" in
  17|21) : ;;
  *) die "Gradle 8.7 은 JDK 17 또는 21 이 필요합니다. 지금 고른 것은 major $JDK_MAJOR 입니다." ;;
esac

# -------------------------------------------------- 2. Android SDK
step "2/7  Android SDK 준비"
mkdir -p "$TOOLS"
if [ ! -x "$SDK/cmdline-tools/latest/bin/sdkmanager" ]; then
  info "commandline-tools 내려받는 중…"
  mkdir -p "$SDK/cmdline-tools"
  GOT=""
  for F in commandlinetools-linux-11076708_latest.zip \
           commandlinetools-linux-10406996_latest.zip \
           commandlinetools-linux-9477386_latest.zip; do
    if curl -fsSL -o "$TOOLS/cmdline.zip" "https://dl.google.com/android/repository/$F"; then
      GOT="$F"; break
    fi
  done
  [ -n "$GOT" ] || die "commandline-tools 를 내려받지 못했습니다. 네트워크를 확인해 주세요."
  info "받음: $GOT"
  rm -rf "$SDK/cmdline-tools/latest" "$TOOLS/_x"
  mkdir -p "$TOOLS/_x" && unzip -q "$TOOLS/cmdline.zip" -d "$TOOLS/_x"
  mv "$TOOLS/_x/cmdline-tools" "$SDK/cmdline-tools/latest"
  rm -rf "$TOOLS/_x" "$TOOLS/cmdline.zip"
else
  info "이미 설치됨 — 건너뜀"
fi

export ANDROID_HOME="$SDK"
export ANDROID_SDK_ROOT="$SDK"
export PATH="$SDK/cmdline-tools/latest/bin:$SDK/platform-tools:$PATH"

if [ ! -d "$SDK/platforms/android-34" ]; then
  info "라이선스 동의 및 구성요소 설치 (몇 분 걸립니다)"
  yes | sdkmanager --licenses >/dev/null 2>&1 || true
  sdkmanager --install "platform-tools" "platforms;android-34" "build-tools;34.0.0" >/dev/null
else
  info "platform 34 / build-tools 34 이미 설치됨"
fi
printf 'sdk.dir=%s\n' "$SDK" > local.properties
info "local.properties 기록 완료"

# -------------------------------------------------- 3. Gradle
step "3/7  Gradle $GRADLE_VER 준비"
if [ ! -x "$GRADLE_HOME/bin/gradle" ]; then
  info "내려받는 중…"
  curl -fsSL -o "$TOOLS/gradle.zip" \
    "https://services.gradle.org/distributions/gradle-${GRADLE_VER}-bin.zip" \
    || die "Gradle 다운로드 실패"
  unzip -q "$TOOLS/gradle.zip" -d "$TOOLS" && rm -f "$TOOLS/gradle.zip"
else
  info "이미 설치됨 — 건너뜀"
fi
export PATH="$GRADLE_HOME/bin:$PATH"
GV="$(gradle --version 2>/dev/null || true)"
info "$(printf '%s\n' "$GV" | sed -n '/^Gradle /{p;q;}')"

# -------------------------------------------------- 4. 키스토어
step "4/7  서명 키스토어"
mkdir -p "$KS_DIR"
grep -qxF 'keystore/' .gitignore 2>/dev/null || echo 'keystore/' >> .gitignore
grep -qxF 'out/' .gitignore 2>/dev/null || echo 'out/' >> .gitignore
grep -qxF 'local.properties' .gitignore 2>/dev/null || echo 'local.properties' >> .gitignore

if [ -f "$KS" ]; then
  info "기존 키스토어 재사용 → 덮어쓰기 업데이트 가능"
else
  info "새 키스토어 생성"
  keytool -genkeypair -v \
    -keystore "$KS" -storetype PKCS12 \
    -storepass "$STORE_PASS" -keypass "$STORE_PASS" -alias "$ALIAS" \
    -keyalg RSA -keysize 2048 -validity 10000 \
    -dname "CN=AI Log EPUB, OU=Private Distribution, O=Local App Build, L=Seoul, C=KR" >/dev/null 2>&1
  warn "이 파일을 반드시 내려받아 보관하세요:  keystore/release.jks"
fi
base64 -w0 "$KS" > "$KS_DIR/release.jks.base64.txt"
cat > "$KS_DIR/암호.txt" <<TXT
KEYSTORE_PASSWORD = $STORE_PASS
KEY_ALIAS         = $ALIAS
KEY_PASSWORD      = $STORE_PASS
TXT

export KEYSTORE_PATH="$KS"
export KEYSTORE_PASSWORD="$STORE_PASS"
export KEY_ALIAS="$ALIAS"
export KEY_PASSWORD="$STORE_PASS"

# -------------------------------------------------- 5. 빌드
step "5/7  APK 빌드"
info "JAVA_HOME=$JAVA_HOME"
"$JAVA_HOME/bin/java" -version 2>&1 | sed -n '1p' | sed 's/^/  /'
gradle :app:assembleRelease --no-daemon --console=plain \
  "-Dorg.gradle.java.home=$JAVA_HOME" \
  "-PksPath=$KEYSTORE_PATH" "-PksPass=$KEYSTORE_PASSWORD" \
  "-PksAlias=$KEY_ALIAS" "-PkeyPass=$KEY_PASSWORD"

APK="$(find app/build/outputs/apk/release -name '*.apk' -print -quit 2>/dev/null || true)"
[ -n "$APK" ] || die "APK 가 생성되지 않았습니다."
case "$APK" in
  *unsigned*) die "서명되지 않은 APK 가 생성됐습니다. keystore/release.jks 를 확인하세요. ($APK)" ;;
esac

# -------------------------------------------------- 6. 검증
step "6/7  서명·무결성 검증"
BT="$(ls -d "$SDK"/build-tools/* 2>/dev/null | sort -V | tail -1 || true)"
if [ -x "$BT/apksigner" ]; then
  VER="$("$BT/apksigner" verify --verbose "$APK" 2>&1 || true)"
  printf '%s\n' "$VER" | sed -n '1,5p'
  echo "  --- 인증서 ---"
  CERT="$("$BT/apksigner" verify --print-certs "$APK" 2>&1 || true)"
  printf '%s\n' "$CERT" | grep -i "SHA-256" || true
else
  keytool -printcert -jarfile "$APK" | grep -i "SHA256" || true
fi

# -------------------------------------------------- 7. 산출물
step "7/7  완료"
mkdir -p "$OUT"
STAMP="$(date +%Y%m%d_%H%M)"
cp "$APK" "$OUT/AI_Log_EPUB_${STAMP}.apk"

echo
echo "  APK        : out/AI_Log_EPUB_${STAMP}.apk"
echo "  크기       : $(du -h "$OUT/AI_Log_EPUB_${STAMP}.apk" | cut -f1)"
echo "  APK SHA-256: $(sha256sum "$OUT/AI_Log_EPUB_${STAMP}.apk" | cut -d' ' -f1)"
echo
echo "  왼쪽 탐색기에서 out/ 폴더의 apk 를 우클릭 → Download 하면"
echo "  폰으로 바로 내려받아 설치할 수 있습니다."
echo
warn "keystore/release.jks 도 함께 내려받아 보관하세요."
warn "이 파일을 잃으면 다음 버전을 덮어쓰기 설치할 수 없습니다."
echo
echo "  GitHub 저장소에도 올리고 Actions 로 빌드하려면:  bash publish.sh"
echo
